# Step 82 — Distributed Tracing + Request Correlation

This step adds two complementary capabilities:

1. **Request correlation IDs**: every API request gets an `X-Request-ID` response header. Clients may supply the same header for end-to-end correlation. Structured logs automatically include the active request ID.
2. **OpenTelemetry tracing scaffold**: optional NodeSDK + OTLP HTTP exporter + Node auto-instrumentations. Tracing is disabled unless `OTEL_ENABLED=true`.

## Run with tracing

Install dependencies, configure `server/.env.tracing.example`, then use:

```bash
npm run start:otel
```

By default traces are exported to `http://localhost:4318/v1/traces`; replace this with your collector/observability provider endpoint.

## Correlation

Each response contains `X-Request-ID`. Pass it from frontend/mobile/client requests when a workflow crosses multiple services. Logs will contain:

```json
{"requestId":"...","event":"..."}
```

## Production notes

- Put the OTLP endpoint behind authenticated private networking or provider credentials.
- Do not put patient/medical data into trace attributes or span names.
- Keep request IDs non-sensitive and do not use them as authentication tokens.
- Centralize traces and logs so support can pivot from a request ID to trace/span data.
