# Monitoring deployment notes

Recommended production wiring:

- Uptime monitor -> `GET /api/health/live`
- Load balancer/Kubernetes readiness -> `GET /api/health/ready`
- Metrics collector -> `GET /api/health/metrics`
- Centralized error tracker (Sentry/OpenTelemetry/etc.) -> application logs
- Alert on repeated 5xx responses, readiness failures, and elevated latency

The included `npm run monitor:health` script can be run by cron/CI as a simple smoke check.
