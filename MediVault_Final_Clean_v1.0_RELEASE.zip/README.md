# MediVault

MediVault is a React + Vite health-record organizer with a Node.js/Express backend, PostgreSQL/Prisma data layer, secure document storage foundations, authentication/MFA, notifications, audit logging, observability, backup/DR tooling, and production deployment configuration.

## Local development

1. Install Node.js 20+ and PostgreSQL.
2. Install frontend dependencies: `npm install`
3. Configure the frontend/backend environment files from the provided `.env*.example` templates.
4. Install backend dependencies: `cd server && npm install`
5. Run Prisma migrations from the `server` directory.
6. Start the backend and frontend using the project scripts.

## Important

Some integrations (ABHA/ABDM, email/SMS/push providers, cloud object storage, maps, telemedicine, AI providers, and device health APIs) require real provider credentials/configuration before production use.
