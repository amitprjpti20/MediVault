# MediVault Step 93

See `README_STEP93.md` for the Step 93 changes.

## Step 95
Holiday scheduling now supports a configurable API-first public-holiday provider with fallback plus persisted custom holiday calendars and rotation application workflows.
