#!/bin/sh
set -eu
required="DATABASE_URL SESSION_SECRET ENCRYPTION_KEY OPERATIONS_TOKEN"
missing=0
for name in $required; do
  eval "value=\${$name-}"
  if [ -z "$value" ]; then echo "missing: $name"; missing=1; fi
done
if [ "$missing" -ne 0 ]; then exit 1; fi
echo "required production secrets are present"
