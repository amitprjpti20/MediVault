# MediVault API — Step 66

## Cloud object storage + encrypted document storage

Step 66 moves document persistence behind a storage abstraction and adds production-oriented encrypted-at-rest support.

### Storage modes
- `STORAGE_PROVIDER=s3` uses S3-compatible private object storage (AWS S3 or compatible providers).
- Objects are never served as a public static directory.
- Every document key is namespaced by authenticated user id and checked again before download/delete.
- Uploads use server-side encryption: AWS KMS (`aws:kms`) when `S3_SSE_KMS_KEY_ID` is configured, otherwise SSE-S3 (`AES256`).
- `STORAGE_PROVIDER=local-encrypted` is available for development. It encrypts files with AES-256-GCM using `LOCAL_STORAGE_MASTER_KEY_B64`.

### Setup
1. Copy `.env.example` to `.env`.
2. Configure PostgreSQL.
3. Configure a **private** S3 bucket and IAM permissions for the API service. Prefer KMS-backed encryption.
4. Run `npm install` in `server/`.
5. Run `npm run prisma:generate` and the reviewed production migration (or `prisma db push` only for development).
6. Start the API.

Production still requires bucket versioning/retention policy, backups, KMS key policy, least-privilege IAM, malware scanning, rate limiting, monitoring, secret management and privacy/compliance review.
