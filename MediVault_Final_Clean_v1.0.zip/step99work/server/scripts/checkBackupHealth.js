import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import process from 'node:process';
import 'dotenv/config';

const dir = process.env.BACKUP_DIR || path.resolve(process.cwd(), '../backups');
const maxAgeHours = Number(process.env.BACKUP_HEALTH_MAX_AGE_HOURS || 26);

async function main() {
  const files = (await fs.readdir(dir).catch(() => [])).filter(f => f.endsWith('.dump'));
  if (!files.length) throw new Error(`No PostgreSQL backups found in ${dir}`);
  const stats = await Promise.all(files.map(async f => {
    const p = path.join(dir, f);
    const s = await fs.stat(p);
    return { f, p, mtime: s.mtimeMs, size: s.size };
  }));
  stats.sort((a,b) => b.mtime - a.mtime);
  const latest = stats[0];
  const ageHours = (Date.now() - latest.mtime) / 36e5;
  const data = await fs.readFile(latest.p);
  const sha256 = crypto.createHash('sha256').update(data).digest('hex');
  const result = { ok: ageHours <= maxAgeHours, latestBackup: latest.f, sizeBytes: latest.size, ageHours: Number(ageHours.toFixed(2)), sha256, backupDir: dir, checkedAt: new Date().toISOString() };
  console.log(JSON.stringify(result, null, 2));
  if (!result.ok) process.exitCode = 2;
}
main().catch(err => { console.error(err.message); process.exitCode = 1; });
