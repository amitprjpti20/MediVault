import 'dotenv/config';
import { readdirSync, statSync, unlinkSync, readFileSync, createHash } from 'node:fs';
import { resolve, join, extname } from 'node:path';
import { S3Client, ListObjectsV2Command, DeleteObjectsCommand } from '@aws-sdk/client-s3';

const enabled = process.env.BACKUP_RETENTION_ENABLED === 'true';
if (!enabled) {
  console.log('Backup retention cleanup disabled. Set BACKUP_RETENTION_ENABLED=true to enable.');
  process.exit(0);
}

const days = Number(process.env.BACKUP_RETENTION_DAYS || 30);
if (!Number.isFinite(days) || days < 1) throw new Error('BACKUP_RETENTION_DAYS must be >= 1');
const cutoff = Date.now() - days * 86400000;
const dir = resolve(process.env.BACKUP_DIR || './backups');
const dryRun = process.env.BACKUP_RETENTION_DRY_RUN !== 'false';

function sha256(path) {
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}

function cleanupLocal() {
  let removed = 0;
  let kept = 0;
  try {
    for (const name of readdirSync(dir)) {
      if (extname(name) !== '.dump') continue;
      const path = join(dir, name);
      const mtime = statSync(path).mtimeMs;
      if (mtime < cutoff) {
        console.log(`${dryRun ? '[dry-run] ' : ''}Remove local backup: ${path} sha256=${sha256(path)}`);
        if (!dryRun) unlinkSync(path);
        removed++;
      } else kept++;
    }
  } catch (err) {
    if (err.code !== 'ENOENT') throw err;
  }
  return { removed, kept };
}

async function cleanupS3() {
  if (process.env.BACKUP_S3_ENABLED !== 'true') return { removed: 0, kept: 0, enabled: false };
  const bucket = process.env.BACKUP_S3_BUCKET;
  if (!bucket) throw new Error('BACKUP_S3_BUCKET is required when S3 backup is enabled');
  const prefix = (process.env.BACKUP_S3_PREFIX || 'medivault/database').replace(/\/+$/, '') + '/';
  const client = new S3Client({
    region: process.env.AWS_REGION || 'ap-south-1',
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
  });
  const keys = [];
  let token;
  do {
    const page = await client.send(new ListObjectsV2Command({ Bucket: bucket, Prefix: prefix, ContinuationToken: token }));
    for (const object of page.Contents || []) {
      if (object.Key && object.LastModified && object.LastModified.getTime() < cutoff) keys.push(object.Key);
    }
    token = page.IsTruncated ? page.NextContinuationToken : undefined;
  } while (token);

  for (let i = 0; i < keys.length; i += 1000) {
    const batch = keys.slice(i, i + 1000);
    console.log(`${dryRun ? '[dry-run] ' : ''}Remove S3 backups: ${batch.length}`);
    if (!dryRun) {
      await client.send(new DeleteObjectsCommand({
        Bucket: bucket,
        Delete: { Objects: batch.map(Key => ({ Key })), Quiet: true },
      }));
    }
  }
  return { removed: keys.length, kept: 0, enabled: true };
}

const local = cleanupLocal();
const remote = await cleanupS3();
console.log(JSON.stringify({ ok: true, dryRun, retentionDays: days, local, remote }, null, 2));
