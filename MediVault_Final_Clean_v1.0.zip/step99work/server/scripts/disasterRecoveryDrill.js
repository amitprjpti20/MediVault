import process from 'node:process';
import path from 'node:path';
import fs from 'node:fs/promises';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import 'dotenv/config';

const exec = promisify(execFile);
const backupDir = process.env.BACKUP_DIR || path.resolve(process.cwd(), '../backups');
const drillDbUrl = process.env.DR_RESTORE_DATABASE_URL;
const allow = process.env.DR_DRILL_ALLOW_DESTRUCTIVE === 'true';

async function main() {
  if (!drillDbUrl) throw new Error('DR_RESTORE_DATABASE_URL is required. Never point it at the primary production database.');
  if (!allow) throw new Error('Set DR_DRILL_ALLOW_DESTRUCTIVE=true only for a disposable recovery database.');
  const files = (await fs.readdir(backupDir)).filter(f => f.endsWith('.dump')).sort().reverse();
  if (!files.length) throw new Error('No .dump backup available for the drill.');
  const archive = path.join(backupDir, files[0]);
  await exec('pg_restore', ['--no-owner', '--no-privileges', '--clean', '--if-exists', '--dbname', drillDbUrl, archive]);
  console.log(JSON.stringify({ ok: true, archive, target: '[redacted]', completedAt: new Date().toISOString(), note: 'Restore drill completed against the configured disposable DR database.' }, null, 2));
}
main().catch(err => { console.error(err.stderr || err.message); process.exitCode = 1; });
