import "dotenv/config";
import fs from "node:fs/promises";

const base = (process.env.MONITOR_BASE_URL || `http://localhost:${process.env.PORT || 4000}`).replace(/\/$/, "");
const timeoutMs = Number(process.env.MONITOR_TIMEOUT_MS || 5000);
const endpoints = ["/api/health/live", "/api/health/ready", "/api/health/metrics"];

async function fetchWithTimeout(url) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  const started = Date.now();
  try {
    const response = await fetch(url, { signal: controller.signal });
    const body = await response.json().catch(() => ({}));
    return { url, ok: response.ok, status: response.status, latencyMs: Date.now() - started, body };
  } catch (error) {
    return { url, ok: false, status: 0, latencyMs: Date.now() - started, error: error.message };
  } finally { clearTimeout(timer); }
}

const results = await Promise.all(endpoints.map(path => fetchWithTimeout(`${base}${path}`)));
const report = { checkedAt: new Date().toISOString(), base, ok: results.every(r => r.ok), results };
console.log(JSON.stringify(report, null, 2));
if (process.env.MONITOR_REPORT_FILE) await fs.writeFile(process.env.MONITOR_REPORT_FILE, JSON.stringify(report, null, 2));
if (!report.ok) process.exitCode = 1;
