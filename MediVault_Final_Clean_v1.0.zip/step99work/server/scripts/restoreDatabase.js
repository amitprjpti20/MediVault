import 'dotenv/config';
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';

const databaseUrl = process.env.DATABASE_URL;
const input = process.argv[2];
if (!databaseUrl) throw new Error('DATABASE_URL is required');
if (!input || !existsSync(input)) throw new Error('Usage: npm run db:restore -- ./backups/file.dump');

console.warn('WARNING: restore will overwrite database objects. Confirm your backup and target database before continuing.');
const child = spawn('pg_restore', ['--clean', '--if-exists', '--no-owner', '--dbname', databaseUrl, input], { stdio: 'inherit' });
child.on('error', (err) => { console.error('pg_restore failed to start:', err.message); process.exit(1); });
child.on('exit', (code) => process.exit(code || 0));
