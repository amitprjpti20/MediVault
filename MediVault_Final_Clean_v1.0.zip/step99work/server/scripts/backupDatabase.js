import 'dotenv/config';
import { spawn } from 'node:child_process';
import { mkdirSync, createWriteStream } from 'node:fs';
import { dirname, resolve } from 'node:path';

const databaseUrl = process.env.DATABASE_URL;
if (!databaseUrl) throw new Error('DATABASE_URL is required');

const outDir = resolve(process.env.BACKUP_DIR || './backups');
mkdirSync(outDir, { recursive: true });
const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const output = resolve(outDir, `medivault-${stamp}.dump`);

const child = spawn('pg_dump', [databaseUrl, '--format=custom', '--no-owner', '--file', output], { stdio: ['ignore', 'pipe', 'pipe'] });
child.stdout.pipe(process.stdout);
child.stderr.pipe(process.stderr);
child.on('error', (err) => { console.error('pg_dump failed to start:', err.message); process.exit(1); });
child.on('exit', (code) => {
  if (code !== 0) process.exit(code || 1);
  console.log(`Backup created: ${output}`);
});
