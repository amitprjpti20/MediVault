import 'dotenv/config';
import { spawn } from 'node:child_process';
import { createHash, readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';

function run(command, args) {
  return new Promise((resolvePromise, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '', stderr = '';
    child.stdout.on('data', d => stdout += d);
    child.stderr.on('data', d => stderr += d);
    child.on('error', reject);
    child.on('exit', code => code === 0 ? resolvePromise({ stdout, stderr }) : reject(new Error(`${command} exited ${code}\n${stderr}`)));
  });
}

const file = resolve(process.argv[2] || process.env.BACKUP_VERIFY_FILE || '');
if (!file) throw new Error('Provide a backup .dump file: npm run db:verify-restore -- ./backups/file.dump');
const digest = createHash('sha256').update(readFileSync(file)).digest('hex');
const size = statSync(file).size;
const listing = await run('pg_restore', ['--list', file]);
const entries = listing.stdout.split('\n').filter(Boolean).length;
if (entries < 1) throw new Error('pg_restore --list returned no archive entries');
console.log(JSON.stringify({ ok: true, file, size, sha256: digest, archiveEntries: entries, restoreTested: false }, null, 2));
console.log('Archive structure verified. A full database restore test requires a disposable PostgreSQL target.');
