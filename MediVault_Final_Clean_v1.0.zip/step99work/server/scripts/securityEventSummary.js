import 'dotenv/config';
import { prisma } from '../src/lib/prisma.js';

const sinceHours=Number(process.env.SECURITY_SUMMARY_HOURS||24);
const events=await prisma.securityEvent.findMany({where:{createdAt:{gte:new Date(Date.now()-sinceHours*3600_000)}},orderBy:{createdAt:'desc'},take:500});
const byType={}; for(const e of events) byType[e.type]=(byType[e.type]||0)+1;
console.log(JSON.stringify({sinceHours,total:events.length,byType,generatedAt:new Date().toISOString()},null,2));
await prisma.$disconnect();
