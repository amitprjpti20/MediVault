import { existsSync, readFileSync, readdirSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = join(fileURLToPath(new URL('../', import.meta.url)));
const repo = join(root, '..');
const findings = [];
const checks = [];
function check(name, ok, detail='') { checks.push({name, ok, detail}); if (!ok) findings.push({name, detail}); }

check('Frontend package manifest', existsSync(join(repo, 'package.json')), 'package.json missing');
check('Backend package manifest', existsSync(join(root, 'package.json')), 'server/package.json missing');
check('Prisma schema', existsSync(join(root, 'prisma', 'schema.prisma')), 'schema.prisma missing');
check('Observability compose', existsSync(join(repo, 'observability', 'docker-compose.observability.yml')), 'compose file missing');

const serverSource = readFileSync(join(root, 'src', 'server.js'), 'utf8');
check('Helmet enabled', /app\.use\(helmet\(/.test(serverSource));
check('x-powered-by disabled', /app\.disable\(['"]x-powered-by['"]\)/.test(serverSource));
check('Body size limits configured', /express\.json\(\{ limit:/.test(serverSource) && /express\.urlencoded\(\{[^\n]*limit:/.test(serverSource));
check('Production error response generic', /Internal server error/.test(serverSource));
check('Internal incident/admin routes isolated', /app\.use\("\/internal\/incidents"/.test(serverSource) && /app\.use\("\/internal\/admin"/.test(serverSource));

const srcDir = join(root, 'src');
const files = [];
function walk(dir) { for (const n of readdirSync(dir)) { const p=join(dir,n); const s=statSync(p); if (s.isDirectory()) walk(p); else if (['.js','.mjs'].includes(extname(p))) files.push(p); } }
walk(srcDir);
for (const file of files) {
  const r = spawnSync(process.execPath, ['--check', file], { encoding: 'utf8' });
  check(`Syntax: ${file.replace(repo+'/', '')}`, r.status === 0, (r.stderr||'').trim());
}

const frontendBuild = existsSync(join(repo, 'node_modules', '.bin', 'vite'));
check('Frontend build tool available', frontendBuild, 'node_modules/.bin/vite not installed in this environment');
if (frontendBuild) {
  const r = spawnSync('npm', ['run', 'build'], { cwd: repo, encoding: 'utf8', stdio: 'pipe' });
  check('Frontend production build', r.status === 0, (r.stderr || r.stdout || '').slice(-1200));
}

const serverDeps = existsSync(join(root, 'node_modules', '.bin', 'prisma'));
check('Backend Prisma CLI available', serverDeps, 'server/node_modules/.bin/prisma not installed in this environment');

const report = {
  generatedAt: new Date().toISOString(),
  pass: findings.length === 0,
  checks,
  summary: { total: checks.length, passed: checks.filter(x=>x.ok).length, failed: findings.length }
};
console.log(JSON.stringify(report, null, 2));
process.exit(findings.some(f => f.name.includes('Syntax')) ? 2 : 0);
