import "dotenv/config";
import { runIncidentEscalationSweep } from "../src/lib/incidentEscalation.js";
import { prisma } from "../src/lib/prisma.js";
const results = await runIncidentEscalationSweep();
console.log(JSON.stringify({ ok: true, results }, null, 2));
await prisma.$disconnect();
