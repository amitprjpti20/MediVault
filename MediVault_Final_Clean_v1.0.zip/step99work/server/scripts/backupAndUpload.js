import 'dotenv/config';
import { spawn } from 'node:child_process';
import { mkdirSync, createHash, readFileSync, statSync, unlinkSync } from 'node:fs';
import { dirname, resolve, basename } from 'node:path';
import { PutObjectCommand, S3Client } from '@aws-sdk/client-s3';

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`${name} is required`);
  return value;
}

function runPgDump(output) {
  return new Promise((resolvePromise, reject) => {
    const databaseUrl = required('DATABASE_URL');
    const child = spawn('pg_dump', [databaseUrl, '--format=custom', '--no-owner', '--file', output], { stdio: ['ignore', 'pipe', 'pipe'] });
    child.stdout.pipe(process.stdout);
    child.stderr.pipe(process.stderr);
    child.on('error', reject);
    child.on('exit', code => code === 0 ? resolvePromise() : reject(new Error(`pg_dump exited with code ${code}`)));
  });
}

function sha256(path) {
  return createHash('sha256').update(readFileSync(path)).digest('hex');
}

async function uploadToS3(filePath, digest) {
  const bucket = required('BACKUP_S3_BUCKET');
  const region = process.env.AWS_REGION || 'ap-south-1';
  const prefix = (process.env.BACKUP_S3_PREFIX || 'medivault/database').replace(/\/+$/, '');
  const key = `${prefix}/${basename(filePath)}`;
  const client = new S3Client({
    region,
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === 'true',
  });

  const body = readFileSync(filePath);
  const command = new PutObjectCommand({
    Bucket: bucket,
    Key: key,
    Body: body,
    ContentType: 'application/octet-stream',
    ChecksumSHA256: Buffer.from(digest, 'hex').toString('base64'),
    ServerSideEncryption: process.env.BACKUP_S3_SSE_KMS_KEY_ID ? 'aws:kms' : 'AES256',
    ...(process.env.BACKUP_S3_SSE_KMS_KEY_ID ? { SSEKMSKeyId: process.env.BACKUP_S3_SSE_KMS_KEY_ID } : {}),
    Metadata: { sha256: digest, generatedAt: new Date().toISOString() },
  });
  await client.send(command);
  return { bucket, key };
}

async function main() {
  const outDir = resolve(process.env.BACKUP_DIR || './backups');
  mkdirSync(outDir, { recursive: true });
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const output = resolve(outDir, `medivault-${stamp}.dump`);

  await runPgDump(output);
  const digest = sha256(output);
  const size = statSync(output).size;
  console.log(`Backup created: ${output}`);
  console.log(`SHA-256: ${digest}`);
  console.log(`Size: ${size} bytes`);

  let remote = null;
  if (process.env.BACKUP_S3_ENABLED === 'true') {
    remote = await uploadToS3(output, digest);
    console.log(`Cloud backup uploaded: s3://${remote.bucket}/${remote.key}`);
  } else {
    console.log('Cloud upload disabled (BACKUP_S3_ENABLED != true).');
  }

  console.log(JSON.stringify({ ok: true, output, digest, size, remote }, null, 2));
}

main().catch(err => {
  console.error('Backup job failed:', err.message);
  process.exit(1);
});
