import "dotenv/config";
import { prisma } from "../src/lib/prisma.js";
import { encryptOptional, isFieldEncryptionConfigured } from "../src/lib/fieldEncryption.js";

if (!isFieldEncryptionConfigured()) throw new Error("Set FIELD_ENCRYPTION_KEY_B64 before migrating plaintext sensitive data.");

const records = await prisma.medicalRecord.findMany({ select: { id: true, type: true, title: true, summary: true, typeEncrypted: true, titleEncrypted: true, summaryEncrypted: true } });
for (const r of records) {
  await prisma.medicalRecord.update({ where: { id: r.id }, data: {
    typeEncrypted: r.typeEncrypted || encryptOptional(r.type),
    titleEncrypted: r.titleEncrypted || encryptOptional(r.title),
    summaryEncrypted: r.summaryEncrypted || encryptOptional(r.summary),
    type: null,
    title: null,
    summary: null,
  }});
}

const consents = await prisma.consent.findMany({ select: { id: true, scope: true, granteeRef: true, scopeEncrypted: true, granteeRefEncrypted: true } });
for (const c of consents) {
  await prisma.consent.update({ where: { id: c.id }, data: {
    scopeEncrypted: c.scopeEncrypted || encryptOptional(c.scope),
    granteeRefEncrypted: c.granteeRefEncrypted || encryptOptional(c.granteeRef),
    scope: null,
    granteeRef: null,
  }});
}

console.log(`Re-encrypted ${records.length} medical records and ${consents.length} consent rows.`);
await prisma.$disconnect();
