import { createReadStream, statSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';

const input = process.argv[2];
if (!input || !existsSync(input)) throw new Error('Usage: npm run db:verify-backup -- ./backups/file.dump');
const size = statSync(input).size;
const hash = createHash('sha256');
await new Promise((resolve, reject) => {
  const s = createReadStream(input); s.on('data', c => hash.update(c)); s.on('end', resolve); s.on('error', reject);
});
console.log(JSON.stringify({ file: input, bytes: size, sha256: hash.digest('hex') }, null, 2));
