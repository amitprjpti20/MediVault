import { prisma } from "../lib/prisma.js";
import { recordSecurityEvent } from "../lib/securityEvents.js";
import { logger } from "../lib/logger.js";

const SENSITIVE_PATH_PARTS = ["/auth/login", "/auth/register", "/auth/logout"];

function resourceFromPath(path = "") {
  const clean = path.split("?")[0].replace(/^\/api\//, "");
  const first = clean.split("/").filter(Boolean)[0] || "api";
  return first;
}

function actionFromRequest(method, path) {
  const clean = path.split("?")[0];
  if (SENSITIVE_PATH_PARTS.some((p) => clean.endsWith(p))) {
    if (clean.endsWith("/login")) return method === "POST" ? "AUTH_LOGIN" : "AUTH";
    if (clean.endsWith("/register")) return method === "POST" ? "AUTH_REGISTER" : "AUTH";
    if (clean.endsWith("/logout")) return method === "POST" ? "AUTH_LOGOUT" : "AUTH";
  }
  return ({ GET: "READ", POST: "CREATE", PUT: "UPDATE", PATCH: "UPDATE", DELETE: "DELETE" })[method] || method;
}

export function auditRequest(req, res, next) {
  const started = Date.now();
  res.on("finish", () => {
    const statusCode = res.statusCode;
    const outcome = statusCode >= 400 ? "failure" : "success";
    const path = req.originalUrl || req.path || "";
    const ipAddress = req.ip || req.socket?.remoteAddress || null;
    const userAgent = req.get("user-agent")?.slice(0, 512) || null;
    const userId = req.user?.id || null;
    const action = actionFromRequest(req.method, path);
    const resource = resourceFromPath(path);
    prisma.auditLog.create({
      data: { userId, action, resource, method:req.method, path:path.slice(0,500), statusCode, outcome, ipAddress, userAgent },
    }).catch((error) => {
      logger.error("audit_log_write_failed", { error:error.message, action, resource, statusCode });
    });

    if (statusCode === 401 || statusCode === 403 || statusCode === 429) {
      void recordSecurityEvent({
        userId,
        type: statusCode===429 ? "rate_limit" : "access_denied",
        severity: statusCode===429 ? "high" : "medium",
        action, resource, statusCode, ipAddress, userAgent,
      });
    }
    void started;
  });
  next();
}
