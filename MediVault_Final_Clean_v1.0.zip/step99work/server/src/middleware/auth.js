import { SESSION_COOKIE, getUserFromToken } from "../lib/auth.js";

export async function requireAuth(req, res, next) {
  try {
    const user = await getUserFromToken(req.cookies?.[SESSION_COOKIE]);
    if (!user) return res.status(401).json({ error: "Authentication required" });
    req.user = user;
    return next();
  } catch (error) {
    return next(error);
  }
}
