import { recordRequest } from "../lib/metrics.js";
import { recordSecurityEvent } from "../lib/securityEvents.js";
import { logger } from "../lib/logger.js";
import { getRequestId } from "../lib/requestContext.js";

export function observability(req, res, next) {
  const started = process.hrtime.bigint();
  res.on("finish", () => {
    const durationMs = Number(process.hrtime.bigint() - started) / 1e6;
    recordRequest({ method: req.method, path: req.route?.path ? `${req.baseUrl}${req.route.path}` : req.path, statusCode: res.statusCode, durationMs });
    if (res.statusCode >= 500) {
      logger.error("http_request_error", { method:req.method, path:req.path, statusCode:res.statusCode, durationMs:Number(durationMs.toFixed(2)), userId:req.user?.id || null, requestId:getRequestId() });
      void recordSecurityEvent({ userId:req.user?.id || null, type:"server_error", severity:"high", action:"HTTP_5XX", resource:req.path.split("/")[2] || "api", statusCode:res.statusCode, ipAddress:req.ip || req.socket?.remoteAddress || null, userAgent:req.get("user-agent") });
    }
  });
  next();
}
