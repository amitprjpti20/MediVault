import { recordHttpPerformance } from '../lib/performance.js';
import { logger } from '../lib/logger.js';

export function performanceMiddleware(req, res, next) {
  const started = process.hrtime.bigint();
  res.on('finish', () => {
    const durationMs = Number(process.hrtime.bigint() - started) / 1e6;
    recordHttpPerformance({
      method: req.method,
      path: req.route?.path ? `${req.baseUrl}${req.route.path}` : req.path,
      statusCode: res.statusCode,
      durationMs,
    });
    if (durationMs >= Number(process.env.SLOW_REQUEST_MS || 1000)) {
      logger.warn('slow_http_request', {
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        durationMs: Number(durationMs.toFixed(2)),
        userId: req.user?.id || null,
      });
    }
  });
  next();
}
