let otel = null;
try { otel = await import('@opentelemetry/api'); } catch {}

export function tracingMiddleware(req, res, next) {
  if (!otel?.trace || process.env.OTEL_ENABLED !== 'true') return next();
  const tracer = otel.trace.getTracer('medivault-api');
  const span = tracer.startSpan(`${req.method} ${req.path}`);
  span.setAttribute('http.request.method', req.method);
  span.setAttribute('url.path', req.path);
  span.setAttribute('http.request.header.x_request_id', req.get('x-request-id') || '');
  const finish = () => {
    span.setAttribute('http.response.status_code', res.statusCode);
    span.end();
  };
  res.once('finish', finish);
  res.once('close', () => { if (!res.writableFinished) span.setAttribute('http.response.status_code', 499); finish(); });
  next();
}
