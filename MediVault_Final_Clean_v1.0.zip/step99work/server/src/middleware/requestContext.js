import { requestContext, createRequestId } from '../lib/requestContext.js';

export function requestContextMiddleware(req, res, next) {
  const requestId = createRequestId(req.get('x-request-id'));
  res.setHeader('X-Request-ID', requestId);
  requestContext.run({ requestId }, next);
}
