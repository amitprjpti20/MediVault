const buckets = new Map();

function now() { return Date.now(); }
function parsePositiveInt(value, fallback) {
  const n = Number(value);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback;
}

function getClientKey(req) {
  return req.ip || req.socket?.remoteAddress || "unknown";
}

export function createRateLimiter({ windowMs, max, keyPrefix }) {
  const ttl = parsePositiveInt(windowMs, 60_000);
  const limit = parsePositiveInt(max, 60);
  return function rateLimiter(req, res, next) {
    const key = `${keyPrefix}:${getClientKey(req)}`;
    const current = buckets.get(key);
    const timestamp = now();
    if (!current || timestamp >= current.resetAt) {
      buckets.set(key, { count: 1, resetAt: timestamp + ttl });
      res.setHeader("RateLimit-Limit", limit);
      res.setHeader("RateLimit-Remaining", Math.max(0, limit - 1));
      return next();
    }
    current.count += 1;
    const remaining = Math.max(0, limit - current.count);
    res.setHeader("RateLimit-Limit", limit);
    res.setHeader("RateLimit-Remaining", remaining);
    res.setHeader("RateLimit-Reset", Math.ceil((current.resetAt - timestamp) / 1000));
    if (current.count > limit) {
      return res.status(429).json({ error: "Too many requests. Please try again later." });
    }
    next();
  };
}

export function createAuthBruteForceGuard({ windowMs, maxAttempts, blockMs }) {
  const ttl = parsePositiveInt(windowMs, 15 * 60_000);
  const attemptsLimit = parsePositiveInt(maxAttempts, 8);
  const blockDuration = parsePositiveInt(blockMs, 15 * 60_000);
  const states = new Map();

  return function authBruteForceGuard(req, res, next) {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const ip = getClientKey(req);
    const key = `auth:${ip}:${email}`;
    const timestamp = now();
    let state = states.get(key);
    if (!state || timestamp >= state.windowResetAt) {
      state = { failures: 0, windowResetAt: timestamp + ttl, blockedUntil: 0 };
      states.set(key, state);
    }
    if (state.blockedUntil > timestamp) {
      res.setHeader("Retry-After", Math.ceil((state.blockedUntil - timestamp) / 1000));
      return res.status(429).json({ error: "Too many failed login attempts. Try again later." });
    }

    res.locals.recordAuthFailure = () => {
      state.failures += 1;
      if (state.failures >= attemptsLimit) state.blockedUntil = timestamp + blockDuration;
    };
    res.locals.clearAuthFailures = () => states.delete(key);
    next();
  };
}

setInterval(() => {
  const timestamp = now();
  for (const [key, value] of buckets) if (timestamp >= value.resetAt) buckets.delete(key);
}, 10 * 60_000).unref();
