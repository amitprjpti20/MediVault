import { prisma } from '../lib/prisma.js';
import { dispatchNotification } from '../lib/notificationDelivery.js';

const intervalMs = Number(process.env.REMINDER_WORKER_INTERVAL_MS || 30000);
const leadMinutes = Number(process.env.REMINDER_LEAD_MINUTES || 60);
const batchSize = Number(process.env.REMINDER_WORKER_BATCH || 100);

export async function processDueReminders() {
  const now = new Date();
  const horizon = new Date(now.getTime() + leadMinutes * 60_000);
  const events = await prisma.calendarEvent.findMany({
    where: { completed: false, startAt: { gte: new Date(now.getTime() - 24 * 60 * 60_000), lte: horizon } },
    orderBy: { startAt: 'asc' },
    take: batchSize,
    select: { id: true, userId: true, profileId: true, title: true, type: true, notes: true, startAt: true }
  });
  let created = 0;
  for (const event of events) {
    const existing = await prisma.notification.findUnique({ where: { sourceEventId: event.id } });
    if (existing) continue;
    const minutes = Math.round((event.startAt.getTime() - now.getTime()) / 60_000);
    const relative = minutes <= 0 ? 'now' : minutes === 1 ? 'in 1 minute' : `in ${minutes} minutes`;
    const notification = await prisma.notification.create({
      data: {
        userId: event.userId,
        profileId: event.profileId,
        sourceEventId: event.id,
        type: 'REMINDER',
        title: event.title,
        body: `${event.type || 'Reminder'} ${relative}.`,
        scheduledFor: event.startAt,
      }
    });
    created += 1;
    const delivery = await dispatchNotification(notification.id).catch(error => ({ ok: false, errors: [error.message] }));
    if (delivery?.errors?.length) console.warn(`Notification delivery had errors for ${notification.id}:`, delivery.errors.join(' | '));
  }
  return { checked: events.length, created };
}

export function startReminderWorker() {
  let running = false;
  const tick = async () => {
    if (running) return;
    running = true;
    try {
      const result = await processDueReminders();
      if (result.created) console.log(`Reminder worker created ${result.created} notification(s).`);
    } catch (error) {
      console.warn('Reminder worker cycle failed:', error?.message || error);
    } finally { running = false; }
  };
  tick();
  return setInterval(tick, intervalMs);
}
