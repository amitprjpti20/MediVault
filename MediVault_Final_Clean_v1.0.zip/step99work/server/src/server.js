import "dotenv/config";
import express from "express";
import cors from "cors";
import helmet from "helmet";
import cookieParser from "cookie-parser";
import { prisma } from "./lib/prisma.js";
import { healthRouter } from "./routes/health.js";
import { authRouter } from "./routes/auth.js";
import { resourceRouter } from "./routes/resources.js";
import { startReminderWorker } from "./workers/reminderWorker.js";
import { auditRequest } from "./middleware/audit.js";
import { observability } from "./middleware/observability.js";
import { logger } from "./lib/logger.js";
import { securityRouter } from "./routes/security.js";
import { performanceRouter } from "./routes/performance.js";
import { performanceMiddleware } from "./middleware/performance.js";
import { metricsRouter } from "./routes/metrics.js";
import { requestContextMiddleware } from "./middleware/requestContext.js";
import { tracingMiddleware } from "./middleware/tracing.js";
import { incidentsRouter } from "./routes/incidents.js";
import { runIncidentEscalationSweep } from "./lib/incidentEscalation.js";
import { onCallRouter } from "./routes/oncall.js";
import { adminRouter } from "./routes/admin.js";

const app = express();
const trustProxy = process.env.TRUST_PROXY;
if (trustProxy) app.set("trust proxy", trustProxy === "true" ? 1 : trustProxy);
const port = Number(process.env.PORT || 4000);

app.disable("x-powered-by");
app.use(helmet({
  contentSecurityPolicy: false,
  crossOriginEmbedderPolicy: false,
}));
app.use(cors({ origin: process.env.CORS_ORIGIN?.split(",").map(v => v.trim()).filter(Boolean) || true, credentials: true }));
app.use(express.json({ limit: process.env.JSON_BODY_LIMIT || "512kb" }));
app.use(express.urlencoded({ extended: false, limit: process.env.URLENCODED_BODY_LIMIT || "128kb" }));
app.use(cookieParser());
app.use(requestContextMiddleware);
app.use(tracingMiddleware);
app.use(observability);
app.use(performanceMiddleware);
app.use(auditRequest);

app.get("/", (_req, res) => res.json({ name: "MediVault API", status: "auth-enabled-scaffold", version: "0.2.1-step90" }));
app.use("/api/health", healthRouter);
app.use("/api/security", securityRouter);
app.use("/internal/incidents", incidentsRouter);
app.use("/internal/oncall", onCallRouter);
app.use("/internal/admin", adminRouter);
app.use("/api/performance", performanceRouter);
app.use("/metrics", metricsRouter);
app.use("/api/auth", authRouter);
app.use("/api", resourceRouter);
const reminderWorkerTimer = startReminderWorker();
const incidentSweepMs = Math.max(60, Number(process.env.INCIDENT_SWEEP_SECONDS || 60)) * 1000;
const incidentEscalationTimer = setInterval(() => {
  runIncidentEscalationSweep().catch((error) => logger.error("incident_escalation_sweep_failed", { error: error?.message }));
}, incidentSweepMs);

app.use((err, _req, res, _next) => {
  logger.error("unhandled_request_error", { error:err?.message, code:err?.code, stack: process.env.NODE_ENV === "production" ? undefined : err?.stack });
  if (err?.code === "P2021" || err?.code === "P2022") return res.status(503).json({ error: "Database schema is not initialized." });
  res.status(500).json({ error: "Internal server error" });
});

let server;
async function start() {
  try {
    await prisma.$connect();
    logger.info("database_connected");
  } catch (error) {
    logger.warn("database_connection_unavailable", { message:"Start Postgres and verify DATABASE_URL before using auth/data APIs." });
  }
  server = app.listen(port, () => logger.info("server_started", {port}));
}

start();

async function shutdown() {
  clearInterval(reminderWorkerTimer);
  clearInterval(incidentEscalationTimer);
  if (server) server.close();
  await prisma.$disconnect().catch(() => {});
  process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);
