import { Router } from "express";
import { processAlertmanagerPayload, listIncidents } from "../lib/incidentResponse.js";
import { prisma } from "../lib/prisma.js";
import { runIncidentEscalationSweep } from "../lib/incidentEscalation.js";

export const incidentsRouter = Router();

function requireIncidentToken(req, res, next) {
  const expected = process.env.ALERTMANAGER_WEBHOOK_TOKEN;
  const supplied = req.get("x-alertmanager-token");
  if (!expected || !supplied || supplied !== expected) {
    return res.status(401).json({ error: "Incident endpoint authentication failed." });
  }
  next();
}

function actor(req) { return (req.get("x-incident-actor") || "on-call").slice(0, 120); }

incidentsRouter.post("/alertmanager", requireIncidentToken, async (req, res, next) => {
  try { const results = await processAlertmanagerPayload(req.body); res.status(202).json({ ok: true, processed: results.length, results }); }
  catch (error) { next(error); }
});

incidentsRouter.get("/dashboard", requireIncidentToken, async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 200);
    const incidents = await listIncidents({ status: req.query.status, severity: req.query.severity, limit });
    const open = incidents.filter((x) => x.status === "firing");
    const acknowledged = open.filter((x) => x.acknowledgedAt);
    const critical = open.filter((x) => String(x.severity).toLowerCase() === "critical");
    res.json({
      data: incidents,
      summary: { total: incidents.length, open: open.length, acknowledged: acknowledged.length, critical: critical.length, generatedAt: new Date().toISOString() },
    });
  } catch (error) { next(error); }
});

incidentsRouter.get("", requireIncidentToken, async (req, res, next) => {
  try { const data = await listIncidents({ status: req.query.status, severity: req.query.severity, limit: req.query.limit }); res.json({ data }); }
  catch (error) { next(error); }
});

incidentsRouter.post("/:id/acknowledge", requireIncidentToken, async (req, res, next) => {
  try {
    const updated = await prisma.alertIncident.update({
      where: { id: req.params.id },
      data: { acknowledgedAt: new Date(), acknowledgedBy: actor(req), nextEscalationAt: null },
    });
    res.json({ ok: true, data: updated });
  } catch (error) { next(error); }
});

incidentsRouter.post("/:id/unacknowledge", requireIncidentToken, async (req, res, next) => {
  try {
    const updated = await prisma.alertIncident.update({
      where: { id: req.params.id },
      data: { acknowledgedAt: null, acknowledgedBy: null, nextEscalationAt: new Date(Date.now() + 15 * 60_000) },
    });
    res.json({ ok: true, data: updated });
  } catch (error) { next(error); }
});

incidentsRouter.post("/:id/notes", requireIncidentToken, async (req, res, next) => {
  try {
    const note = String(req.body?.note || "").trim().slice(0, 4000);
    if (!note) return res.status(400).json({ error: "note is required" });
    const updated = await prisma.alertIncident.update({ where: { id: req.params.id }, data: { responderNotes: note } });
    res.json({ ok: true, data: updated });
  } catch (error) { next(error); }
});

incidentsRouter.post("/escalation/sweep", requireIncidentToken, async (_req, res, next) => {
  try { const results = await runIncidentEscalationSweep(); res.json({ ok: true, results }); }
  catch (error) { next(error); }
});
