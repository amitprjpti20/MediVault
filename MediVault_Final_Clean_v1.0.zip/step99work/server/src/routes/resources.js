import { Router } from "express";
import { z } from "zod";
import crypto from "node:crypto";
import multer from "multer";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";
import { putObject, getObject, deleteObject } from "../lib/storage.js";
import { encryptOptional, decryptWithFallback, isFieldEncryptionConfigured } from "../lib/fieldEncryption.js";

export const resourceRouter = Router();
resourceRouter.use(requireAuth);

const DOCUMENT_LIMIT_BYTES = Number(process.env.MAX_DOCUMENT_BYTES || 10 * 1024 * 1024);
const allowedMime = new Set([
  "application/pdf",
  "image/jpeg",
  "image/png",
  "image/webp",
  "text/plain",
  "application/msword",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
]);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: DOCUMENT_LIMIT_BYTES, files: 1 },
  fileFilter: (_req, file, cb) => cb(null, allowedMime.has(file.mimetype)),
});

const profileSchema = z.object({
  name: z.string().trim().min(1).max(120),
  relation: z.string().trim().max(80).optional().nullable(),
  dob: z.string().date().optional().nullable(),
});
const medicationSchema = z.object({
  name: z.string().trim().min(1).max(160),
  dose: z.string().trim().max(80).optional().nullable(),
  frequency: z.string().trim().max(120).optional().nullable(),
  active: z.boolean().optional(),
});
const vitalSchema = z.object({
  type: z.string().trim().min(1).max(100),
  value: z.string().trim().min(1).max(100),
  unit: z.string().trim().max(40).optional().nullable(),
  recordedAt: z.string().datetime().optional().nullable(),
  profileId: z.string().min(1).optional().nullable(),
});
const vaccinationSchema = z.object({
  vaccineName: z.string().trim().min(1).max(160),
  doseNumber: z.string().trim().max(40).optional().nullable(),
  administeredAt: z.string().datetime().optional().nullable(),
  nextDueAt: z.string().datetime().optional().nullable(),
  provider: z.string().trim().max(160).optional().nullable(),
  notes: z.string().max(1000).optional().nullable(),
  profileId: z.string().min(1).optional().nullable(),
});
const goalSchema = z.object({
  title: z.string().trim().min(1).max(180),
  metric: z.string().trim().max(100).optional().nullable(),
  target: z.string().trim().max(100).optional().nullable(),
  current: z.string().trim().max(100).optional().nullable(),
  unit: z.string().trim().max(40).optional().nullable(),
  status: z.string().trim().max(40).optional(),
  dueDate: z.string().datetime().optional().nullable(),
  profileId: z.string().min(1).optional().nullable(),
});

const labReportSchema = z.object({
  testName: z.string().trim().min(1).max(160),
  result: z.string().trim().max(160).optional().nullable(),
  unit: z.string().trim().max(80).optional().nullable(),
  reference: z.string().trim().max(160).optional().nullable(),
  status: z.string().trim().max(40).optional().nullable(),
  testedAt: z.string().datetime().optional().nullable(),
  profileId: z.string().min(1).optional().nullable(),
});

const recordSchema = z.object({
  type: z.string().trim().min(1).max(80),
  title: z.string().trim().min(1).max(200),
  summary: z.string().max(5000).optional().nullable(),
  occurredAt: z.string().datetime().optional().nullable(),
  profileId: z.string().min(1).optional().nullable(),
});

const recordUpdateSchema = recordSchema.partial();

async function assertProfileOwner(profileId, userId) {
  if (!profileId) return true;
  const profile = await prisma.healthProfile.findFirst({ where: { id: profileId, userId }, select: { id: true } });
  return Boolean(profile);
}

async function ensureUserFolder(userId) {
  const folder = path.join(DATA_ROOT, userId);
  await fs.mkdir(folder, { recursive: true, mode: 0o700 });
  return folder;
}

resourceRouter.get("/me", async (req, res) => {
  res.json({ user: { id: req.user.id, email: req.user.email, name: req.user.name, createdAt: req.user.createdAt } });
});

resourceRouter.get("/profiles", async (req, res, next) => {
  try {
    const profiles = await prisma.healthProfile.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: "asc" } });
    res.json({ data: profiles });
  } catch (error) { next(error); }
});

resourceRouter.post("/profiles", async (req, res, next) => {
  try {
    const parsed = profileSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid family profile payload." });
    const profile = await prisma.healthProfile.create({ data: { ...parsed.data, userId: req.user.id, dob: parsed.data.dob ? new Date(parsed.data.dob) : null } });
    res.status(201).json({ data: profile });
  } catch (error) { next(error); }
});

resourceRouter.patch("/profiles/:id", async (req, res, next) => {
  try {
    const parsed = profileSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid family profile payload." });
    const existing = await prisma.healthProfile.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!existing) return res.status(404).json({ error: "Profile not found." });
    const data = { ...parsed.data };
    if (data.dob !== undefined) data.dob = data.dob ? new Date(data.dob) : null;
    const profile = await prisma.healthProfile.update({ where: { id: existing.id }, data });
    res.json({ data: profile });
  } catch (error) { next(error); }
});

resourceRouter.delete("/profiles/:id", async (req, res, next) => {
  try {
    const existing = await prisma.healthProfile.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!existing) return res.status(404).json({ error: "Profile not found." });
    await prisma.healthProfile.delete({ where: { id: existing.id } });
    res.status(204).end();
  } catch (error) { next(error); }
});

resourceRouter.get("/records", async (req, res, next) => {
  try {
    const records = await prisma.medicalRecord.findMany({ where: { userId: req.user.id }, orderBy: [{ occurredAt: "desc" }, { createdAt: "desc" }] });
    const data = records.map((record) => ({
      ...record,
      type: decryptWithFallback(record.typeEncrypted, record.type),
      title: decryptWithFallback(record.titleEncrypted, record.title),
      summary: decryptWithFallback(record.summaryEncrypted, record.summary),
    }));
    res.json({ data });
  } catch (error) { next(error); }
});

resourceRouter.post("/records", async (req, res, next) => {
  try {
    const parsed = recordSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid medical record payload." });
    if (!(await assertProfileOwner(parsed.data.profileId, req.user.id))) return res.status(403).json({ error: "Profile does not belong to this account." });
    if (!isFieldEncryptionConfigured()) return res.status(503).json({ error: "Sensitive-data encryption is not configured." });
    const record = await prisma.medicalRecord.create({
      data: {
        userId: req.user.id,
        type: null,
        title: null,
        summary: null,
        typeEncrypted: encryptOptional(parsed.data.type),
        titleEncrypted: encryptOptional(parsed.data.title),
        summaryEncrypted: encryptOptional(parsed.data.summary),
        occurredAt: parsed.data.occurredAt ? new Date(parsed.data.occurredAt) : null,
        profileId: parsed.data.profileId ?? null,
      }
    });
    res.status(201).json({ data: { ...record, type: parsed.data.type, title: parsed.data.title, summary: parsed.data.summary ?? null } });
  } catch (error) { next(error); }
});

resourceRouter.patch("/records/:id", async (req, res, next) => {
  try {
    const parsed = recordUpdateSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid medical record payload." });
    const existing = await prisma.medicalRecord.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!existing) return res.status(404).json({ error: "Record not found." });
    if (parsed.data.profileId !== undefined && !(await assertProfileOwner(parsed.data.profileId, req.user.id))) return res.status(403).json({ error: "Profile does not belong to this account." });
    if (!isFieldEncryptionConfigured()) return res.status(503).json({ error: "Sensitive-data encryption is not configured." });
    const data = { ...parsed.data };
    if (data.occurredAt !== undefined) data.occurredAt = data.occurredAt ? new Date(data.occurredAt) : null;
    if (data.type !== undefined) data.typeEncrypted = encryptOptional(data.type);
    if (data.title !== undefined) data.titleEncrypted = encryptOptional(data.title);
    if (data.summary !== undefined) data.summaryEncrypted = encryptOptional(data.summary);
    const record = await prisma.medicalRecord.update({ where: { id: existing.id }, data });
    res.json({ data: { ...record, type: data.type ?? decryptWithFallback(existing.typeEncrypted, existing.type), title: data.title ?? decryptWithFallback(existing.titleEncrypted, existing.title), summary: data.summary !== undefined ? data.summary : decryptWithFallback(existing.summaryEncrypted, existing.summary) } });
  } catch (error) { next(error); }
});

resourceRouter.delete("/records/:id", async (req, res, next) => {
  try {
    const existing = await prisma.medicalRecord.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!existing) return res.status(404).json({ error: "Record not found." });
    await prisma.medicalRecord.delete({ where: { id: existing.id } });
    res.status(204).end();
  } catch (error) { next(error); }
});

resourceRouter.get("/records/:id", async (req, res, next) => {
  try {
    const record = await prisma.medicalRecord.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!record) return res.status(404).json({ error: "Record not found." });
    res.json({ data: { ...record, type: decryptWithFallback(record.typeEncrypted, record.type), title: decryptWithFallback(record.titleEncrypted, record.title), summary: decryptWithFallback(record.summaryEncrypted, record.summary) } });
  } catch (error) { next(error); }
});

resourceRouter.get("/documents", async (req, res, next) => {
  try {
    const documents = await prisma.document.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: "desc" }, select: { id: true, name: true, mimeType: true, sizeBytes: true, sha256: true, objectKey: true, createdAt: true, updatedAt: true } });
    res.json({ data: documents });
  } catch (error) { next(error); }
});

resourceRouter.post("/documents", upload.single("file"), async (req, res, next) => {
  try {
    if (!req.file) return res.status(400).json({ error: "A supported file is required." });
    const objectKey = `${req.user.id}/${crypto.randomUUID()}`;
    const digest = crypto.createHash("sha256").update(req.file.buffer).digest("hex");
    await putObject({ objectKey, body: req.file.buffer, contentType: req.file.mimetype });
    const document = await prisma.document.create({
      data: { userId: req.user.id, name: req.file.originalname.slice(0, 255), mimeType: req.file.mimetype, objectKey, sizeBytes: req.file.size, sha256: digest },
      select: { id: true, name: true, mimeType: true, sizeBytes: true, sha256: true, createdAt: true, updatedAt: true }
    });
    res.status(201).json({ data: document });
  } catch (error) { next(error); }
});

resourceRouter.get("/documents/:id/download", async (req, res, next) => {
  try {
    const document = await prisma.document.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!document) return res.status(404).json({ error: "Document not found." });
    const file = await getObject(document.objectKey);
    res.setHeader("Content-Type", document.mimeType);
    res.setHeader("Content-Length", String(file.body.length));
    res.setHeader("Content-Disposition", `attachment; filename*=UTF-8''${encodeURIComponent(document.name)}`);
    res.end(file.body);
  } catch (error) { next(error); }
});

resourceRouter.delete("/documents/:id", async (req, res, next) => {
  try {
    const document = await prisma.document.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!document) return res.status(404).json({ error: "Document not found." });
    await deleteObject(document.objectKey);
    await prisma.document.delete({ where: { id: document.id } });
    res.status(204).end();
  } catch (error) { next(error); }
});

resourceRouter.get("/audit-logs", async (req, res, next) => {
  try {
    const limit = Math.min(Math.max(Number(req.query.limit || 50), 1), 200);
    const data = await prisma.auditLog.findMany({
      where: { userId: req.user.id },
      orderBy: { createdAt: "desc" },
      take: limit,
      select: { id: true, action: true, resource: true, method: true, path: true, statusCode: true, outcome: true, ipAddress: true, userAgent: true, createdAt: true },
    });
    res.json({ data });
  } catch (error) { next(error); }
});

resourceRouter.get("/consents", async (req, res, next) => {
  try {
    const consents = await prisma.consent.findMany({ where: { userId: req.user.id }, orderBy: { createdAt: "desc" } });
    const data = consents.map((consent) => ({ ...consent, scope: decryptWithFallback(consent.scopeEncrypted, consent.scope), granteeRef: decryptWithFallback(consent.granteeRefEncrypted, consent.granteeRef) }));
    res.json({ data });
  } catch (error) { next(error); }
});

resourceRouter.post("/consents", async (req, res, next) => {
  try {
    const schema = z.object({ scope: z.string().trim().min(1).max(200), granteeRef: z.string().max(200).optional(), expiresAt: z.string().datetime().optional() });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Invalid consent payload." });
    if (!isFieldEncryptionConfigured()) return res.status(503).json({ error: "Sensitive-data encryption is not configured." });
    const consent = await prisma.consent.create({ data: { userId: req.user.id, scope: null, granteeRef: null, scopeEncrypted: encryptOptional(parsed.data.scope), granteeRefEncrypted: encryptOptional(parsed.data.granteeRef), expiresAt: parsed.data.expiresAt ? new Date(parsed.data.expiresAt) : null } });
    res.status(201).json({ data: { ...consent, scope: parsed.data.scope, granteeRef: parsed.data.granteeRef || null } });
  } catch (error) { next(error); }
});

resourceRouter.get('/notifications', async (req, res, next) => {
  try {
    const data = await prisma.notification.findMany({ where: { userId: req.user.id }, orderBy: [{ readAt: 'asc' }, { scheduledFor: 'asc' }, { createdAt: 'desc' }], take: 100 });
    res.json({ data, unreadCount: data.filter(x => !x.readAt).length });
  } catch (error) { next(error); }
});
resourceRouter.patch('/notifications/:id/read', async (req, res, next) => {
  try {
    const existing = await prisma.notification.findFirst({ where: { id: req.params.id, userId: req.user.id } });
    if (!existing) return res.status(404).json({ error: 'Notification not found.' });
    const data = await prisma.notification.update({ where: { id: existing.id }, data: { readAt: existing.readAt || new Date() } });
    res.json({ data });
  } catch (error) { next(error); }
});
resourceRouter.post('/notifications/read-all', async (req, res, next) => {
  try {
    await prisma.notification.updateMany({ where: { userId: req.user.id, readAt: null }, data: { readAt: new Date() } });
    res.status(204).end();
  } catch (error) { next(error); }
});

resourceRouter.get('/notifications/push/public-key', async (req, res) => {
  res.json({ configured: Boolean(process.env.VAPID_PUBLIC_KEY), publicKey: process.env.VAPID_PUBLIC_KEY || null });
});

resourceRouter.post('/notifications/push/subscribe', async (req, res, next) => {
  try {
    const schema = z.object({ endpoint: z.string().url().max(2000), keys: z.object({ p256dh: z.string().min(10).max(500), auth: z.string().min(5).max(500) }) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Invalid push subscription.' });
    const { endpoint, keys } = parsed.data;
    const data = await prisma.pushSubscription.upsert({
      where: { endpoint },
      create: { userId: req.user.id, endpoint, p256dh: keys.p256dh, auth: keys.auth },
      update: { userId: req.user.id, p256dh: keys.p256dh, auth: keys.auth },
    });
    res.status(201).json({ data: { id: data.id, endpoint: data.endpoint } });
  } catch (error) { next(error); }
});

resourceRouter.delete('/notifications/push/subscribe', async (req, res, next) => {
  try {
    const schema = z.object({ endpoint: z.string().url().max(2000) });
    const parsed = schema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Valid endpoint is required.' });
    await prisma.pushSubscription.deleteMany({ where: { userId: req.user.id, endpoint: parsed.data.endpoint } });
    res.status(204).end();
  } catch (error) { next(error); }
});
