import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { validTimeZone, localDateKey, zonedLocalToUtc, addMinutesInZone } from "../lib/timezone.js";

const CALENDAR_COUNTRIES = {
  IN: {name:"India (national holidays)", fixed:[[1,26,"Republic Day"],[5,1,"Labour Day"],[8,15,"Independence Day"],[10,2,"Gandhi Jayanti"],[12,25,"Christmas Day"]]},
  US: {name:"United States (federal-style holidays)", fixed:[[1,1,"New Year's Day"],[6,19,"Juneteenth"],[7,4,"Independence Day"],[11,11,"Veterans Day"],[12,25,"Christmas Day"]]},
  GB: {name:"United Kingdom (selected bank holidays)", fixed:[[1,1,"New Year's Day"],[12,25,"Christmas Day"],[12,26,"Boxing Day"]]}
};
function dateOnlyUtc(y,m,d){ return new Date(Date.UTC(y,m-1,d)); }
function nthWeekday(y,m,weekday,n){ const first=dateOnlyUtc(y,m,1); const shift=(weekday-first.getUTCDay()+7)%7; return new Date(first.getTime()+((shift+7*(n-1))*86400000)); }
function lastWeekday(y,m,weekday){ const next=m===12?dateOnlyUtc(y+1,1,1):dateOnlyUtc(y,m+1,1); const last=new Date(next.getTime()-86400000); const shift=(last.getUTCDay()-weekday+7)%7; return new Date(last.getTime()-shift*86400000); }
function isoDate(d){ return d.toISOString().slice(0,10); }
function holidayCalendar(country, year){
  const c=CALENDAR_COUNTRIES[country]||CALENDAR_COUNTRIES.IN; const out=[];
  for(const [m,d,name] of c.fixed) out.push({dateKey:isoDate(dateOnlyUtc(year,m,d)),name,source:country});
  if(country==='IN'){ out.push({dateKey:isoDate(nthWeekday(year,1,1,4)),name:"Republic Day observed calendar note",source:country}); out.pop(); }
  if(country==='US'){ out.push({dateKey:isoDate(nthWeekday(year,1,1,3)),name:"Martin Luther King Jr. Day",source:country}); out.push({dateKey:isoDate(nthWeekday(year,2,1,3)),name:"Presidents' Day",source:country}); out.push({dateKey:isoDate(lastWeekday(year,5,1)),name:"Memorial Day",source:country}); out.push({dateKey:isoDate(nthWeekday(year,9,1,1)),name:"Labor Day",source:country}); out.push({dateKey:isoDate(nthWeekday(year,10,1,2)),name:"Columbus Day",source:country}); out.push({dateKey:isoDate(nthWeekday(year,11,4,4)),name:"Thanksgiving Day",source:country}); }
  if(country==='GB'){ out.push({dateKey:isoDate(nthWeekday(year,5,1,1)),name:"Early May Bank Holiday",source:country}); out.push({dateKey:isoDate(lastWeekday(year,5,1)),name:"Spring Bank Holiday",source:country}); out.push({dateKey:isoDate(lastWeekday(year,8,1)),name:"Summer Bank Holiday",source:country}); }
  return out.sort((a,b)=>a.dateKey.localeCompare(b.dateKey));
}

async function fetchOfficialHolidayCalendar(country, year){
  const base=String(process.env.HOLIDAY_API_BASE_URL||"https://date.nager.at/api/v3").replace(/\/$/,"");
  const url=`${base}/PublicHolidays/${year}/${encodeURIComponent(country)}`;
  const controller=new AbortController();
  const timeout=setTimeout(()=>controller.abort(), Math.min(15000, Math.max(1000, Number(process.env.HOLIDAY_API_TIMEOUT_MS)||8000)));
  try{
    const response=await fetch(url,{headers:{accept:"application/json"},signal:controller.signal});
    if(!response.ok) throw new Error(`Holiday API returned ${response.status}`);
    const json=await response.json();
    if(!Array.isArray(json)) throw new Error("Holiday API returned an invalid payload");
    return json.map(x=>({
      dateKey:String(x.date||"").slice(0,10),
      name:String(x.localName||x.name||"Public holiday").slice(0,240),
      source:`api:${new URL(url).host}`,
      observed:Boolean(x.counties?.length===0?false:x.types?.includes?.("Public holiday")),
      global:Boolean(x.global!==false)
    })).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.dateKey)&&x.global!==false);
  } finally { clearTimeout(timeout); }
}

async function resolveHolidayCalendar(country, year, source="api"){
  if(source==="built_in") return holidayCalendar(country,year);
  try{ return await fetchOfficialHolidayCalendar(country,year); }
  catch(error){
    if(source==="api_strict") throw error;
    return holidayCalendar(country,year).map(x=>({...x,source:`built-in:${country}`}));
  }
}

function ruleMatchesDate(rule,dateKey){
  const d=new Date(`${dateKey}T00:00:00Z`), start=new Date(`${rule.startDate}T00:00:00Z`);
  if(d<start) return false; if(rule.endDate && d>new Date(`${rule.endDate}T00:00:00Z`)) return false;
  if(rule.recurrence==='date_range') return true;
  if(rule.recurrence==='annual') return d.getUTCMonth()===start.getUTCMonth() && d.getUTCDate()===start.getUTCDate();
  if(rule.recurrence==='monthly') return d.getUTCDate()===start.getUTCDate();
  if(rule.recurrence==='weekly'){ const days=String(rule.daysOfWeek||'').split(',').map(Number).filter(Number.isInteger); return days.includes(d.getUTCDay()); }
  return false;
}

export const onCallRouter = Router();

function requireToken(req,res,next){
  const expected=process.env.ALERTMANAGER_WEBHOOK_TOKEN;
  const supplied=req.get("x-alertmanager-token");
  if(!expected || supplied!==expected) return res.status(401).json({error:"On-call management authentication failed."});
  next();
}
const text=(v,max=200)=>String(v??"").trim().slice(0,max);
function overlap(aStart,aEnd,bStart,bEnd){ return new Date(aStart)<new Date(bEnd) && new Date(aEnd)>new Date(bStart); }
async function coverageForRotation(rotationId,start,end){
  const shifts=await prisma.onCallShift.findMany({where:{rotationId,startsAt:{lt:end},endsAt:{gt:start}},orderBy:{startsAt:"asc"},include:{member:true}});
  const conflicts=[];
  for(let i=0;i<shifts.length;i++){
    const s=shifts[i];
    if(!s.member?.active) conflicts.push({type:"inactive_member",shiftId:s.id,memberId:s.memberId,message:"Shift is assigned to an inactive responder."});
    if(i && overlap(shifts[i-1].startsAt,shifts[i-1].endsAt,s.startsAt,s.endsAt)) conflicts.push({type:"overlap",shiftId:s.id,withShiftId:shifts[i-1].id,message:"Shift overlaps a previous shift."});
  }
  const gaps=[];
  let cursor=new Date(start);
  for(const s of shifts){
    const ss=new Date(s.startsAt), ee=new Date(s.endsAt);
    if(ee<=cursor) continue;
    if(ss>cursor) gaps.push({start:new Date(cursor),end:new Date(Math.min(ss.getTime(),new Date(end).getTime()))});
    if(ee>cursor) cursor=ee;
    if(cursor>=new Date(end)) break;
  }
  if(cursor<new Date(end)) gaps.push({start:new Date(cursor),end:new Date(end)});
  return {shifts,conflicts,gaps,covered:gaps.length===0&&conflicts.length===0};
}

onCallRouter.use(requireToken);

onCallRouter.get("/dashboard", async (_req,res,next)=>{
  try{
    const now=new Date();
    const [rotations, policies, activeShift, upcomingShifts]=await Promise.all([
      prisma.onCallRotation.findMany({orderBy:{name:"asc"},include:{members:{where:{active:true},orderBy:{name:"asc"}}}}),
      prisma.escalationPolicy.findMany({orderBy:{name:"asc"},include:{steps:{orderBy:{level:"asc"}}}}),
      prisma.onCallShift.findFirst({where:{startsAt:{lte:now},endsAt:{gt:now},status:{in:["scheduled","handed_off"]}},orderBy:{startsAt:"desc"},include:{member:true,rotation:true}}),
      prisma.onCallShift.findMany({where:{startsAt:{gte:now}},orderBy:{startsAt:"asc"},take:24,include:{member:true,rotation:true}})
    ]);
    res.json({data:{rotations,policies,activeShift,upcomingShifts}});
  }catch(e){next(e)}
});

onCallRouter.post("/rotations", async (req,res,next)=>{
  try{const name=text(req.body?.name); if(!name)return res.status(400).json({error:"name is required"}); const timezone=text(req.body?.timezone||"UTC",80)||"UTC"; if(!validTimeZone(timezone)) return res.status(400).json({error:"Invalid IANA timezone."}); const row=await prisma.onCallRotation.create({data:{name,timezone,active:req.body?.active!==false}}); res.status(201).json({data:row});}catch(e){next(e)}
});
onCallRouter.patch("/rotations/:id", async(req,res,next)=>{try{const row=await prisma.onCallRotation.update({where:{id:req.params.id},data:{...(req.body.name!==undefined?{name:text(req.body.name)}:{}),...(req.body.timezone!==undefined?(()=>{const timezone=text(req.body.timezone,80)||"UTC"; if(!validTimeZone(timezone)) throw new Error("Invalid IANA timezone."); return {timezone};})():{}),...(req.body.active!==undefined?{active:Boolean(req.body.active)}:{}),...(req.body.rotationMode!==undefined?{rotationMode:text(req.body.rotationMode,40)||"round_robin"}:{}),...(req.body.shiftDurationMinutes!==undefined?{shiftDurationMinutes:Math.min(10080,Math.max(30,Number(req.body.shiftDurationMinutes)||1440))}:{}),...(req.body.anchorAt!==undefined?{anchorAt:req.body.anchorAt?new Date(req.body.anchorAt):null}:{})}});res.json({data:row})}catch(e){next(e)}});
onCallRouter.post("/rotations/:id/members", async(req,res,next)=>{try{const name=text(req.body?.name);if(!name)return res.status(400).json({error:"member name is required"});const row=await prisma.onCallMember.create({data:{rotationId:req.params.id,name,email:text(req.body?.email,180)||null,phone:text(req.body?.phone,80)||null,role:text(req.body?.role,80)||null}});res.status(201).json({data:row})}catch(e){next(e)}});
onCallRouter.patch("/members/:id", async(req,res,next)=>{try{const row=await prisma.onCallMember.update({where:{id:req.params.id},data:{...(req.body.name!==undefined?{name:text(req.body.name)}:{}),...(req.body.email!==undefined?{email:text(req.body.email,180)||null}:{}),...(req.body.phone!==undefined?{phone:text(req.body.phone,80)||null}:{}),...(req.body.role!==undefined?{role:text(req.body.role,80)||null}:{}),...(req.body.active!==undefined?{active:Boolean(req.body.active)}:{})}});res.json({data:row})}catch(e){next(e)}});
onCallRouter.delete("/members/:id", async(req,res,next)=>{try{await prisma.onCallMember.delete({where:{id:req.params.id}});res.status(204).end()}catch(e){next(e)}});

onCallRouter.post("/shifts", async(req,res,next)=>{try{const rotationId=text(req.body?.rotationId,100),memberId=text(req.body?.memberId,100);const startsAt=new Date(req.body?.startsAt),endsAt=new Date(req.body?.endsAt);if(!rotationId||!memberId||Number.isNaN(startsAt.getTime())||Number.isNaN(endsAt.getTime())||endsAt<=startsAt)return res.status(400).json({error:"Valid rotation, member, startsAt and endsAt are required."});const member=await prisma.onCallMember.findUnique({where:{id:memberId}});if(!member||member.rotationId!==rotationId)return res.status(400).json({error:"Selected responder does not belong to this rotation."});if(!member.active)return res.status(400).json({error:"Selected responder is inactive."});const conflict=await prisma.onCallShift.findFirst({where:{rotationId,startsAt:{lt:endsAt},endsAt:{gt:startsAt},status:{not:"cancelled"}}});if(conflict)return res.status(409).json({error:"Shift conflicts with an existing shift in this rotation.",conflictShiftId:conflict.id});const row=await prisma.onCallShift.create({data:{rotationId,memberId,startsAt,endsAt,status:"scheduled"},include:{member:true,rotation:true}});res.status(201).json({data:row})}catch(e){next(e)}});
onCallRouter.delete("/shifts/:id", async(req,res,next)=>{try{await prisma.onCallShift.delete({where:{id:req.params.id}});res.status(204).end()}catch(e){next(e)}});

onCallRouter.post("/rotations/:id/generate-shifts", async(req,res,next)=>{
  try{
    const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id},include:{members:{where:{active:true},orderBy:{createdAt:"asc"}},overrides:{orderBy:{dateKey:"asc"}},recurringRules:{where:{active:true},orderBy:{startDate:"asc"}}}});
    if(!rotation) return res.status(404).json({error:"Rotation not found."});
    if(!rotation.members.length) return res.status(400).json({error:"Rotation has no active members."});
    if(!validTimeZone(rotation.timezone)) return res.status(400).json({error:"Rotation has an invalid IANA timezone."});
    const days=Math.min(90,Math.max(1,Number(req.body?.days)||14));
    const duration=Math.min(10080,Math.max(30,Number(req.body?.shiftDurationMinutes)||rotation.shiftDurationMinutes||1440));
    let startLocal=req.body?.startLocal;
    if(!startLocal && req.body?.startAt) startLocal=new Date(req.body.startAt).toISOString().slice(0,16);
    if(!startLocal && rotation.anchorAt){
      const d=rotation.anchorAt; const f=new Intl.DateTimeFormat('sv-SE',{timeZone:rotation.timezone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(d).replace(' ','T'); startLocal=f;
    }
    if(!startLocal) { const d=new Date(); const f=new Intl.DateTimeFormat('sv-SE',{timeZone:rotation.timezone,year:'numeric',month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',hourCycle:'h23'}).format(d).replace(' ','T'); startLocal=f; }
    let cursor=zonedLocalToUtc(startLocal,rotation.timezone);
    const existing=await prisma.onCallShift.findMany({where:{rotationId:rotation.id,endsAt:{gt:cursor}},orderBy:{startsAt:"asc"},select:{startsAt:true,endsAt:true}});
    if(existing.length) cursor=new Date(Math.max(cursor.getTime(),new Date(existing.at(-1).endsAt).getTime()));
    const count=Math.ceil((days*1440)/duration);
    const created=[]; let memberIndex=0;
    const overrides=rotation.overrides || [];
    for(let i=0;i<count;i++){
      const ends=addMinutesInZone(cursor,duration,rotation.timezone);
      const intended=rotation.members[memberIndex%rotation.members.length];
      const dateKey=localDateKey(cursor,rotation.timezone);
      const recurring=rotation.recurringRules.filter(r=>ruleMatchesDate(r,dateKey) && (r.memberId===null || r.memberId===intended.id));
      const applicable=[...overrides.filter(o=>o.dateKey===dateKey && (o.memberId===null || o.memberId===intended.id)), ...recurring.map(r=>({...r, memberId:r.memberId, replacementMemberId:r.replacementMemberId}))];
      let selected=intended;
      let skip=false;
      const ov=applicable.at(-1);
      if(ov){ if(ov.mode==='skip') skip=true; else if(ov.replacementMemberId){ selected=rotation.members.find(m=>m.id===ov.replacementMemberId) || intended; } else { selected=rotation.members.find(m=>m.id!==intended.id) || intended; } }
      const overlap=existing.some(x=>new Date(x.startsAt)<ends && new Date(x.endsAt)>cursor);
      if(!overlap && !skip){
        created.push(await prisma.onCallShift.create({data:{rotationId:rotation.id,memberId:selected.id,startsAt:new Date(cursor),endsAt:new Date(ends),status:"scheduled"},include:{member:true,rotation:true}}));
      }
      cursor=ends; memberIndex++;
    }
    res.status(201).json({data:created,meta:{days,durationMinutes:duration,createdCount:created.length,timezone:rotation.timezone,startLocal,overrideCount:overrides.length}});
  }catch(e){next(e)}
});

onCallRouter.get("/holiday-calendars", async(req,res,next)=>{ try{ const year=Math.min(2100,Math.max(2000,Number(req.query.year)||new Date().getUTCFullYear())); const country=String(req.query.country||"IN").toUpperCase(); const source=String(req.query.source||"api"); if(!/^[A-Z]{2}$/.test(country)) return res.status(400).json({error:"country must be an ISO 3166-1 alpha-2 code."}); const holidays=await resolveHolidayCalendar(country,year,source); res.json({data:{country,year,name:CALENDAR_COUNTRIES[country]?.name||`Public holidays (${country})`,source:source==="built_in"?"built-in":"official-api-with-fallback",holidays}}); }catch(e){next(e)} });

onCallRouter.get("/holiday-calendars/custom", async(req,res,next)=>{ try{ const rows=await prisma.onCallHolidayCalendar.findMany({where:{active:true},orderBy:{name:"asc"},include:{holidays:{orderBy:{dateKey:"asc"}}}}); res.json({data:rows}); }catch(e){next(e)} });
onCallRouter.post("/holiday-calendars/custom", async(req,res,next)=>{ try{ const name=text(req.body?.name,120); if(!name) return res.status(400).json({error:"Calendar name is required."}); const row=await prisma.onCallHolidayCalendar.create({data:{name,countryCode:text(req.body?.countryCode,2)?.toUpperCase()||null,timezone:text(req.body?.timezone,80)||"UTC",sourceType:text(req.body?.sourceType,20)||"custom",sourceUrl:text(req.body?.sourceUrl,500)||null}}); res.status(201).json({data:row}); }catch(e){next(e)} });
onCallRouter.post("/holiday-calendars/custom/:id/holidays", async(req,res,next)=>{ try{ const calendar=await prisma.onCallHolidayCalendar.findUnique({where:{id:req.params.id}}); if(!calendar) return res.status(404).json({error:"Custom calendar not found."}); const dateKey=text(req.body?.dateKey,10), name=text(req.body?.name,240); if(!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)||!name) return res.status(400).json({error:"dateKey (YYYY-MM-DD) and name are required."}); const row=await prisma.onCallHoliday.create({data:{calendarId:calendar.id,dateKey,name,observed:Boolean(req.body?.observed),source:text(req.body?.source,240)||"custom"}}); res.status(201).json({data:row}); }catch(e){ if(e?.code==='P2002') return res.status(409).json({error:"That holiday already exists in the calendar."}); next(e)} });
onCallRouter.delete("/holiday-calendars/custom/holidays/:id", async(req,res,next)=>{ try{ await prisma.onCallHoliday.delete({where:{id:req.params.id}}); res.status(204).end(); }catch(e){next(e)} });
onCallRouter.post("/holiday-calendars/custom/:id/sync", async(req,res,next)=>{ try{ const calendar=await prisma.onCallHolidayCalendar.findUnique({where:{id:req.params.id}}); if(!calendar) return res.status(404).json({error:"Custom calendar not found."}); if(calendar.sourceType!=="api" && !calendar.countryCode) return res.status(400).json({error:"API sync requires a countryCode or a custom source implementation."}); const year=Math.min(2100,Math.max(2000,Number(req.body?.year)||new Date().getUTCFullYear())); let holidays; if(calendar.sourceUrl){ const url=calendar.sourceUrl.replace(/\/$/,"").replace("{year}",String(year)).replace("{country}",encodeURIComponent(calendar.countryCode||"")); const response=await fetch(url,{headers:{accept:"application/json"}}); if(!response.ok) throw new Error(`Custom holiday source returned ${response.status}`); const json=await response.json(); holidays=(Array.isArray(json)?json:json.holidays||[]).map(x=>({dateKey:String(x.date||x.dateKey||"").slice(0,10),name:String(x.localName||x.name||"Public holiday").slice(0,240),observed:Boolean(x.observed),source:`api:${new URL(url).host}`})).filter(x=>/^\d{4}-\d{2}-\d{2}$/.test(x.dateKey)&&x.name); } else holidays=await fetchOfficialHolidayCalendar(calendar.countryCode,year); let created=0; for(const h of holidays){try{await prisma.onCallHoliday.create({data:{calendarId:calendar.id,dateKey:h.dateKey,name:h.name,observed:Boolean(h.observed),source:h.source||"api"}});created++;}catch(e){if(e?.code!=="P2002")throw e;}} res.status(201).json({data:{calendarId:calendar.id,year,createdCount:created,totalReturned:holidays.length}}); }catch(e){next(e)} });
onCallRouter.post("/rotations/:id/holiday-calendar/apply-custom", async(req,res,next)=>{ try{ const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id},include:{members:true}}); if(!rotation) return res.status(404).json({error:"Rotation not found."}); const calendar=await prisma.onCallHolidayCalendar.findUnique({where:{id:req.body?.calendarId},include:{holidays:{where:{dateKey:{gte:String(req.body?.startDate||"0000-01-01"),lte:String(req.body?.endDate||"9999-12-31")}},orderBy:{dateKey:"asc"}}}}); if(!calendar) return res.status(404).json({error:"Holiday calendar not found."}); const mode=['replace','skip'].includes(req.body?.mode)?req.body.mode:'replace'; const replacementMemberId=text(req.body?.replacementMemberId,100)||null; if(mode==='replace'&&!replacementMemberId) return res.status(400).json({error:"replacementMemberId is required for replace mode."}); if(replacementMemberId&&!rotation.members.some(m=>m.id===replacementMemberId&&m.active)) return res.status(400).json({error:"replacementMemberId must be an active rotation member."}); let created=0; for(const h of calendar.holidays){try{await prisma.onCallOverride.create({data:{rotationId:rotation.id,dateKey:h.dateKey,type:'holiday',memberId:null,replacementMemberId,mode,note:`${h.name} · ${calendar.name}`}});created++;}catch(e){if(e?.code!=="P2002")throw e;}} res.status(201).json({data:{calendarId:calendar.id,createdCount:created,totalHolidays:calendar.holidays.length}}); }catch(e){next(e)} });
onCallRouter.get("/rotations/:id/recurring-rules", async(req,res,next)=>{ try{ const rows=await prisma.onCallRecurringRule.findMany({where:{rotationId:req.params.id},orderBy:[{active:"desc"},{startDate:"asc"}],include:{member:true,replacementMember:true}}); res.json({data:rows}); }catch(e){next(e)} });
onCallRouter.post("/rotations/:id/recurring-rules", async(req,res,next)=>{ try{ const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id},include:{members:true}}); if(!rotation) return res.status(404).json({error:"Rotation not found."}); const type=text(req.body?.type,20).toLowerCase(); const recurrence=text(req.body?.recurrence,20).toLowerCase(); const mode=text(req.body?.mode,20).toLowerCase()||"replace"; const startDate=text(req.body?.startDate,20); const endDate=text(req.body?.endDate,20)||null; const memberId=text(req.body?.memberId,100)||null; const replacementMemberId=text(req.body?.replacementMemberId,100)||null; if(!['leave','holiday'].includes(type)) return res.status(400).json({error:"type must be leave or holiday."}); if(!['weekly','monthly','annual','date_range'].includes(recurrence)) return res.status(400).json({error:"recurrence must be weekly, monthly, annual or date_range."}); if(!/^\d{4}-\d{2}-\d{2}$/.test(startDate)) return res.status(400).json({error:"startDate must be YYYY-MM-DD."}); if(endDate && !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) return res.status(400).json({error:"endDate must be YYYY-MM-DD."}); if(type==='leave'&&!memberId) return res.status(400).json({error:"Leave rules require a memberId."}); if(memberId&&!rotation.members.some(m=>m.id===memberId)) return res.status(400).json({error:"memberId does not belong to this rotation."}); if(replacementMemberId&&!rotation.members.some(m=>m.id===replacementMemberId&&m.active)) return res.status(400).json({error:"replacementMemberId must be an active rotation member."}); const daysOfWeek=recurrence==='weekly'?String(req.body?.daysOfWeek||"").split(',').map(x=>Number(x)).filter(x=>x>=0&&x<=6).join(','):null; if(recurrence==='weekly'&&!daysOfWeek) return res.status(400).json({error:"Weekly rules require daysOfWeek."}); const row=await prisma.onCallRecurringRule.create({data:{rotationId:rotation.id,type,memberId,replacementMemberId,mode,recurrence,daysOfWeek,startDate,endDate,note:text(req.body?.note,500)||null,active:req.body?.active!==false},include:{member:true,replacementMember:true}}); res.status(201).json({data:row}); }catch(e){next(e)} });
onCallRouter.delete("/recurring-rules/:id", async(req,res,next)=>{ try{ await prisma.onCallRecurringRule.delete({where:{id:req.params.id}}); res.status(204).end(); }catch(e){next(e)} });
onCallRouter.post("/rotations/:id/holiday-calendar/apply", async(req,res,next)=>{ try{ const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id},include:{members:true}}); if(!rotation) return res.status(404).json({error:"Rotation not found."}); const country=String(req.body?.country||"IN").toUpperCase(); const year=Math.min(2100,Math.max(2000,Number(req.body?.year)||new Date().getUTCFullYear())); const source=String(req.body?.source||"api"); const mode=['replace','skip'].includes(req.body?.mode)?req.body.mode:'replace'; const replacementMemberId=text(req.body?.replacementMemberId,100)||null; if(mode==='replace'&&!replacementMemberId) return res.status(400).json({error:"replacementMemberId is required for replace mode."}); if(replacementMemberId&&!rotation.members.some(m=>m.id===replacementMemberId&&m.active)) return res.status(400).json({error:"replacementMemberId must be an active rotation member."}); const holidays=await resolveHolidayCalendar(country,year,source); let created=0; for(const h of holidays){ try{ await prisma.onCallOverride.create({data:{rotationId:rotation.id,dateKey:h.dateKey,type:'holiday',memberId:null,replacementMemberId,mode,note:`${h.name} · ${h.source||country}`}}); created++; }catch(e){ if(e?.code!=='P2002') throw e; } } res.status(201).json({data:{country,year,source,createdCount:created,totalHolidays:holidays.length}}); }catch(e){next(e)} });

onCallRouter.get("/rotations/:id/overrides", async(req,res,next)=>{
  try{const rows=await prisma.onCallOverride.findMany({where:{rotationId:req.params.id},orderBy:[{dateKey:"asc"},{createdAt:"asc"}],include:{member:true,replacementMember:true}});res.json({data:rows});}catch(e){next(e)}
});
onCallRouter.post("/rotations/:id/overrides", async(req,res,next)=>{
  try{
    const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id},include:{members:true}}); if(!rotation)return res.status(404).json({error:"Rotation not found."});
    const dateKey=text(req.body?.dateKey,20), type=text(req.body?.type,20).toLowerCase(), mode=text(req.body?.mode,20).toLowerCase()||"replace";
    if(!/^\d{4}-\d{2}-\d{2}$/.test(dateKey)) return res.status(400).json({error:"dateKey must be YYYY-MM-DD in the rotation timezone."});
    if(!['leave','holiday'].includes(type)) return res.status(400).json({error:"type must be leave or holiday."});
    if(!['replace','skip'].includes(mode)) return res.status(400).json({error:"mode must be replace or skip."});
    const memberId=text(req.body?.memberId,100)||null, replacementMemberId=text(req.body?.replacementMemberId,100)||null;
    if(memberId && !rotation.members.some(m=>m.id===memberId)) return res.status(400).json({error:"memberId does not belong to this rotation."});
    if(replacementMemberId && !rotation.members.some(m=>m.id===replacementMemberId && m.active)) return res.status(400).json({error:"replacementMemberId must be an active rotation member."});
    if(type==='leave' && !memberId) return res.status(400).json({error:"Leave overrides require a memberId."});
    if(mode==='replace' && !replacementMemberId && type==='holiday') return res.status(400).json({error:"Holiday replace overrides require a replacementMemberId."});
    const row=await prisma.onCallOverride.create({data:{rotationId:rotation.id,dateKey,type,memberId,replacementMemberId,mode,note:text(req.body?.note,500)||null},include:{member:true,replacementMember:true}});
    res.status(201).json({data:row});
  }catch(e){ if(e?.code==='P2002') return res.status(409).json({error:"An override of this type already exists for the selected date/member."}); next(e)}
});
onCallRouter.delete("/overrides/:id", async(req,res,next)=>{try{await prisma.onCallOverride.delete({where:{id:req.params.id}});res.status(204).end()}catch(e){next(e)}});

onCallRouter.post("/shifts/:id/handoff", async(req,res,next)=>{
  try{
    const current=await prisma.onCallShift.findUnique({where:{id:req.params.id},include:{rotation:{include:{members:{where:{active:true},orderBy:{createdAt:"asc"}}}},member:true}});
    if(!current) return res.status(404).json({error:"Shift not found."});
    const at=new Date(req.body?.handoffAt || new Date());
    if(Number.isNaN(at.getTime())) return res.status(400).json({error:"handoffAt must be a valid date."});
    if(at<new Date(current.startsAt) || at>=new Date(current.endsAt)) return res.status(400).json({error:"handoffAt must fall inside the current shift."});
    const members=current.rotation.members;
    if(members.length<2) return res.status(400).json({error:"A handoff requires at least two active rotation members."});
    const idx=Math.max(0,members.findIndex(m=>m.id===current.memberId));
    const next=members[(idx+1)%members.length];
    const note=text(req.body?.note,500)||null;
    const result=await prisma.$transaction([
      prisma.onCallShift.update({where:{id:current.id},data:{endsAt:at,status:"handed_off",handoffAt:at,handoffNote:note}}),
      prisma.onCallShift.create({data:{rotationId:current.rotationId,memberId:next.id,startsAt:at,endsAt:current.endsAt,status:"scheduled"},include:{member:true,rotation:true}})
    ]);
    res.status(201).json({data:{endedShift:result[0],newShift:result[1]}});
  }catch(e){next(e)}
});

onCallRouter.get("/rotations/:id/conflicts", async(req,res,next)=>{
  try{
    const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id}});
    if(!rotation) return res.status(404).json({error:"Rotation not found."});
    const start=req.query.startLocal ? zonedLocalToUtc(String(req.query.startLocal),rotation.timezone) : new Date(req.query.startAt || new Date());
    const days=Math.min(90,Math.max(1,Number(req.query.days)||14));
    const end=req.query.endLocal ? zonedLocalToUtc(String(req.query.endLocal),rotation.timezone) : addMinutesInZone(start,days*1440,rotation.timezone);
    if(Number.isNaN(start.getTime())) return res.status(400).json({error:"startAt must be a valid date."});
    const result=await coverageForRotation(rotation.id,start,end);
    res.json({data:{rotation,window:{start,end,days},...result,conflictCount:result.conflicts.length,gapCount:result.gaps.length}});
  }catch(e){next(e)}
});

onCallRouter.post("/rotations/:id/validate-coverage", async(req,res,next)=>{
  try{
    const rotation=await prisma.onCallRotation.findUnique({where:{id:req.params.id}});
    if(!rotation) return res.status(404).json({error:"Rotation not found."});
    const start=req.body?.startLocal ? zonedLocalToUtc(String(req.body.startLocal),rotation.timezone) : new Date(req.body?.startAt || new Date());
    const days=Math.min(90,Math.max(1,Number(req.body?.days)||14));
    const end=req.body?.endLocal ? zonedLocalToUtc(String(req.body.endLocal),rotation.timezone) : addMinutesInZone(start,days*1440,rotation.timezone);
    if(Number.isNaN(start.getTime())) return res.status(400).json({error:"startAt must be a valid date."});
    const result=await coverageForRotation(rotation.id,start,end);
    res.json({data:{rotationId:rotation.id,window:{start,end,days},covered:result.covered,conflicts:result.conflicts,gaps:result.gaps,shiftCount:result.shifts.length}});
  }catch(e){next(e)}
});

onCallRouter.post("/policies", async(req,res,next)=>{try{const name=text(req.body?.name);if(!name)return res.status(400).json({error:"policy name is required"});const steps=Array.isArray(req.body?.steps)?req.body.steps:[];const row=await prisma.escalationPolicy.create({data:{name,description:text(req.body?.description,500)||null,active:req.body?.active!==false,steps:{create:steps.map((x,i)=>({level:Number(x.level)||i+1,delayMinutes:Math.max(1,Number(x.delayMinutes)||15),targetType:text(x.targetType,40)||"webhook",targetRef:text(x.targetRef,240)||"default"}))}},include:{steps:{orderBy:{level:"asc"}}}});res.status(201).json({data:row})}catch(e){next(e)}});
onCallRouter.patch("/policies/:id", async(req,res,next)=>{try{const row=await prisma.escalationPolicy.update({where:{id:req.params.id},data:{...(req.body.name!==undefined?{name:text(req.body.name)}:{}),...(req.body.description!==undefined?{description:text(req.body.description,500)||null}:{}),...(req.body.active!==undefined?{active:Boolean(req.body.active)}:{})}});res.json({data:row})}catch(e){next(e)}});
onCallRouter.post("/policies/:id/steps", async(req,res,next)=>{try{const row=await prisma.escalationPolicyStep.create({data:{policyId:req.params.id,level:Math.max(1,Number(req.body?.level)||1),delayMinutes:Math.max(1,Number(req.body?.delayMinutes)||15),targetType:text(req.body?.targetType,40)||"webhook",targetRef:text(req.body?.targetRef,240)||"default"}});res.status(201).json({data:row})}catch(e){next(e)}});
onCallRouter.delete("/policy-steps/:id", async(req,res,next)=>{try{await prisma.escalationPolicyStep.delete({where:{id:req.params.id}});res.status(204).end()}catch(e){next(e)}});
