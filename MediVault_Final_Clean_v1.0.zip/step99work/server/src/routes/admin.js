import { Router } from "express";
import { prisma } from "../lib/prisma.js";

export const adminRouter = Router();

function requireOpsToken(req, res, next) {
  const expected = process.env.ALERTMANAGER_WEBHOOK_TOKEN;
  const supplied = req.get("x-alertmanager-token");
  if (!expected || !supplied || supplied !== expected) {
    return res.status(401).json({ error: "Operations endpoint authentication failed." });
  }
  next();
}

async function safeCount(delegate, where) {
  try { return await delegate.count(where ? { where } : undefined); }
  catch { return null; }
}


const RETENTION_RESOURCES = {
  auditLogs: { delegate: () => prisma.auditLog, dateField: "createdAt" },
  securityEvents: { delegate: () => prisma.securityEvent, dateField: "createdAt" },
  notifications: { delegate: () => prisma.notification, dateField: "createdAt" },
  sessions: { delegate: () => prisma.session, dateField: "createdAt" },
};

function retentionCutoff(days) {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - Number(days));
  return d;
}

adminRouter.get("/privacy/overview", requireOpsToken, async (_req, res, next) => {
  try {
    const [policies, requests, recentRuns] = await Promise.all([
      prisma.dataRetentionPolicy.findMany({ orderBy: { resource: "asc" } }),
      prisma.privacyRequest.findMany({ take: 50, orderBy: { requestedAt: "desc" }, select: { id:true,userId:true,type:true,status:true,requestedAt:true,acknowledgedAt:true,dueAt:true,resolvedAt:true,actor:true,notes:true } }),
      prisma.retentionRun.findMany({ take: 20, orderBy: { startedAt: "desc" } }),
    ]);
    const overdue = requests.filter(r => r.status !== "resolved" && r.dueAt && r.dueAt < new Date()).length;
    res.json({ data: { policies, requests, recentRuns, overdue, generatedAt: new Date().toISOString(), safety: { patientDataReturned:false, destructiveRetentionRequiresExplicitFlag:true } } });
  } catch (e) { next(e); }
});

adminRouter.post("/privacy/policies", requireOpsToken, async (req, res, next) => {
  try {
    const { resource, retentionDays, enabled=true, legalBasis, notes, actor="ops-admin" } = req.body || {};
    if (!RETENTION_RESOURCES[resource] || !Number.isInteger(Number(retentionDays)) || Number(retentionDays) < 1 || Number(retentionDays) > 36500) return res.status(400).json({ error:"Invalid retention policy." });
    const data = await prisma.dataRetentionPolicy.upsert({ where:{resource}, update:{retentionDays:Number(retentionDays),enabled:Boolean(enabled),legalBasis:legalBasis||null,notes:notes||null,updatedBy:actor}, create:{resource,retentionDays:Number(retentionDays),enabled:Boolean(enabled),legalBasis:legalBasis||null,notes:notes||null,updatedBy:actor} });
    res.status(201).json({ data });
  } catch (e) { next(e); }
});

adminRouter.post("/privacy/requests", requireOpsToken, async (req, res, next) => {
  try {
    const { userId, type="access", notes, dueDays=30, actor="ops-admin" } = req.body || {};
    const allowed=["access","export","delete","correct","restrict","withdraw-consent"];
    if (!userId || !allowed.includes(type)) return res.status(400).json({ error:"userId and valid request type are required." });
    const dueAt = new Date(); dueAt.setUTCDate(dueAt.getUTCDate() + Math.max(1,Math.min(365,Number(dueDays)||30)));
    const data = await prisma.privacyRequest.create({ data:{userId,type,notes:notes||null,dueAt,actor} });
    res.status(201).json({ data });
  } catch (e) { next(e); }
});

adminRouter.patch("/privacy/requests/:id", requireOpsToken, async (req,res,next)=>{
  try {
    const { status, notes, actor="ops-admin" }=req.body||{};
    const allowed=["submitted","acknowledged","in_progress","resolved","rejected"];
    if(status && !allowed.includes(status)) return res.status(400).json({error:"Invalid request status."});
    const data=await prisma.privacyRequest.update({where:{id:req.params.id},data:{...(status?{status}:{}),...(notes!==undefined?{notes}:{}),actor, ...(status==="acknowledged"?{acknowledgedAt:new Date()}:{}), ...(status==="resolved"?{resolvedAt:new Date()}: {})}});
    res.json({data});
  } catch(e){next(e);}
});

adminRouter.post("/privacy/retention/preview", requireOpsToken, async (req,res,next)=>{
  try {
    const { resource }=req.body||{};
    if(!RETENTION_RESOURCES[resource]) return res.status(400).json({error:"Unsupported retention resource."});
    const policy=await prisma.dataRetentionPolicy.findUnique({where:{resource}});
    if(!policy || !policy.enabled) return res.status(400).json({error:"No enabled retention policy configured."});
    const model=RETENTION_RESOURCES[resource]; const count=await model.delegate().count({where:{[model.dateField]:{lt:retentionCutoff(policy.retentionDays)}}});
    const run=await prisma.retentionRun.create({data:{resource,mode:"preview",matchedCount:count,summary:`Preview for ${resource}: ${count} records older than ${policy.retentionDays} days.`}});
    res.json({data:{resource,retentionDays:policy.retentionDays,matchedCount:count,run}});
  } catch(e){next(e);}
});

adminRouter.post("/privacy/retention/execute", requireOpsToken, async (req,res,next)=>{
  try {
    if(process.env.PRIVACY_RETENTION_EXECUTE !== "true") return res.status(403).json({error:"Destructive retention execution is disabled by policy. Set PRIVACY_RETENTION_EXECUTE=true only after legal/operational approval."});
    const { resource, actor="ops-admin" }=req.body||{};
    if(!RETENTION_RESOURCES[resource]) return res.status(400).json({error:"Unsupported retention resource."});
    const policy=await prisma.dataRetentionPolicy.findUnique({where:{resource}});
    if(!policy || !policy.enabled) return res.status(400).json({error:"No enabled retention policy configured."});
    const model=RETENTION_RESOURCES[resource], where={[model.dateField]:{lt:retentionCutoff(policy.retentionDays)}};
    const started=await prisma.retentionRun.create({data:{resource,mode:"execute",status:"running",actor}});
    let result;
    try { result=await model.delegate().deleteMany({where}); await prisma.retentionRun.update({where:{id:started.id},data:{matchedCount:result.count,deletedCount:result.count,status:"completed",completedAt:new Date(),summary:`Executed retention for ${resource}.`}}); }
    catch(e){await prisma.retentionRun.update({where:{id:started.id},data:{status:"failed",completedAt:new Date(),summary:e.message}});throw e;}
    res.json({data:{resource,deletedCount:result.count,retentionRunId:started.id}});
  } catch(e){next(e);}
});

adminRouter.get("/overview", requireOpsToken, async (_req, res, next) => {
  try {
    const [
      users, profiles, records, documents, medications, labs, vitals, vaccinations,
      goals, notifications, sessions, auditLogs, securityEvents,
      incidents, rotations, members, shifts, overrides, recurringRules,
      policies, backups,
    ] = await Promise.all([
      safeCount(prisma.user), safeCount(prisma.healthProfile), safeCount(prisma.medicalRecord),
      safeCount(prisma.document), safeCount(prisma.medication), safeCount(prisma.labReport),
      safeCount(prisma.vital), safeCount(prisma.vaccination), safeCount(prisma.healthGoal),
      safeCount(prisma.notification), safeCount(prisma.session), safeCount(prisma.auditLog),
      safeCount(prisma.securityEvent), safeCount(prisma.alertIncident), safeCount(prisma.onCallRotation),
      safeCount(prisma.onCallMember), safeCount(prisma.onCallShift), safeCount(prisma.onCallOverride),
      safeCount(prisma.onCallRecurringRule), safeCount(prisma.escalationPolicy), safeCount(prisma.backupJob),
    ]);

    const [openCritical, openIncidents, acknowledgedIncidents, activeRotations, activeSessions] = await Promise.all([
      safeCount(prisma.alertIncident, { status: "firing", severity: "critical" }),
      safeCount(prisma.alertIncident, { status: "firing" }),
      safeCount(prisma.alertIncident, { status: "firing", acknowledgedAt: { not: null } }),
      safeCount(prisma.onCallRotation, { active: true }),
      safeCount(prisma.session, { expiresAt: { gt: new Date() } }),
    ]);

    res.json({
      data: {
        generatedAt: new Date().toISOString(),
        scope: "operations-metadata-only",
        product: "MediVault",
        version: "step96",
        environment: process.env.NODE_ENV || "development",
        counts: {
          users, healthProfiles: profiles, medicalRecords: records, documents,
          medications, labReports: labs, vitals, vaccinations, healthGoals: goals,
          notifications, sessions, auditLogs, securityEvents,
          incidents, onCallRotations: rotations, onCallMembers: members,
          onCallShifts: shifts, onCallOverrides: overrides, recurringRules,
          escalationPolicies: policies, backups,
        },
        operations: { openCritical, openIncidents, acknowledgedIncidents, activeRotations, activeSessions },
        safety: {
          patientDataReturned: false,
          secretsReturned: false,
          readOnly: true,
        },
      },
    });
  } catch (error) { next(error); }
});
