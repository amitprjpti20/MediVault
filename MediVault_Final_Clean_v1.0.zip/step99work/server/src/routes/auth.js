import { Router } from "express";
import crypto from "node:crypto";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { SESSION_COOKIE, createSession, getUserFromToken, hashPassword, revokeSession, sessionTokenHash, verifyPassword } from "../lib/auth.js";
import { sendTransactionalEmail } from "../lib/notificationDelivery.js";
import { createAuthBruteForceGuard, createRateLimiter } from "../middleware/rateLimit.js";
import { encryptSecret, decryptSecret, randomBase32, verifyTotp, makeRecoveryCodes, hashRecoveryCode, makeOpaqueToken } from "../lib/mfa.js";
import { recordSecurityEvent } from "../lib/securityEvents.js";

export const authRouter = Router();

const loginGuard = createAuthBruteForceGuard({
  windowMs: Number(process.env.AUTH_FAILURE_WINDOW_MS || 15 * 60_000),
  maxAttempts: Number(process.env.AUTH_MAX_FAILURES || 8),
  blockMs: Number(process.env.AUTH_BLOCK_MS || 15 * 60_000),
});
const authEndpointLimiter = createRateLimiter({
  windowMs: Number(process.env.AUTH_RATE_WINDOW_MS || 60_000),
  max: Number(process.env.AUTH_RATE_MAX || 30),
  keyPrefix: "auth-api",
});

authRouter.use(authEndpointLimiter);

async function writeAuthAudit(req, { userId = null, action, statusCode, outcome }) {
  try {
    await prisma.auditLog.create({
      data: {
        userId,
        action,
        resource: "auth",
        method: req.method,
        path: (req.originalUrl || req.path || "").slice(0, 500),
        statusCode,
        outcome,
        ipAddress: req.ip || req.socket?.remoteAddress || null,
        userAgent: req.get("user-agent")?.slice(0, 512) || null,
      },
    });
  } catch (error) {
    console.error("Auth audit log write failed:", error.message);
  }
}

const credentialsSchema = z.object({
  email: z.string().email().max(320),
  password: z.string().min(8).max(128),
  name: z.string().trim().min(1).max(100).optional(),
});

const publicUser = (user) => ({ id: user.id, email: user.email, name: user.name, emailVerified: user.emailVerified, createdAt: user.createdAt });
const MFA_COOKIE = "medivault_trusted_device";
const mfaChallengeMinutes = () => Number(process.env.MFA_CHALLENGE_MINUTES || 5);
const trustedDeviceDays = () => Number(process.env.TRUSTED_DEVICE_DAYS || 30);
function setTrustedDeviceCookie(res, token, expiresAt){ res.cookie(MFA_COOKIE, token, { httpOnly:true, secure:process.env.NODE_ENV === "production", sameSite:process.env.COOKIE_SAMESITE || "lax", expires:expiresAt, path:"/" }); }
function clearTrustedDeviceCookie(res){ res.clearCookie(MFA_COOKIE,{httpOnly:true,secure:process.env.NODE_ENV === "production",sameSite:process.env.COOKIE_SAMESITE || "lax",path:"/"}); }
const hashToken = (token) => crypto.createHash("sha256").update(token).digest("hex");
const makeToken = () => crypto.randomBytes(32).toString("base64url");
const verificationHours = () => Number(process.env.EMAIL_VERIFICATION_HOURS || 24);
const resetMinutes = () => Number(process.env.PASSWORD_RESET_MINUTES || 30);
const appUrl = () => (process.env.APP_URL || "http://localhost:5173").replace(/\/$/, "");

async function issueVerification(user) {
  const token = makeToken();
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + verificationHours() * 3600_000);
  await prisma.emailVerificationToken.deleteMany({ where: { userId: user.id, usedAt: null } });
  await prisma.emailVerificationToken.create({ data: { userId: user.id, tokenHash, expiresAt } });
  const url = `${appUrl()}/?verify=${encodeURIComponent(token)}`;
  return sendTransactionalEmail({ to: user.email, subject: "Verify your MediVault email", text: `Welcome to MediVault. Verify your email:\n\n${url}\n\nThis link expires in ${verificationHours()} hour(s). If you did not create this account, ignore this email.` });
}

async function issuePasswordReset(user) {
  const token = makeToken();
  const tokenHash = hashToken(token);
  const expiresAt = new Date(Date.now() + resetMinutes() * 60_000);
  await prisma.passwordResetToken.deleteMany({ where: { userId: user.id, usedAt: null } });
  await prisma.passwordResetToken.create({ data: { userId: user.id, tokenHash, expiresAt } });
  const url = `${appUrl()}/?reset=${encodeURIComponent(token)}`;
  return sendTransactionalEmail({ to: user.email, subject: "Reset your MediVault password", text: `A password reset was requested for your MediVault account.\n\nReset your password here:\n${url}\n\nThis link expires in ${resetMinutes()} minutes. If you did not request this, ignore this email.` });
}

function setSessionCookie(res, token, expiresAt) {
  res.cookie(SESSION_COOKIE, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: process.env.COOKIE_SAMESITE || "lax",
    expires: expiresAt,
    path: "/",
  });
}

async function getMfaSetting(userId){ return prisma.mfaSetting.findUnique({where:{userId}}); }
async function trustedDeviceUser(req){ const raw=req.cookies?.[MFA_COOKIE]; if(!raw) return null; const d=await prisma.trustedDevice.findUnique({where:{tokenHash:hashToken(raw)},include:{user:true}}); if(!d || d.expiresAt<=new Date()) { if(d) await prisma.trustedDevice.delete({where:{id:d.id}}).catch(()=>{}); return null; } await prisma.trustedDevice.update({where:{id:d.id},data:{lastUsedAt:new Date()}}); return d.user; }
async function createMfaChallenge(userId){ const token=makeOpaqueToken(); const expiresAt=new Date(Date.now()+mfaChallengeMinutes()*60000); await prisma.mfaLoginChallenge.deleteMany({where:{userId,usedAt:null}}); await prisma.mfaLoginChallenge.create({data:{userId,tokenHash:hashToken(token),expiresAt}}); return {token,expiresAt}; }

authRouter.post("/register", async (req, res, next) => {
  try {
    const parsed = credentialsSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Valid email and password (8+ characters) are required." });
    const { email, password, name } = parsed.data;
    const normalizedEmail = email.trim().toLowerCase();
    const exists = await prisma.user.findUnique({ where: { email: normalizedEmail } });
    if (exists) { await writeAuthAudit(req, { action: "AUTH_REGISTER", statusCode: 409, outcome: "failure" }); return res.status(409).json({ error: "An account with this email already exists." }); }
    const user = await prisma.user.create({ data: { email: normalizedEmail, name: name || null, passwordHash: await hashPassword(password), emailVerified: false } });
    const delivery = await issueVerification(user);
    await writeAuthAudit(req, { userId: user.id, action: "AUTH_REGISTER", statusCode: 201, outcome: "success" });
    return res.status(201).json({ user: publicUser(user), verificationSent: delivery.sent, verificationRequired: process.env.REQUIRE_EMAIL_VERIFICATION !== "false" });
  } catch (error) { return next(error); }
});

authRouter.post("/login", loginGuard, async (req, res, next) => {
  try {
    const parsed = credentialsSchema.pick({ email: true, password: true }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: "Valid email and password are required." });
    const normalizedEmail = parsed.data.email.trim().toLowerCase();
    const user = await prisma.user.findUnique({ where: { email: normalizedEmail } });
    if (!user || !(await verifyPassword(parsed.data.password, user.passwordHash))) {
      res.locals.recordAuthFailure?.();
      await writeAuthAudit(req, { userId: user?.id || null, action: "AUTH_LOGIN", statusCode: 401, outcome: "failure" });
      return res.status(401).json({ error: "Invalid email or password." });
    }
    if (process.env.REQUIRE_EMAIL_VERIFICATION !== "false" && !user.emailVerified) {
      return res.status(403).json({ error: "Please verify your email before signing in.", code: "EMAIL_NOT_VERIFIED" });
    }
    res.locals.clearAuthFailures?.();
    const mfa = await getMfaSetting(user.id);
    const trusted = await trustedDeviceUser(req);
    if (mfa?.enabled && !trusted) {
      const challenge = await createMfaChallenge(user.id);
      return res.json({ mfaRequired: true, challenge: challenge.token, challengeExpiresAt: challenge.expiresAt });
    }
    const session = await createSession(user.id, req);
    setSessionCookie(res, session.token, session.expiresAt);
    await writeAuthAudit(req, { userId: user.id, action: trusted ? "AUTH_LOGIN_TRUSTED_DEVICE" : "AUTH_LOGIN", statusCode: 200, outcome: "success" });
    return res.json({ user: publicUser(user), mfaBypassedByTrustedDevice: Boolean(trusted) });
  } catch (error) { return next(error); }
});

authRouter.get("/verify-email", async (req, res, next) => {
  try {
    const token = String(req.query.token || "");
    if (!token) return res.status(400).json({ error: "Verification token is required." });
    const record = await prisma.emailVerificationToken.findUnique({ where: { tokenHash: hashToken(token) } });
    if (!record || record.usedAt || record.expiresAt <= new Date()) return res.status(400).json({ error: "This verification link is invalid or expired." });
    const user = await prisma.user.update({ where: { id: record.userId }, data: { emailVerified: true } });
    await prisma.emailVerificationToken.update({ where: { id: record.id }, data: { usedAt: new Date() } });
    await prisma.session.deleteMany({ where: { userId: user.id } });
    await writeAuthAudit(req, { userId: user.id, action: "AUTH_EMAIL_VERIFY", statusCode: 200, outcome: "success" });
    return res.json({ ok: true, user: publicUser(user) });
  } catch (error) { next(error); }
});

authRouter.post("/resend-verification", async (req, res, next) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    const user = await prisma.user.findUnique({ where: { email } });
    // Avoid account enumeration. Always return the same response.
    if (user && !user.emailVerified) await issueVerification(user);
    return res.json({ ok: true, message: "If the account exists and needs verification, a new email has been sent." });
  } catch (error) { next(error); }
});

authRouter.post("/request-password-reset", async (req, res, next) => {
  try {
    const email = String(req.body?.email || "").trim().toLowerCase();
    if (!email) return res.status(400).json({ error: "Email is required." });
    const user = await prisma.user.findUnique({ where: { email } });
    if (user) await issuePasswordReset(user);
    return res.json({ ok: true, message: "If the account exists, password reset instructions have been sent." });
  } catch (error) { next(error); }
});

authRouter.post("/reset-password", async (req, res, next) => {
  try {
    const token = String(req.body?.token || "");
    const password = String(req.body?.password || "");
    if (!token || password.length < 8 || password.length > 128) return res.status(400).json({ error: "A valid token and an 8–128 character password are required." });
    const record = await prisma.passwordResetToken.findUnique({ where: { tokenHash: hashToken(token) } });
    if (!record || record.usedAt || record.expiresAt <= new Date()) return res.status(400).json({ error: "This reset link is invalid or expired." });
    await prisma.user.update({ where: { id: record.userId }, data: { passwordHash: await hashPassword(password) } });
    await prisma.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } });
    await prisma.session.deleteMany({ where: { userId: record.userId } });
    await writeAuthAudit(req, { userId: record.userId, action: "AUTH_PASSWORD_RESET", statusCode: 200, outcome: "success" });
    return res.json({ ok: true, message: "Password updated. Please sign in again." });
  } catch (error) { next(error); }
});

authRouter.get("/mfa/status", async (req,res,next)=>{
 try{ const {getUserFromToken}=await import("../lib/auth.js"); const user=await getUserFromToken(req.cookies?.[SESSION_COOKIE]); if(!user) return res.status(401).json({error:"Authentication required"}); const mfa=await getMfaSetting(user.id); const trusted=await prisma.trustedDevice.findMany({where:{userId:user.id,expiresAt:{gt:new Date()}},orderBy:{lastUsedAt:"desc"},select:{id,label,lastUsedAt,expiresAt,createdAt}}); return res.json({enabled:Boolean(mfa?.enabled),devices:trusted}); }catch(e){next(e)}
});

authRouter.post("/mfa/setup", async (req,res,next)=>{
 try{ const {getUserFromToken}=await import("../lib/auth.js"); const user=await getUserFromToken(req.cookies?.[SESSION_COOKIE]); if(!user) return res.status(401).json({error:"Authentication required"}); const existing=await getMfaSetting(user.id); if(existing?.enabled) return res.status(409).json({error:"MFA is already enabled."}); const secret=randomBase32(20); const encrypted=encryptSecret(secret); const recovery=makeRecoveryCodes(8); await prisma.mfaSetting.upsert({where:{userId:user.id},create:{userId:user.id,secretEncrypted:encrypted,enabled:false,recoveryCodeHashes:recovery.map(hashRecoveryCode)},update:{secretEncrypted:encrypted,enabled:false,recoveryCodeHashes:recovery.map(hashRecoveryCode)}}); const issuer=encodeURIComponent("MediVault"); const account=encodeURIComponent(user.email); const otpauth=`otpauth://totp/${issuer}:${account}?secret=${secret}&issuer=${issuer}&algorithm=SHA1&digits=6&period=30`; return res.json({secret,otpauth,recoveryCodes:recovery}); }catch(e){next(e)}
});

authRouter.post("/mfa/enable", async (req,res,next)=>{
 try{ const {getUserFromToken}=await import("../lib/auth.js"); const user=await getUserFromToken(req.cookies?.[SESSION_COOKIE]); if(!user) return res.status(401).json({error:"Authentication required"}); const mfa=await getMfaSetting(user.id); if(!mfa) return res.status(400).json({error:"Start MFA setup first."}); const secret=decryptSecret(mfa.secretEncrypted); if(!verifyTotp(secret,req.body?.code)) return res.status(400).json({error:"Invalid authenticator code."}); await prisma.mfaSetting.update({where:{userId:user.id},data:{enabled:true}}); await writeAuthAudit(req,{userId:user.id,action:"MFA_ENABLED",statusCode:200,outcome:"success"}); return res.json({ok:true,enabled:true}); }catch(e){next(e)}
});

authRouter.post("/mfa/verify-login", async (req,res,next)=>{
 try{ const token=String(req.body?.challenge||""); const code=String(req.body?.code||""); if(!token||!code) return res.status(400).json({error:"Challenge and authenticator code are required."}); const challenge=await prisma.mfaLoginChallenge.findUnique({where:{tokenHash:hashToken(token)},include:{user:true}}); if(!challenge||challenge.usedAt||challenge.expiresAt<=new Date()) return res.status(400).json({error:"MFA challenge is invalid or expired."}); const mfa=await getMfaSetting(challenge.userId); if(!mfa?.enabled) return res.status(400).json({error:"MFA is not enabled."}); let ok=verifyTotp(decryptSecret(mfa.secretEncrypted),code); let recoveryIndex=-1; const hashes=Array.isArray(mfa.recoveryCodeHashes)?mfa.recoveryCodeHashes:[]; if(!ok){ const hash=hashRecoveryCode(code); recoveryIndex=hashes.indexOf(hash); ok=recoveryIndex>=0; } if(!ok){ await recordSecurityEvent({userId:challenge.userId,type:"mfa_failure",severity:"high",action:"MFA_LOGIN_FAILED",resource:"auth",statusCode:401,ipAddress:req.ip||req.socket?.remoteAddress||null,userAgent:req.get("user-agent")}); return res.status(401).json({error:"Invalid MFA code."}); } const nextHashes=recoveryIndex>=0?hashes.filter((_,i)=>i!==recoveryIndex):hashes; await prisma.$transaction([prisma.mfaLoginChallenge.update({where:{id:challenge.id},data:{usedAt:new Date()}}),prisma.mfaSetting.update({where:{userId:challenge.userId},data:{recoveryCodeHashes:nextHashes}})]); const session=await createSession(challenge.userId, req); setSessionCookie(res,session.token,session.expiresAt); if(req.body?.trustDevice){ const raw=makeOpaqueToken(); const expiresAt=new Date(Date.now()+trustedDeviceDays()*86400000); await prisma.trustedDevice.create({data:{userId:challenge.userId,tokenHash:hashToken(raw),label:String(req.body?.deviceLabel||"This device").slice(0,100),userAgent:req.get("user-agent")?.slice(0,512)||null,expiresAt}}); setTrustedDeviceCookie(res,raw,expiresAt); } await writeAuthAudit(req,{userId:challenge.userId,action:recoveryIndex>=0?"MFA_RECOVERY_LOGIN":"MFA_LOGIN",statusCode:200,outcome:"success"}); return res.json({user:publicUser(challenge.user),recoveryCodeUsed:recoveryIndex>=0}); }catch(e){next(e)}
});

authRouter.post("/mfa/disable", async (req,res,next)=>{
 try{ const {getUserFromToken}=await import("../lib/auth.js"); const user=await getUserFromToken(req.cookies?.[SESSION_COOKIE]); if(!user) return res.status(401).json({error:"Authentication required"}); const mfa=await getMfaSetting(user.id); if(!mfa?.enabled) return res.json({ok:true,enabled:false}); if(!verifyTotp(decryptSecret(mfa.secretEncrypted),req.body?.code)) return res.status(400).json({error:"Invalid authenticator code."}); await prisma.$transaction([prisma.mfaSetting.update({where:{userId:user.id},data:{enabled:false}}),prisma.trustedDevice.deleteMany({where:{userId:user.id}})]); clearTrustedDeviceCookie(res); await writeAuthAudit(req,{userId:user.id,action:"MFA_DISABLED",statusCode:200,outcome:"success"}); return res.json({ok:true,enabled:false}); }catch(e){next(e)}
});

authRouter.delete("/mfa/trusted-devices/:id", async (req,res,next)=>{
 try{ const {getUserFromToken}=await import("../lib/auth.js"); const user=await getUserFromToken(req.cookies?.[SESSION_COOKIE]); if(!user) return res.status(401).json({error:"Authentication required"}); const d=await prisma.trustedDevice.findFirst({where:{id:req.params.id,userId:user.id}}); if(!d) return res.status(404).json({error:"Trusted device not found."}); await prisma.trustedDevice.delete({where:{id:d.id}}); return res.json({ok:true}); }catch(e){next(e)}
});

authRouter.get("/sessions", async (req, res, next) => {
  try {
    const currentToken = req.cookies?.[SESSION_COOKIE];
    const currentHash = sessionTokenHash(currentToken || "");
    const user = await getUserFromToken(currentToken);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const sessions = await prisma.session.findMany({
      where: { userId: user.id, expiresAt: { gt: new Date() } },
      orderBy: { lastUsedAt: "desc" },
      select: { id: true, createdAt: true, lastUsedAt: true, expiresAt: true, ipAddress: true, userAgent: true, tokenHash: true }
    });
    return res.json({ data: sessions.map(s => ({ id:s.id, createdAt:s.createdAt, lastUsedAt:s.lastUsedAt, expiresAt:s.expiresAt, ipAddress:s.ipAddress, userAgent:s.userAgent, current:s.tokenHash===currentHash })) });
  } catch (error) { next(error); }
});

authRouter.delete("/sessions/:id", async (req, res, next) => {
  try {
    const user = await getUserFromToken(req.cookies?.[SESSION_COOKIE]);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const session = await prisma.session.findFirst({ where: { id:req.params.id, userId:user.id } });
    if (!session) return res.status(404).json({ error: "Session not found." });
    const currentHash = sessionTokenHash(req.cookies?.[SESSION_COOKIE] || "");
    if (session.tokenHash === currentHash) return res.status(400).json({ error: "Use Sign out for the current session." });
    await prisma.session.delete({ where: { id: session.id } });
    await writeAuthAudit(req,{userId:user.id,action:"SESSION_REVOKED",statusCode:200,outcome:"success",resource:"session",resourceId:session.id});
    return res.json({ ok:true });
  } catch (error) { next(error); }
});

authRouter.post("/sessions/revoke-others", async (req, res, next) => {
  try {
    const token = req.cookies?.[SESSION_COOKIE];
    const user = await getUserFromToken(token);
    if (!user) return res.status(401).json({ error: "Authentication required." });
    const currentHash = sessionTokenHash(token || "");
    const deleted = await prisma.session.deleteMany({ where: { userId:user.id, NOT:{ tokenHash:currentHash } } });
    await writeAuthAudit(req,{userId:user.id,action:"SESSIONS_REVOKE_OTHERS",statusCode:200,outcome:"success",resource:"session"});
    return res.json({ ok:true, revoked:deleted.count });
  } catch (error) { next(error); }
});

authRouter.post("/logout", async (req, res, next) => {
  try {
    const { getUserFromToken } = await import("../lib/auth.js");
    const currentUser = await getUserFromToken(req.cookies?.[SESSION_COOKIE]);
    await revokeSession(req.cookies?.[SESSION_COOKIE]);
    clearTrustedDeviceCookie(res);
    res.clearCookie(SESSION_COOKIE, { httpOnly: true, secure: process.env.NODE_ENV === "production", sameSite: process.env.COOKIE_SAMESITE || "lax", path: "/" });
    await writeAuthAudit(req, { userId: currentUser?.id || null, action: "AUTH_LOGOUT", statusCode: 200, outcome: "success" });
    return res.json({ ok: true });
  } catch (error) { return next(error); }
});

authRouter.get("/me", async (req, res, next) => {
  try {
    const { getUserFromToken } = await import("../lib/auth.js");
    const user = await getUserFromToken(req.cookies?.[SESSION_COOKIE]);
    if (!user) return res.status(401).json({ error: "Authentication required" });
    return res.json({ user: publicUser(user) });
  } catch (error) { return next(error); }
});
