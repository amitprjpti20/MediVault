import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { getMetrics } from "../lib/metrics.js";

export const healthRouter = Router();

healthRouter.get("/", (_req, res) => res.json({ ok: true, service: "medivault-api", time: new Date().toISOString() }));
healthRouter.get("/live", (_req, res) => res.status(200).json({ ok: true, status: "live", time: new Date().toISOString() }));
healthRouter.get("/ready", async (_req, res) => {
  try {
    await prisma.$queryRaw`SELECT 1`;
    res.status(200).json({ ok: true, status: "ready", dependencies: { postgres: "ok" }, time: new Date().toISOString() });
  } catch {
    res.status(503).json({ ok: false, status: "not-ready", dependencies: { postgres: "unavailable" }, time: new Date().toISOString() });
  }
});
healthRouter.get("/metrics", (_req, res) => res.json({ ok: true, ...getMetrics() }));
