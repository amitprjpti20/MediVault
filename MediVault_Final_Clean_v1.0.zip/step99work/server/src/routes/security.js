import { Router } from 'express';
import { SESSION_COOKIE, getUserFromToken } from '../lib/auth.js';
import { listSecurityEvents } from '../lib/securityEvents.js';

export const securityRouter=Router();

securityRouter.use(async (req,res,next)=>{
  try{
    const user=await getUserFromToken(req.cookies?.[SESSION_COOKIE]);
    if(!user) return res.status(401).json({error:'Authentication required.'});
    req.securityUser=user; next();
  }catch(error){next(error)}
});

securityRouter.get('/events', async (req,res,next)=>{
  try{
    const data=await listSecurityEvents(req.securityUser.id,{limit:req.query.limit,sinceDays:req.query.sinceDays});
    res.json({data});
  }catch(error){next(error)}
});
