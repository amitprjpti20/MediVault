import { Router } from 'express';
import { renderPrometheusMetrics } from '../lib/metrics.js';

export const metricsRouter = Router();

metricsRouter.get('/', (req, res) => {
  const configuredToken = process.env.METRICS_TOKEN?.trim();
  if (configuredToken && req.get('authorization') !== `Bearer ${configuredToken}`) {
    return res.status(401).type('text/plain').send('Unauthorized\\n');
  }
  res.set('Content-Type', 'text/plain; version=0.0.4; charset=utf-8');
  res.send(renderPrometheusMetrics());
});
