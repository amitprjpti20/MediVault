import { Router } from 'express';
import { getUserFromToken, SESSION_COOKIE } from '../lib/auth.js';
import { getPerformance } from '../lib/performance.js';

export const performanceRouter = Router();

performanceRouter.use(async (req, res, next) => {
  try {
    const user = await getUserFromToken(req.cookies?.[SESSION_COOKIE]);
    if (!user) return res.status(401).json({ error: 'Authentication required.' });
    req.performanceUser = user;
    next();
  } catch (error) { next(error); }
});

performanceRouter.get('/', (_req, res) => res.json({ data: getPerformance() }));
