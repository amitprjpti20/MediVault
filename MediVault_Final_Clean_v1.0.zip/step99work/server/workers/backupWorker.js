import 'dotenv/config';
import cron from 'node-cron';
import { spawn } from 'node:child_process';

const enabled = process.env.BACKUP_SCHEDULER_ENABLED === 'true';
if (!enabled) {
  console.log('Backup scheduler disabled. Set BACKUP_SCHEDULER_ENABLED=true to enable.');
  process.exit(0);
}

const schedule = process.env.BACKUP_CRON || '0 2 * * *';
if (!cron.validate(schedule)) throw new Error(`Invalid BACKUP_CRON: ${schedule}`);
const command = process.platform === 'win32' ? 'npm.cmd' : 'npm';

function runBackup() {
  console.log(`[backup-worker] Starting backup at ${new Date().toISOString()}`);
  const child = spawn(command, ['run', 'db:backup-upload'], { stdio: 'inherit', env: process.env });
  child.on('exit', code => {
    if (code === 0) console.log('[backup-worker] Backup completed successfully.');
    else console.error(`[backup-worker] Backup failed with code ${code ?? 'unknown'}.`);
  });
}

console.log(`[backup-worker] Scheduler enabled: ${schedule}`);
if (process.env.BACKUP_RUN_ON_START === 'true') runBackup();
cron.schedule(schedule, runBackup, { timezone: process.env.BACKUP_TIMEZONE || 'Asia/Kolkata' });
