ALTER TABLE "OnCallRotation" ADD COLUMN "rotationMode" TEXT NOT NULL DEFAULT 'round_robin';
ALTER TABLE "OnCallRotation" ADD COLUMN "shiftDurationMinutes" INTEGER NOT NULL DEFAULT 1440;
ALTER TABLE "OnCallRotation" ADD COLUMN "anchorAt" TIMESTAMP(3);
ALTER TABLE "OnCallShift" ADD COLUMN "handoffNote" TEXT;
ALTER TABLE "OnCallShift" ADD COLUMN "handoffAt" TIMESTAMP(3);
