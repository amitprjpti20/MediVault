ALTER TABLE "MedicalRecord" ADD COLUMN "typeEncrypted" TEXT;
ALTER TABLE "MedicalRecord" ADD COLUMN "titleEncrypted" TEXT;
ALTER TABLE "MedicalRecord" ADD COLUMN "summaryEncrypted" TEXT;

ALTER TABLE "Consent" ADD COLUMN "scopeEncrypted" TEXT;
ALTER TABLE "Consent" ADD COLUMN "granteeRefEncrypted" TEXT;

ALTER TABLE "MedicalRecord" ALTER COLUMN "type" DROP NOT NULL;
ALTER TABLE "MedicalRecord" ALTER COLUMN "title" DROP NOT NULL;
ALTER TABLE "Consent" ALTER COLUMN "scope" DROP NOT NULL;
