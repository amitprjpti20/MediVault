CREATE TABLE "OnCallOverride" (
  "id" TEXT NOT NULL,
  "rotationId" TEXT NOT NULL,
  "dateKey" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "memberId" TEXT,
  "replacementMemberId" TEXT,
  "mode" TEXT NOT NULL DEFAULT 'replace',
  "note" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallOverride_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "OnCallOverride_rotationId_dateKey_type_memberId_key" ON "OnCallOverride"("rotationId","dateKey","type","memberId");
CREATE INDEX "OnCallOverride_rotationId_dateKey_idx" ON "OnCallOverride"("rotationId","dateKey");
ALTER TABLE "OnCallOverride" ADD CONSTRAINT "OnCallOverride_rotationId_fkey" FOREIGN KEY ("rotationId") REFERENCES "OnCallRotation"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "OnCallOverride" ADD CONSTRAINT "OnCallOverride_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "OnCallMember"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "OnCallOverride" ADD CONSTRAINT "OnCallOverride_replacementMemberId_fkey" FOREIGN KEY ("replacementMemberId") REFERENCES "OnCallMember"("id") ON DELETE SET NULL ON UPDATE CASCADE;
