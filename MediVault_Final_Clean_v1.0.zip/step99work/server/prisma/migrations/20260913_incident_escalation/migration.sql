-- Step 88: incident acknowledgement, escalation and responder notes
ALTER TABLE "AlertIncident"
  ADD COLUMN "acknowledgedAt" TIMESTAMP(3),
  ADD COLUMN "acknowledgedBy" TEXT,
  ADD COLUMN "escalationLevel" INTEGER NOT NULL DEFAULT 0,
  ADD COLUMN "nextEscalationAt" TIMESTAMP(3),
  ADD COLUMN "lastEscalatedAt" TIMESTAMP(3),
  ADD COLUMN "responderNotes" TEXT;

CREATE INDEX "AlertIncident_status_severity_nextEscalationAt_idx"
  ON "AlertIncident"("status", "severity", "nextEscalationAt");
