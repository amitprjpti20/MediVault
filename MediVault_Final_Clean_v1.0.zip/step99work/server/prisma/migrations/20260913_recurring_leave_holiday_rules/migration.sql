-- Step 94: recurring leave rules and holiday calendar automation
CREATE TABLE "OnCallRecurringRule" (
  "id" TEXT NOT NULL,
  "rotationId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "memberId" TEXT,
  "replacementMemberId" TEXT,
  "mode" TEXT NOT NULL DEFAULT 'replace',
  "recurrence" TEXT NOT NULL,
  "daysOfWeek" TEXT,
  "startDate" TEXT NOT NULL,
  "endDate" TEXT,
  "note" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallRecurringRule_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "OnCallRecurringRule_rotationId_fkey" FOREIGN KEY ("rotationId") REFERENCES "OnCallRotation" ("id") ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT "OnCallRecurringRule_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "OnCallMember" ("id") ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT "OnCallRecurringRule_replacementMemberId_fkey" FOREIGN KEY ("replacementMemberId") REFERENCES "OnCallMember" ("id") ON DELETE SET NULL ON UPDATE CASCADE
);
CREATE INDEX "OnCallRecurringRule_rotationId_startDate_idx" ON "OnCallRecurringRule"("rotationId", "startDate");
CREATE INDEX "OnCallRecurringRule_active_idx" ON "OnCallRecurringRule"("active");
