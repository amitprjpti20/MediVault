CREATE TABLE "OnCallRotation" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "timezone" TEXT NOT NULL DEFAULT 'UTC',
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallRotation_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OnCallRotation_active_idx" ON "OnCallRotation"("active");

CREATE TABLE "OnCallMember" (
  "id" TEXT NOT NULL,
  "rotationId" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "email" TEXT,
  "phone" TEXT,
  "role" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallMember_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OnCallMember_rotationId_active_idx" ON "OnCallMember"("rotationId", "active");
ALTER TABLE "OnCallMember" ADD CONSTRAINT "OnCallMember_rotationId_fkey" FOREIGN KEY ("rotationId") REFERENCES "OnCallRotation"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "OnCallShift" (
  "id" TEXT NOT NULL,
  "rotationId" TEXT NOT NULL,
  "memberId" TEXT NOT NULL,
  "startsAt" TIMESTAMP(3) NOT NULL,
  "endsAt" TIMESTAMP(3) NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'scheduled',
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallShift_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OnCallShift_rotationId_startsAt_endsAt_idx" ON "OnCallShift"("rotationId", "startsAt", "endsAt");
CREATE INDEX "OnCallShift_memberId_startsAt_idx" ON "OnCallShift"("memberId", "startsAt");
ALTER TABLE "OnCallShift" ADD CONSTRAINT "OnCallShift_rotationId_fkey" FOREIGN KEY ("rotationId") REFERENCES "OnCallRotation"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "OnCallShift" ADD CONSTRAINT "OnCallShift_memberId_fkey" FOREIGN KEY ("memberId") REFERENCES "OnCallMember"("id") ON DELETE CASCADE ON UPDATE CASCADE;

CREATE TABLE "EscalationPolicy" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "description" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "EscalationPolicy_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "EscalationPolicy_active_idx" ON "EscalationPolicy"("active");

CREATE TABLE "EscalationPolicyStep" (
  "id" TEXT NOT NULL,
  "policyId" TEXT NOT NULL,
  "level" INTEGER NOT NULL,
  "delayMinutes" INTEGER NOT NULL,
  "targetType" TEXT NOT NULL,
  "targetRef" TEXT NOT NULL,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "EscalationPolicyStep_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "EscalationPolicyStep_policyId_level_key" ON "EscalationPolicyStep"("policyId", "level");
CREATE INDEX "EscalationPolicyStep_policyId_level_idx" ON "EscalationPolicyStep"("policyId", "level");
ALTER TABLE "EscalationPolicyStep" ADD CONSTRAINT "EscalationPolicyStep_policyId_fkey" FOREIGN KEY ("policyId") REFERENCES "EscalationPolicy"("id") ON DELETE CASCADE ON UPDATE CASCADE;
