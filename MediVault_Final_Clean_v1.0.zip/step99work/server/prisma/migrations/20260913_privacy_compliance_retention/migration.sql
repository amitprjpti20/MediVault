CREATE TABLE "PrivacyRequest" (
  "id" TEXT NOT NULL,
  "userId" TEXT NOT NULL,
  "type" TEXT NOT NULL,
  "status" TEXT NOT NULL DEFAULT 'submitted',
  "requestedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "acknowledgedAt" TIMESTAMP(3),
  "dueAt" TIMESTAMP(3),
  "resolvedAt" TIMESTAMP(3),
  "actor" TEXT,
  "notes" TEXT,
  "metadataJson" TEXT,
  CONSTRAINT "PrivacyRequest_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "DataRetentionPolicy" (
  "id" TEXT NOT NULL,
  "resource" TEXT NOT NULL,
  "retentionDays" INTEGER NOT NULL,
  "enabled" BOOLEAN NOT NULL DEFAULT true,
  "legalBasis" TEXT,
  "notes" TEXT,
  "updatedBy" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "DataRetentionPolicy_pkey" PRIMARY KEY ("id")
);
CREATE TABLE "RetentionRun" (
  "id" TEXT NOT NULL,
  "resource" TEXT NOT NULL,
  "mode" TEXT NOT NULL DEFAULT 'preview',
  "matchedCount" INTEGER NOT NULL DEFAULT 0,
  "deletedCount" INTEGER NOT NULL DEFAULT 0,
  "status" TEXT NOT NULL DEFAULT 'completed',
  "startedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "completedAt" TIMESTAMP(3),
  "actor" TEXT,
  "summary" TEXT,
  CONSTRAINT "RetentionRun_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "DataRetentionPolicy_resource_key" ON "DataRetentionPolicy"("resource");
CREATE INDEX "PrivacyRequest_userId_requestedAt_idx" ON "PrivacyRequest"("userId", "requestedAt");
CREATE INDEX "PrivacyRequest_status_dueAt_idx" ON "PrivacyRequest"("status", "dueAt");
CREATE INDEX "RetentionRun_resource_startedAt_idx" ON "RetentionRun"("resource", "startedAt");
ALTER TABLE "PrivacyRequest" ADD CONSTRAINT "PrivacyRequest_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
