-- Step 87: operational Alertmanager incident persistence
CREATE TABLE "AlertIncident" (
    "id" TEXT NOT NULL,
    "fingerprint" TEXT NOT NULL,
    "alertName" TEXT NOT NULL,
    "severity" TEXT NOT NULL DEFAULT 'warning',
    "category" TEXT,
    "status" TEXT NOT NULL DEFAULT 'firing',
    "summary" TEXT,
    "description" TEXT,
    "labelsJson" TEXT,
    "annotationsJson" TEXT,
    "startsAt" TIMESTAMP(3),
    "endsAt" TIMESTAMP(3),
    "firstReceivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "lastReceivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "resolvedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "AlertIncident_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "AlertIncident_fingerprint_key" ON "AlertIncident"("fingerprint");
CREATE INDEX "AlertIncident_status_severity_lastReceivedAt_idx" ON "AlertIncident"("status", "severity", "lastReceivedAt");
CREATE INDEX "AlertIncident_alertName_lastReceivedAt_idx" ON "AlertIncident"("alertName", "lastReceivedAt");
