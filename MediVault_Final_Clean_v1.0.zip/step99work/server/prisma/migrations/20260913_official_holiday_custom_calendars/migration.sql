CREATE TABLE "OnCallHolidayCalendar" (
  "id" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "countryCode" TEXT,
  "timezone" TEXT NOT NULL DEFAULT 'UTC',
  "sourceType" TEXT NOT NULL DEFAULT 'custom',
  "sourceUrl" TEXT,
  "active" BOOLEAN NOT NULL DEFAULT true,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallHolidayCalendar_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "OnCallHolidayCalendar_countryCode_active_idx" ON "OnCallHolidayCalendar"("countryCode", "active");
CREATE TABLE "OnCallHoliday" (
  "id" TEXT NOT NULL,
  "calendarId" TEXT NOT NULL,
  "dateKey" TEXT NOT NULL,
  "name" TEXT NOT NULL,
  "observed" BOOLEAN NOT NULL DEFAULT false,
  "source" TEXT,
  "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
  "updatedAt" TIMESTAMP(3) NOT NULL,
  CONSTRAINT "OnCallHoliday_pkey" PRIMARY KEY ("id"),
  CONSTRAINT "OnCallHoliday_calendarId_fkey" FOREIGN KEY ("calendarId") REFERENCES "OnCallHolidayCalendar"("id") ON DELETE CASCADE ON UPDATE CASCADE
);
CREATE UNIQUE INDEX "OnCallHoliday_calendarId_dateKey_name_key" ON "OnCallHoliday"("calendarId", "dateKey", "name");
CREATE INDEX "OnCallHoliday_calendarId_dateKey_idx" ON "OnCallHoliday"("calendarId", "dateKey");
