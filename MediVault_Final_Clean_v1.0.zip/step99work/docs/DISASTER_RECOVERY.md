# MediVault Disaster Recovery Runbook — Step 74

## Recovery objectives
- Target RPO: 24 hours for the baseline backup workflow.
- Target RTO: environment-dependent; validate with a staging restore drill before production promises.

## Backup workflow
1. Run `npm run db:backup` from the API server with a valid `DATABASE_URL`.
2. Run `npm run db:verify-backup -- ./backups/<file>.dump` and record the SHA-256 checksum.
3. Upload the dump to a private, versioned, encrypted object-storage bucket.
4. Keep at least one backup in a separate account/region from the primary database where operationally appropriate.

## Restore workflow
1. Provision a clean PostgreSQL instance.
2. Restore using `npm run db:restore -- ./backups/<file>.dump`.
3. Run Prisma migrations/generate as required by the deployed release.
4. Validate login, health records, documents metadata, notifications, audit logs, and consent data.
5. Only then switch application traffic to the recovered database.

## Point-in-time recovery
Enable the managed PostgreSQL provider's WAL/PITR feature in production. This project provides the logical backup scripts; PITR itself is a database-provider capability and must be configured outside the repository.

## Document recovery
Database restore does not restore cloud object contents. Document storage must use bucket versioning/object lock where appropriate, lifecycle policies, and a tested cross-region or separate-account replication strategy.

## Restore drills
Perform a documented restore test at least quarterly. Record: backup identifier, restore start/end times, checksum verification, application smoke tests, and any data discrepancies.
