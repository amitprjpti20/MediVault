# On-Call Operations Runbook — Step 90

1. Keep at least one active rotation.
2. Ensure the current shift covers the present time window.
3. Maintain at least one secondary responder for critical incidents.
4. Critical escalation policy should have increasing delays and distinct targets.
5. Acknowledge incidents from the private incident dashboard once a responder has engaged.
6. If an alert remains unacknowledged, the incident escalation worker can continue to advance levels.
7. Rotate operations tokens and paging credentials when personnel change.
