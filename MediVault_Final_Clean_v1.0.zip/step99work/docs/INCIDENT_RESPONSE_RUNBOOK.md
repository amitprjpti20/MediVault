# MediVault Incident Response Runbook — Step 88

## Purpose
Provide an on-call workflow for critical security/performance alerts from Prometheus → Alertmanager → MediVault.

## Severity
- **Critical**: security bursts, API 5xx spikes, observability pipeline outage, or other production-impacting conditions.
- **Warning**: degraded performance or early-warning conditions.

## First 5 minutes
1. Open the incident in the incident receiver / internal incident list.
2. Acknowledge it with the responder identity (`X-Incident-Actor`).
3. Record a short responder note: impact, hypothesis, and first action.
4. Check request IDs/traces in Grafana and correlate logs in Loki/Tempo.
5. Avoid exposing health-record contents in tickets, chat, or logs.

## Escalation
Unacknowledged critical incidents are periodically escalated. Default delays are configured by `INCIDENT_ESCALATION_MINUTES=15,30,60`.

After acknowledgement, automatic escalation pauses. Unacknowledging re-arms the escalation timer.

## Containment
- For an auth/security burst: preserve logs, verify rate limiting, inspect active sessions, and consider temporary access restrictions.
- For high 5xx/latency: inspect recent deployments, dependencies, database health, and slow-query telemetry.
- For telemetry failure: restore Prometheus/OTel/Loki/Tempo pipeline before relying on dashboards for incident decisions.

## Resolution
1. Confirm the alert is resolved in Alertmanager.
2. Add a final responder note containing root cause and mitigation.
3. Capture follow-up items for a post-incident review.
4. Verify backup/DR health for incidents involving data services.

## Security rules
Never paste medical record contents, document URLs, passwords, tokens, session cookies, or encryption keys into incident notes. Incident metadata is operational data and should remain access-controlled.

## Required production configuration
Set a private `INCIDENT_ESCALATION_WEBHOOK_URL` or equivalent paging bridge and keep its bearer token in a secret manager. Restrict `/internal/incidents/*` to trusted network paths and rotate the shared incident token regularly.
