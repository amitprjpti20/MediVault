import { useEffect, useMemo, useState } from "react";
import { api, API_BASE } from "./lib/api.js";

const navGroups = [
  { title:"CORE", items:[["🏠","Dashboard"],["🗂️","Medical Records"],["👨‍👩‍👧","Family Profiles"]] },
  { title:"HEALTH", items:[["💊","Medicines"],["🧪","Lab Reports"],["❤️","Vitals & Sync"],["📊","Health Insights"],["📅","Calendar & Reminders"],["💉","Vaccinations"],["📄","Documents Vault"]] },
  { title:"TOOLS", items:[["🔎","Smart Document Scanner"],["🧾","Data Import / Export"],["🔔","Notifications"],["🎯","Health Goals"],["📓","Health Journal"],["🤖","Advanced AI"],["🩺","Doctor-ready Summary"]] },
  { title:"MONITORING", items:[["📈","System Monitoring"],["🛠️","Operations Console"],["🚨","Incident Dashboard"],["📟","On-Call Management"],["🛡️","Privacy & Compliance"]] },
  { title:"CONNECT", items:[["🔐","Security Dashboard"],["🧾","Activity History"],["📱","Active Sessions"],["☁️","Cloud Sync"],["🪪","ABHA / ABDM"],["🤝","Sharing & Consent"],["🚑","Emergency Card"],["🧑‍⚕️","Doctors & Hospitals"],["🛡️","Insurance & Claims"],["💳","Payments & Expenses"],["📍","Nearby Healthcare"],["🎥","Telemedicine"],["⚙️","Settings"]] },
  { title:"FAMILY & PETS", items:[["🧬","Family Health History"],["🐾","Pet Profiles"],["🐶","Pet Health Records"]] }
];

const places=[
 {id:1,name:"CityCare Hospital",type:"Hospital",specialty:"Multi-specialty",distance:"2.4 km",open:"Open 24/7",phone:"+91 XXXXX XXXXX",emergency:true},
 {id:2,name:"Metro Diagnostics",type:"Laboratory",specialty:"Lab & Imaging",distance:"3.1 km",open:"Open until 8 PM",phone:"+91 XXXXX XXXXX",emergency:false},
 {id:3,name:"CarePlus Pharmacy",type:"Pharmacy",specialty:"24-hour pharmacy",distance:"1.2 km",open:"Open now",phone:"+91 XXXXX XXXXX",emergency:false},
 {id:4,name:"LifeLine Clinic",type:"Clinic",specialty:"General Medicine",distance:"4.6 km",open:"Open until 9 PM",phone:"+91 XXXXX XXXXX",emergency:false},
];

const consults=[
 {id:1,doctor:"Dr. Sharma",specialty:"General Medicine",patient:"Amit Kumar",mode:"Video",date:"16 Sep 2026",time:"10:30 AM",status:"Scheduled",icon:"🎥"},
 {id:2,doctor:"Dr. Mehta",specialty:"Pediatrics",patient:"Rajesh Kumar",mode:"Phone",date:"20 Sep 2026",time:"4:00 PM",status:"Scheduled",icon:"📞"},
 {id:3,doctor:"Dr. Verma",specialty:"Internal Medicine",patient:"Amit Kumar",mode:"Chat",date:"12 Sep 2026",time:"2:00 PM",status:"Completed",icon:"💬"},
];

function App(){
 const [authStatus,setAuthStatus]=useState("loading");
 const [user,setUser]=useState(null);
 const [authRefresh,setAuthRefresh]=useState(0);

 useEffect(()=>{
  let alive=true;
  api.me().then(({user})=>{ if(alive){ setUser(user); setAuthStatus("authenticated"); } })
   .catch(()=>{ if(alive){ setUser(null); setAuthStatus("anonymous"); } });
  return ()=>{ alive=false; };
 },[authRefresh]);

 if(authStatus==="loading") return <LoadingScreen/>;
 if(!user) return <AuthPage apiBase={API_BASE} onAuthenticated={(nextUser)=>{ setUser(nextUser); setAuthStatus("authenticated"); setAuthRefresh(v=>v+1); }}/>;

 return <AuthenticatedApp user={user} setUser={setUser}/>;
}

function AuthenticatedApp({user,setUser}){
 const [menuOpen,setMenuOpen]=useState(false);
 const [active,setActive]=useState("Dashboard");
 const [placeQuery,setPlaceQuery]=useState("");
 const [placeType,setPlaceType]=useState("All");
 const [selectedPlace,setSelectedPlace]=useState(null);
 const [consultQuery,setConsultQuery]=useState("");
 const [consultMode,setConsultMode]=useState("All");
 const [selectedConsult,setSelectedConsult]=useState(null);
 const [settingsSaved,setSettingsSaved]=useState(false);
 const [securityMode,setSecurityMode]=useState("Standard");
 const [reminders,setReminders]=useState(true);
 const [analytics,setAnalytics]=useState(true);
 const [sharing,setSharing]=useState(false);
 const [emergencyOnly,setEmergencyOnly]=useState(false);

 const nearby=useMemo(()=>places.filter(p=>
   (placeType==="All"||p.type===placeType)&&
   (!emergencyOnly||p.emergency)&&
   (p.name+p.type+p.specialty).toLowerCase().includes(placeQuery.toLowerCase())
 ),[placeQuery,placeType,emergencyOnly]);

 const tele=useMemo(()=>consults.filter(c=>
   (consultMode==="All"||c.mode===consultMode)&&
   (c.doctor+c.specialty+c.patient+c.mode).toLowerCase().includes(consultQuery.toLowerCase())
 ),[consultMode,consultQuery]);

 const select=n=>{setActive(n);setMenuOpen(false);setSelectedPlace(null);setSelectedConsult(null)};

 return <div className="app-shell">
  <header className="topbar"><button className="hamburger" onClick={()=>setMenuOpen(v=>!v)}>☰</button>
   <div className="brand"><div className="logo">M</div><div><strong>MediVault</strong><small>Personal Health Organizer</small></div></div>
   <div className="topbar-right"><span className="secure-pill">● Secure session</span><button className="avatar" title={user.email}>{(user.name||user.email).slice(0,2).toUpperCase()}</button><button className="topbar-logout" onClick={async()=>{await api.logout().catch(()=>{});setUser(null)}}>Sign out</button></div>
  </header>

  {menuOpen&&<div className="menu-overlay" onClick={()=>setMenuOpen(false)}><aside className="side-menu" onClick={e=>e.stopPropagation()}>
   <div className="menu-head"><div><b>All sections</b><small>MediVault workspace</small></div><button onClick={()=>setMenuOpen(false)}>×</button></div>
   {navGroups.map(g=><div className="nav-group" key={g.title}><div className="nav-title">{g.title}</div>{g.items.map(([icon,name])=><button key={name} className={active===name?"nav-item active":"nav-item"} onClick={()=>select(name)}><span>{icon}</span>{name}</button>)}</div>)}
  </aside></div>}

  <main className="page">
   {active==="Dashboard"&&<Dashboard select={select}/>}
   {active==="Medical Records"&&<MedicalRecordsPage/>}
   {active==="Family Profiles"&&<FamilyProfilesPage/>}
   {active==="Medicines"&&<MedicinesPage/>}
   {active==="Lab Reports"&&<LabReportsPage/>}
   {active==="Vitals & Sync"&&<VitalsPage/>}
   {active==="Vaccinations"&&<VaccinationsPage/>}
   {active==="Health Goals"&&<HealthGoalsPage/>}
   {active==="Calendar & Reminders"&&<CalendarPage/>}
   {active==="Health Journal"&&<JournalPage/>}
   {active==="Notifications"&&<NotificationsPage/>}
   {active==="Security Dashboard"&&<SecurityDashboardPage/>}
   {active==="System Monitoring"&&<SystemMonitoringPage/>}
   {active==="Operations Console"&&<OperationsConsolePage/>}
   {active==="Incident Dashboard"&&<IncidentDashboardPage/>}
   {active==="On-Call Management"&&<OnCallManagementPage/>}
   {active==="Privacy & Compliance"&&<PrivacyCompliancePage/>}
   {active==="Activity History"&&<ActivityHistoryPage/>}
   {active==="Active Sessions"&&<ActiveSessionsPage/>}
   {active==="Documents Vault"&&<DocumentsPage/>}
   {active==="Nearby Healthcare"&&<NearbyPage places={nearby} query={placeQuery} setQuery={setPlaceQuery} type={placeType} setType={setPlaceType} emergencyOnly={emergencyOnly} setEmergencyOnly={setEmergencyOnly} selected={selectedPlace} setSelected={setSelectedPlace}/>}
   {active==="Settings"&&<SettingsPage {...{settingsSaved,setSettingsSaved,securityMode,setSecurityMode,reminders,setReminders,analytics,setAnalytics,sharing,setSharing,user,onLogout:async()=>{await api.logout().catch(()=>{});setUser(null)}}}/>}
   {active==="Telemedicine"&&<TelemedicinePage consults={tele} query={consultQuery} setQuery={setConsultQuery} mode={consultMode} setMode={setConsultMode} selected={selectedConsult} setSelected={setSelectedConsult}/>}
   {!["Dashboard","Medical Records","Documents Vault","Nearby Healthcare","Telemedicine","Settings","Notifications","Activity History","Active Sessions","Security Dashboard","System Monitoring","Operations Console","On-Call Management","Privacy & Compliance"].includes(active)&&<Placeholder active={active} onBack={()=>select("Dashboard")}/>}
  </main>
 </div>
}




function PrivacyCompliancePage(){
 const [token,setToken]=useState(()=>sessionStorage.getItem("medivault_ops_token")||"");
 const [actor,setActor]=useState(()=>sessionStorage.getItem("medivault_ops_actor")||"privacy-admin");
 const [data,setData]=useState(null); const [loading,setLoading]=useState(false); const [error,setError]=useState("");
 const [policy,setPolicy]=useState({resource:"auditLogs",retentionDays:365,enabled:true,legalBasis:"Operational/security retention"});
 const [request,setRequest]=useState({userId:"",type:"access",dueDays:30,notes:""});
 async function load(){ if(!token.trim()){setError("Enter the restricted operations token.");return;} setLoading(true);setError(""); try{sessionStorage.setItem("medivault_ops_token",token);sessionStorage.setItem("medivault_ops_actor",actor||"privacy-admin"); const r=await api.privacyOverview(token);setData(r.data||null);}catch(e){setError(e.message||"Unable to load privacy controls.")}finally{setLoading(false)} }
 async function savePolicy(){try{await api.createRetentionPolicy(token,{...policy,retentionDays:Number(policy.retentionDays),actor});await load();}catch(e){setError(e.message||"Unable to save retention policy.")}}
 async function submitRequest(){try{await api.createPrivacyRequest(token,{...request,dueDays:Number(request.dueDays),actor});setRequest({userId:"",type:"access",dueDays:30,notes:""});await load();}catch(e){setError(e.message||"Unable to create privacy request.")}}
 async function updateReq(id,status){try{await api.updatePrivacyRequest(token,id,{status,actor});await load();}catch(e){setError(e.message||"Unable to update request.")}}
 async function preview(resource){try{const r=await api.previewRetention(token,resource);alert(`${resource}: ${r.data.matchedCount} records match the retention window.`);}catch(e){setError(e.message||"Retention preview failed.")}}
 return <section>
  <div className="page-head"><div><div className="eyebrow">OPERATIONS · PRIVACY</div><h1>Privacy & Compliance</h1><p>Manage data-subject requests, retention policies and non-destructive retention previews. This console never shows health-record content.</p></div><button className="primary" onClick={load}>{loading?"Loading…":"↻ Refresh"}</button></div>
  <section className="card"><div className="section-title"><div><h2>Restricted access</h2><p>Uses the private operations token. Keep this page inside the trusted operations network.</p></div><span className="badge">Protected</span></div><div className="two-col"><label>Operations token<input type="password" value={token} onChange={e=>setToken(e.target.value)} placeholder="x-alertmanager-token" autoComplete="off"/></label><label>Operator<input value={actor} onChange={e=>setActor(e.target.value)} placeholder="privacy-admin"/></label></div><div className="page-actions" style={{marginTop:10}}><button className="primary" onClick={load}>Connect & load</button></div></section>
  {error&&<div className="alert warning">{error}</div>}
  {data&&<>
   <div className="stats-grid"><div className="card"><span className="stat-label">Privacy requests</span><b className="stat-number">{data.requests?.length??0}</b><small>Most recent operational queue</small></div><div className="card"><span className="stat-label">Overdue</span><b className="stat-number">{data.overdue??0}</b><small>Needs compliance attention</small></div><div className="card"><span className="stat-label">Retention policies</span><b className="stat-number">{data.policies?.length??0}</b><small>Configured resources</small></div><div className="card"><span className="stat-label">Retention runs</span><b className="stat-number">{data.recentRuns?.length??0}</b><small>Recent previews/executions</small></div></div>
   <div className="grid-2">
    <div className="card"><h2>Retention policies</h2><p className="muted">Preview is always allowed. Destructive execution is separately gated by <code>PRIVACY_RETENTION_EXECUTE=true</code>.</p><div className="form-grid"><label>Resource<select value={policy.resource} onChange={e=>setPolicy({...policy,resource:e.target.value})}><option value="auditLogs">Audit logs</option><option value="securityEvents">Security events</option><option value="notifications">Notifications</option><option value="sessions">Sessions</option></select></label><label>Retention days<input type="number" min="1" max="36500" value={policy.retentionDays} onChange={e=>setPolicy({...policy,retentionDays:e.target.value})}/></label><label>Legal basis<input value={policy.legalBasis} onChange={e=>setPolicy({...policy,legalBasis:e.target.value})}/></label></div><div className="page-actions"><button onClick={()=>preview(policy.resource)}>Preview</button><button className="primary" onClick={savePolicy}>Save policy</button></div><div className="list">{(data.policies||[]).map(p=><div className="list-row" key={p.id}><div><b>{p.resource}</b><div className="muted">{p.retentionDays} days · {p.enabled?"enabled":"disabled"}</div></div><small>{p.legalBasis||"No legal basis note"}</small></div>)}</div></div>
    <div className="card"><h2>Privacy request intake</h2><p className="muted">Track access, export, deletion, correction and consent-withdrawal requests without exposing record contents in this console.</p><div className="form-grid"><label>User ID<input value={request.userId} onChange={e=>setRequest({...request,userId:e.target.value})} placeholder="user id"/></label><label>Request type<select value={request.type} onChange={e=>setRequest({...request,type:e.target.value})}><option>access</option><option>export</option><option>delete</option><option>correct</option><option>restrict</option><option>withdraw-consent</option></select></label><label>Due days<input type="number" min="1" max="365" value={request.dueDays} onChange={e=>setRequest({...request,dueDays:e.target.value})}/></label><label>Notes<input value={request.notes} onChange={e=>setRequest({...request,notes:e.target.value})} placeholder="case reference / handling note"/></label></div><div className="page-actions"><button className="primary" disabled={!request.userId.trim()} onClick={submitRequest}>Create request</button></div></div>
   </div>
   <div className="card"><div className="section-title"><div><h2>Privacy request queue</h2><p>Operational metadata only.</p></div></div>{data.requests?.length?<div className="record-list">{data.requests.map(r=><article className="record-item" key={r.id}><div className="record-icon">🧾</div><div className="record-main"><b>{r.type.toUpperCase()} · {r.status}</b><small>User {r.userId} · due {r.dueAt?new Date(r.dueAt).toLocaleString():"—"}</small><p>{r.notes||"No notes"}</p></div><div className="page-actions">{r.status!=="acknowledged"&&r.status!=="resolved"&&<button onClick={()=>updateReq(r.id,"acknowledged")}>Acknowledge</button>}{r.status!=="resolved"&&<button className="primary" onClick={()=>updateReq(r.id,"resolved")}>Resolve</button>}</div></article>)}</div>:<div className="empty">No privacy requests.</div>}</div>
   <div className="card"><h2>Compliance guardrails</h2><div className="security-checks"><div><span>✅</span><div><b>Metadata boundary</b><small>Record contents, passwords, keys and raw medical documents are not returned by these admin endpoints.</small></div></div><div><span>✅</span><div><b>Retention is opt-in for deletion</b><small>Destructive retention execution is disabled unless the deployment explicitly enables it.</small></div></div><div><span>✅</span><div><b>Auditability</b><small>Privacy request state and retention runs are persisted for operational review.</small></div></div></div></div>
  </>}
 </section>
}

function OperationsConsolePage(){
 const [token,setToken]=useState(()=>sessionStorage.getItem("medivault_ops_token")||"");
 const [actor,setActor]=useState(()=>sessionStorage.getItem("medivault_ops_actor")||"ops-admin");
 const [data,setData]=useState(null); const [loading,setLoading]=useState(false); const [error,setError]=useState("");
 async function load(){
  if(!token){setError("Enter the restricted operations token.");return;}
  setLoading(true); setError("");
  try{sessionStorage.setItem("medivault_ops_token",token);sessionStorage.setItem("medivault_ops_actor",actor||"ops-admin");const r=await api.adminOverview(token);setData(r.data?.data||null);}
  catch(e){setError(e.message||"Unable to load operations console.");}
  finally{setLoading(false);}
 }
 return <section>
  <div className="page-head"><div><div className="eyebrow">OPERATIONS · ADMIN</div><h1>Operations Console</h1><p>Read-only production metadata for service, security, incident and on-call operations. Patient records are never returned here.</p></div><button className="primary" onClick={load}>{loading?"Loading…":"↻ Refresh"}</button></div>
  <section className="card"><div className="section-title"><div><h2>Restricted access</h2><p>Uses the same private operations token as Alertmanager incident management.</p></div><span className="badge">Metadata only</span></div>
   <div className="two-col"><label>Operations token<input type="password" value={token} onChange={e=>setToken(e.target.value)} placeholder="x-alertmanager-token"/></label><label>Operator<input value={actor} onChange={e=>setActor(e.target.value)} placeholder="ops-admin"/></label></div>
   <div className="page-actions" style={{marginTop:10}}><button className="primary" onClick={load} disabled={loading}>{loading?"Connecting…":"Connect & load"}</button></div>
  </section>
  {error&&<div className="alert warning">{error}</div>}
  {!data&&!loading?<div className="empty-state compact-empty"><div>🛠️</div><h2>Operations console locked</h2><p>No patient data is exposed here. Authenticate with the restricted operations token.</p></div>:data&&<>
   <div className="stats-grid">
    <div className="card"><span className="stat-label">Open critical incidents</span><b className="stat-number">{data.operations.openCritical ?? "—"}</b><small>Immediate response queue</small></div>
    <div className="card"><span className="stat-label">Open incidents</span><b className="stat-number">{data.operations.openIncidents ?? "—"}</b><small>{data.operations.acknowledgedIncidents ?? 0} acknowledged</small></div>
    <div className="card"><span className="stat-label">Active rotations</span><b className="stat-number">{data.operations.activeRotations ?? "—"}</b><small>{data.counts.onCallMembers ?? 0} active member records</small></div>
    <div className="card"><span className="stat-label">Active sessions</span><b className="stat-number">{data.operations.activeSessions ?? "—"}</b><small>Unexpired application sessions</small></div>
   </div>
   <div className="grid-2">
    <div className="card"><h2>Platform inventory</h2><p className="muted">Counts only; no individual health records or secrets returned.</p><div className="final-grid">{[["👤","Users",data.counts.users],["🗂️","Medical records",data.counts.medicalRecords],["📄","Documents",data.counts.documents],["💊","Medications",data.counts.medications],["🧪","Lab reports",data.counts.labReports],["❤️","Vitals",data.counts.vitals],["💉","Vaccinations",data.counts.vaccinations],["🎯","Health goals",data.counts.healthGoals]].map(([icon,label,value])=><div key={label}><span>{icon}</span><div><b>{label}</b><small>{value??"unavailable"}</small></div></div>)}</div></div>
    <div className="card"><h2>Security & operations inventory</h2><p className="muted">Operational metadata for security posture and support workflows.</p><div className="final-grid">{[["🧾","Audit logs",data.counts.auditLogs],["🔐","Security events",data.counts.securityEvents],["📟","On-call shifts",data.counts.onCallShifts],["🏖️","Overrides",data.counts.onCallOverrides],["🔁","Recurring rules",data.counts.recurringRules],["📣","Escalation policies",data.counts.escalationPolicies],["💾","Backup jobs",data.counts.backups],["🔔","Notifications",data.counts.notifications]].map(([icon,label,value])=><div key={label}><span>{icon}</span><div><b>{label}</b><small>{value??"unavailable"}</small></div></div>)}</div></div>
   </div>
   <div className="card"><div className="section-title"><div><h2>Safety boundary</h2><p>The console is intentionally read-only and returns metadata only.</p></div><span className="badge">Protected</span></div><div className="security-checks"><div><span>✅</span><div><b>Patient data hidden</b><small>Medical records, documents and personal health content are represented only as aggregate counts.</small></div></div><div><span>✅</span><div><b>Secrets hidden</b><small>Passwords, tokens, encryption keys and provider credentials are never returned by this endpoint.</small></div></div><div><span>✅</span><div><b>Restricted authentication</b><small>Access requires the private operations token and should remain inside the trusted operations network.</small></div></div></div></div>
   <small className="muted">Generated {new Date(data.generatedAt).toLocaleString()} · environment: {data.environment} · {data.version}</small>
  </>}
 </section>
}

function SystemMonitoringPage(){
 const [live,setLive]=useState(null); const [ready,setReady]=useState(null); const [metrics,setMetrics]=useState(null); const [performance,setPerformance]=useState(null); const [loading,setLoading]=useState(true); const [error,setError]=useState("");
 async function load(){ setLoading(true); setError(""); try{ const [a,b,c,d]=await Promise.all([api.healthLive(),api.healthReady(),api.healthMetrics(),api.performanceMetrics()]); setLive(a); setReady(b); setMetrics(c); setPerformance(d.data||null); }catch(e){setError(e.message||"Unable to load monitoring status");}finally{setLoading(false);} }
 useEffect(()=>{load(); const id=setInterval(load,30000); return ()=>clearInterval(id)},[]);
 return <section><div className="page-head"><div><div className="eyebrow">OPERATIONS</div><h1>System Monitoring</h1><p>Live service health, PostgreSQL readiness and in-process API performance metrics.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
  {error&&<div className="alert warning">{error}</div>}
  <div className="stats-grid">
   <div className="card"><span className="stat-label">Liveness</span><b className="stat-number">{loading?"Checking…":live?.ok?"Healthy":"Down"}</b><small>{live?.time||"Waiting for response"}</small></div>
   <div className="card"><span className="stat-label">Database readiness</span><b className="stat-number">{loading?"Checking…":ready?.ok?"Ready":"Unavailable"}</b><small>{ready?.dependencies?.postgres||"No response"}</small></div>
   <div className="card"><span className="stat-label">Uptime</span><b className="stat-number">{metrics?`${Math.floor((metrics.uptimeSeconds||0)/60)}m`:"—"}</b><small>API process uptime</small></div>
   <div className="card"><span className="stat-label">5xx error rate</span><b className="stat-number">{metrics?`${((metrics.errorRate||0)*100).toFixed(2)}%`:"—"}</b><small>{metrics?`${metrics.errors} server errors / ${metrics.requests} requests`:"Waiting for metrics"}</small></div>
  </div>
  <div className="grid-2">
   <div className="card"><h2>Latency</h2><p className="muted">Average in-process response time.</p><div className="big-number">{metrics?`${metrics.avgLatencyMs} ms`:"—"}</div><small>{performance?`${performance.slowRequests} slow requests`:"Performance data unavailable"}</small></div>
   <div className="card"><h2>Database performance</h2><p className="muted">Slow-query threshold: {performance?.thresholds?.slowQueryMs ?? "—"} ms.</p><div className="big-number">{performance?.slowQueries ?? "—"}</div><small>Slow queries observed in this API process</small></div>
  </div>
  <div className="card"><h2>Slow-request alerts</h2><p className="muted">Process-local alerts; production deployments should export these to centralized observability tooling.</p>{performance?.recentAlerts?.length ? <div className="list">{performance.recentAlerts.slice(0,8).map((a,i)=><div className="list-row" key={i}><div><b>{a.type}</b><div className="muted">{a.path || a.model || "—"} · {a.durationMs} ms</div></div><small>{new Date(a.at).toLocaleString()}</small></div>)}</div> : <div className="empty">No slow-request or slow-query alerts recorded.</div>}</div>
  <div className="card"><h2>Operational guidance</h2><p>Use <code>/api/health/live</code> for uptime, <code>/api/health/ready</code> for dependency readiness, and authenticated <code>/api/performance</code> for API/query performance.</p><p className="muted">Performance counters are process-local and reset when the API restarts.</p></div>
 </section>
}


function IncidentDashboardPage(){
 const [token,setToken]=useState(()=>sessionStorage.getItem("medivault_ops_token")||"");
 const [actor,setActor]=useState(()=>sessionStorage.getItem("medivault_ops_actor")||"on-call");
 const [data,setData]=useState(null); const [loading,setLoading]=useState(false); const [error,setError]=useState(""); const [selected,setSelected]=useState(null); const [note,setNote]=useState(""); const [status,setStatus]=useState("firing");
 const saveToken=(v)=>{setToken(v); sessionStorage.setItem("medivault_ops_token",v)};
 const saveActor=(v)=>{setActor(v); sessionStorage.setItem("medivault_ops_actor",v)};
 async function load(nextStatus=status){
  if(!token.trim()){setError("Enter the Alertmanager dashboard token to continue.");return;}
  setLoading(true); setError("");
  try{ const r=await api.incidentsDashboard(token,{status:nextStatus||undefined,limit:100}); setData(r); }
  catch(e){setData(null);setError(e.message||"Unable to load incidents. Check the operations token.");}
  finally{setLoading(false)}
 }
 useEffect(()=>{ if(token) load(); },[]);
 const ack=async(i)=>{try{await api.acknowledgeIncident(token,i.id,actor);await load()}catch(e){setError(e.message||"Unable to acknowledge incident.")}};
 const unack=async(i)=>{try{await api.unacknowledgeIncident(token,i.id);await load()}catch(e){setError(e.message||"Unable to unacknowledge incident.")}};
 const addNote=async()=>{if(!selected||!note.trim())return;try{await api.addIncidentNote(token,selected.id,note.trim());setNote("");setSelected(null);await load()}catch(e){setError(e.message||"Unable to save incident note.")}};
 const incidents=data?.data||[]; const summary=data?.summary||{};
 return <div>
  <div className="page-head"><div><div className="eyebrow">OPERATIONS · INCIDENTS</div><h1>Production Incident Dashboard</h1><p>Critical alerts, acknowledgement state and on-call response at a glance.</p></div><div className="page-actions"><button onClick={load}>↻ Refresh</button></div></div>
  <section className="card">
   <div className="section-title"><div><h2>On-call access</h2><p>The Alertmanager token is kept in this browser session only.</p></div><span className="badge">Restricted</span></div>
   <div className="form-grid">
    <label>Responder name<input value={actor} onChange={e=>saveActor(e.target.value.slice(0,120))} placeholder="on-call engineer"/></label>
    <label>Dashboard token<input type="password" value={token} onChange={e=>saveToken(e.target.value)} placeholder="ALERTMANAGER_WEBHOOK_TOKEN" autoComplete="off"/></label>
   </div>
   <div className="page-actions"><button className="primary" onClick={load}>Connect to incident feed</button>{data&&<button onClick={()=>{sessionStorage.removeItem("medivault_ops_token");setToken("");setData(null)}}>Forget token</button>}</div>
  </section>
  {error&&<div className="auth-error">{error}</div>}
  <div className="stats-grid">
   <div className="card"><span className="stat-label">Open incidents</span><b className="stat-number">{loading?"…":summary.open??"—"}</b><small>{summary.generatedAt?new Date(summary.generatedAt).toLocaleTimeString():"Not connected"}</small></div>
   <div className="card"><span className="stat-label">Critical</span><b className="stat-number">{loading?"…":summary.critical??"—"}</b><small>Unresolved critical alerts</small></div>
   <div className="card"><span className="stat-label">Acknowledged</span><b className="stat-number">{loading?"…":summary.acknowledged??"—"}</b><small>Open incidents already owned</small></div>
   <div className="card"><span className="stat-label">Feed records</span><b className="stat-number">{loading?"…":summary.total??"—"}</b><small>Recent incident records</small></div>
  </div>
  <section className="card">
   <div className="section-title"><div><h2>Incident queue</h2><p>Use acknowledge to stop the next escalation window while the responder investigates.</p></div><select value={status} onChange={e=>{const next=e.target.value;setStatus(next);setTimeout(()=>load(next),0)}}><option value="firing">Open only</option><option value="resolved">Resolved</option><option value="">All statuses</option></select></div>
   {!data&&!loading?<div className="empty-state compact-empty"><div>🔐</div><h2>Operations feed locked</h2><p>Enter the restricted incident token above.</p></div>:loading?<div className="empty-state"><div>⏳</div><h2>Loading incidents…</h2></div>:incidents.length===0?<div className="empty-state compact-empty"><div>✅</div><h2>No incidents in this view</h2><p>The queue is clear for the selected status.</p></div>:<div className="record-list">{incidents.map(i=><article className="record-item" key={i.id}><div className="record-icon">{i.severity==='critical'?'🔴':i.severity==='warning'?'🟠':'🔵'}</div><div className="record-main"><b>{i.alertName} · {String(i.severity||'warning').toUpperCase()}</b><small>{i.status} · {i.acknowledgedAt?`Acknowledged by ${i.acknowledgedBy||'on-call'}`:'Unacknowledged'} · {i.lastReceivedAt?new Date(i.lastReceivedAt).toLocaleString():''}</small><p>{i.summary||i.description||'No alert description.'}</p>{i.responderNotes&&<code>Note: {i.responderNotes}</code>}</div><div className="page-actions">{i.status==='firing'&&(i.acknowledgedAt?<button onClick={()=>unack(i)}>Unacknowledge</button>:<button className="primary" onClick={()=>ack(i)}>Acknowledge</button>)}<button onClick={()=>{setSelected(i);setNote(i.responderNotes||'')}}>Note</button></div></article>)}</div>}
  </section>
  {selected&&<section className="card"><div className="section-title"><div><h2>Responder note</h2><p>{selected.alertName}</p></div><button onClick={()=>setSelected(null)}>Close</button></div><textarea value={note} onChange={e=>setNote(e.target.value.slice(0,4000))} placeholder="What did you observe, change or hand off?" rows={5}/><div className="page-actions"><button onClick={()=>setSelected(null)}>Cancel</button><button className="primary" onClick={addNote} disabled={!note.trim()}>Save note</button></div></section>}
  <div className="note">🛡️ This dashboard does not expose medical records. Keep the operations token private, rotate it when responders change, and place the internal incident endpoint behind a private network or authenticated gateway in production.</div>
 </div>
}


function OnCallManagementPage(){
 const [token,setToken]=useState(()=>sessionStorage.getItem("medivault_ops_token")||"");
 const [actor,setActor]=useState(()=>sessionStorage.getItem("medivault_oncall_actor")||"on-call");
 const [data,setData]=useState(null); const [error,setError]=useState(""); const [loading,setLoading]=useState(false);
 const [newRotation,setNewRotation]=useState({name:"Primary On-Call",timezone:"UTC"});
 const [newMember,setNewMember]=useState({name:"",email:"",role:"Primary"}); const [selectedRotation,setSelectedRotation]=useState("");
 const [policy,setPolicy]=useState({name:"Critical Default",description:"Production critical alert escalation policy",steps:[{level:1,delayMinutes:15,targetType:"webhook",targetRef:"on-call"},{level:2,delayMinutes:30,targetType:"webhook",targetRef:"secondary"},{level:3,delayMinutes:60,targetType:"webhook",targetRef:"incident-lead"}]});
 const [shift,setShift]=useState({memberId:"",startsAt:"",endsAt:""});
 const [generate,setGenerate]=useState({days:14,shiftDurationMinutes:1440,startAt:""});
 const [handoffNote,setHandoffNote]=useState("");
 const [coverage,setCoverage]=useState(null); const [coverageLoading,setCoverageLoading]=useState(false);
 const [overrides,setOverrides]=useState([]); const [override,setOverride]=useState({dateKey:"",type:"leave",memberId:"",replacementMemberId:"",mode:"replace",note:""});
 const [recurringRules,setRecurringRules]=useState([]); const [rule,setRule]=useState({type:"leave",recurrence:"weekly",memberId:"",replacementMemberId:"",mode:"replace",daysOfWeek:"1,2,3,4,5",startDate:"",endDate:"",note:""});
 const [holiday,setHoliday]=useState({country:"IN",year:new Date().getFullYear(),mode:"replace",replacementMemberId:"",items:[],source:"api"});
 const [customCalendars,setCustomCalendars]=useState([]); const [customCalendar,setCustomCalendar]=useState({name:"",countryCode:"IN",timezone:"Asia/Kolkata",sourceType:"custom",sourceUrl:""}); const [customHoliday,setCustomHoliday]=useState({calendarId:"",dateKey:"",name:"",observed:false}); const [customSyncYear,setCustomSyncYear]=useState(new Date().getFullYear());
 async function load(){ if(!token){setError("Enter the operations token to manage on-call settings.");return;} setLoading(true);setError("");try{sessionStorage.setItem("medivault_ops_token",token);sessionStorage.setItem("medivault_oncall_actor",actor||"on-call");const r=await api.onCallDashboard(token);setData(r.data); if(selectedRotation){const [ov,rr]=await Promise.all([api.onCallOverrides(token,selectedRotation),api.onCallRecurringRules(token,selectedRotation)]);setOverrides(ov.data||[]);setRecurringRules(rr.data||[]);} }catch(e){setError(e.message||"Unable to load on-call configuration.")}finally{setLoading(false)} }
 useEffect(()=>{if(token){load();loadCustomCalendars()}},[]);
 async function createRotation(){try{await api.createRotation(token,newRotation);setNewRotation({name:"",timezone:"UTC"});await load()}catch(e){setError(e.message||"Unable to create rotation")}}
 async function addMember(){if(!selectedRotation||!newMember.name.trim())return;try{await api.addOnCallMember(token,selectedRotation,newMember);setNewMember({name:"",email:"",role:"Primary"});await load()}catch(e){setError(e.message||"Unable to add member")}}
 async function savePolicy(){try{await api.createEscalationPolicy(token,policy);await load()}catch(e){setError(e.message||"Unable to create policy")}}
 async function addShift(){if(!shift.memberId||!shift.startsAt||!shift.endsAt)return;try{await api.createOnCallShift(token,{rotationId:selectedRotation,memberId:shift.memberId,startsAt:new Date(shift.startsAt).toISOString(),endsAt:new Date(shift.endsAt).toISOString()});setShift({memberId:"",startsAt:"",endsAt:""});await load()}catch(e){setError(e.message||"Unable to schedule shift")}}
 async function generateShifts(){if(!selectedRotation)return;const rotation=rotations.find(r=>r.id===selectedRotation);try{await api.generateOnCallShifts(token,selectedRotation,{days:Number(generate.days),shiftDurationMinutes:Number(generate.shiftDurationMinutes),startLocal:generate.startAt||undefined});await load()}catch(e){setError(e.message||"Unable to generate rotation schedule")}}
 async function handoffShift(id){try{await api.handoffOnCallShift(token,id,{note:handoffNote});setHandoffNote("");await load()}catch(e){setError(e.message||"Unable to complete handoff")}}
 async function validateCoverage(){if(!selectedRotation)return;setCoverageLoading(true);try{const r=await api.validateOnCallCoverage(token,selectedRotation,{startLocal:generate.startAt||undefined,days:Number(generate.days)||14});setCoverage(r.data);setError("")}catch(e){setError(e.message||"Unable to validate coverage")}finally{setCoverageLoading(false)}}
 async function loadOverrides(rotationId=selectedRotation){if(!rotationId||!token)return;try{const r=await api.onCallOverrides(token,rotationId);setOverrides(r.data||[])}catch(e){setError(e.message||"Unable to load schedule overrides")}}
 async function loadRules(rotationId=selectedRotation){if(!rotationId||!token)return;try{const r=await api.onCallRecurringRules(token,rotationId);setRecurringRules(r.data||[])}catch(e){setError(e.message||"Unable to load recurring rules")}}
 async function loadHoliday(){if(!token)return;try{const r=await api.holidayCalendars(token,holiday.country,Number(holiday.year));setHoliday(h=>({...h,items:r.data?.holidays||[],source:r.data?.source||"api"}))}catch(e){setError(e.message||"Unable to load holiday calendar")}}
 async function loadCustomCalendars(){if(!token)return;try{const r=await api.customHolidayCalendars(token);setCustomCalendars(r.data||[])}catch(e){setError(e.message||"Unable to load custom calendars")}}
 async function createCustomCalendar(){if(!customCalendar.name.trim())return;try{await api.createCustomHolidayCalendar(token,customCalendar);setCustomCalendar({name:"",countryCode:"IN",timezone:"Asia/Kolkata",sourceType:"custom",sourceUrl:""});await loadCustomCalendars()}catch(e){setError(e.message||"Unable to create custom calendar")}}
 async function addCustomHoliday(){if(!customHoliday.calendarId||!customHoliday.dateKey||!customHoliday.name.trim())return;try{await api.addCustomHoliday(token,customHoliday.calendarId,{...customHoliday});setCustomHoliday(x=>({...x,dateKey:"",name:"",observed:false}));await loadCustomCalendars()}catch(e){setError(e.message||"Unable to add custom holiday")}}
 async function syncCustomCalendar(id){try{const r=await api.syncCustomHolidayCalendar(token,id,Number(customSyncYear));setError(`Synced ${r.data?.createdCount||0} new holidays.`);await loadCustomCalendars()}catch(e){setError(e.message||"Unable to sync holiday calendar")}}
 async function applyCustomCalendar(id){if(!selectedRotation)return;try{const r=await api.applyCustomHolidayCalendar(token,selectedRotation,{calendarId:id,year:Number(customSyncYear),startDate:`${customSyncYear}-01-01`,endDate:`${customSyncYear}-12-31`,mode:holiday.mode,replacementMemberId:holiday.replacementMemberId||undefined});setError(`Applied ${r.data?.createdCount||0} custom holiday overrides.`);await loadOverrides()}catch(e){setError(e.message||"Unable to apply custom calendar")}}
 async function createRule(){if(!selectedRotation||!rule.startDate)return;try{await api.createOnCallRecurringRule(token,selectedRotation,{...rule,memberId:rule.memberId||undefined,replacementMemberId:rule.replacementMemberId||undefined});setRule({type:"leave",recurrence:"weekly",memberId:"",replacementMemberId:"",mode:"replace",daysOfWeek:"1,2,3,4,5",startDate:"",endDate:"",note:""});await loadRules()}catch(e){setError(e.message||"Unable to create recurring rule")}}
 async function deleteRule(id){try{await api.deleteOnCallRecurringRule(token,id);await loadRules()}catch(e){setError(e.message||"Unable to remove recurring rule")}}
 async function applyHolidayCalendar(){if(!selectedRotation)return;try{const r=await api.applyHolidayCalendar(token,selectedRotation,{country:holiday.country,year:Number(holiday.year),mode:holiday.mode,replacementMemberId:holiday.replacementMemberId||undefined});setError(`Applied ${r.data?.createdCount||0} holiday overrides.`);await loadOverrides()}catch(e){setError(e.message||"Unable to apply holiday calendar")}}
 async function createOverride(){if(!selectedRotation||!override.dateKey)return;try{await api.createOnCallOverride(token,selectedRotation,{...override,memberId:override.memberId||undefined,replacementMemberId:override.replacementMemberId||undefined});setOverride({dateKey:"",type:"leave",memberId:"",replacementMemberId:"",mode:"replace",note:""});await loadOverrides()}catch(e){setError(e.message||"Unable to create schedule override")}}
 async function deleteOverride(id){try{await api.deleteOnCallOverride(token,id);await loadOverrides()}catch(e){setError(e.message||"Unable to remove override")}}
 const active=data?.activeShift;
 const rotations=data?.rotations||[]; const policies=data?.policies||[];
 return <section>
  <div className="page-head"><div><div className="eyebrow">OPERATIONS · ON-CALL</div><h1>On-Call Management</h1><p>Manage rotation members, active shifts and escalation policy timing without touching patient data.</p></div><div className="page-actions"><button onClick={load}>↻ Refresh</button></div></div>
  <section className="card"><div className="section-title"><div><h2>Operations access</h2><p>Use the same private operations token configured for Alertmanager incident management.</p></div><span className="badge">Internal only</span></div><div className="two-col"><label>Operations token<input type="password" value={token} onChange={e=>setToken(e.target.value)} placeholder="x-alertmanager-token"/></label><label>Responder name<input value={actor} onChange={e=>setActor(e.target.value)} placeholder="on-call"/></label></div><div className="page-actions" style={{marginTop:10}}><button className="primary" onClick={load} disabled={loading}>{loading?"Connecting…":"Connect & load"}</button></div></section>
  {error&&<div className="auth-error">{error}</div>}
  {active&&<section className="card"><div className="section-title"><div><h2>Current on-call</h2><p>Schedule currently covering the system.</p></div><span className="badge">Active</span></div><div className="record-item"><div className="record-icon">📟</div><div className="record-main"><b>{active.member?.name||"Unknown responder"}</b><small>{active.rotation?.name||"Rotation"} · {new Date(active.startsAt).toLocaleString()} → {new Date(active.endsAt).toLocaleString()}</small><p>{active.member?.role||"Responder"}{active.member?.email?` · ${active.member.email}`:""}</p></div></div></section>}
  <section className="split-grid">
   <div className="card"><div className="section-title"><div><h2>Rotations</h2><p>Create a team and maintain its active responders.</p></div></div>{rotations.map(r=><article className="record-item" key={r.id}><div className="record-icon">👥</div><div className="record-main"><b>{r.name} <span className="badge">{r.active?"Active":"Paused"}</span></b><small>{r.timezone} · {r.members?.length||0} active members</small><div className="record-list" style={{marginTop:8}}>{(r.members||[]).map(m=><div key={m.id}><small>{m.name} · {m.role||"Responder"}{m.email?` · ${m.email}`:""}</small></div>)}</div></div></article>)}{rotations.length===0&&<div className="empty-state compact-empty"><div>👥</div><h2>No rotations</h2><p>Create the first on-call rotation.</p></div>}<div className="compact-form" style={{marginTop:12}}><div className="two-col"><label>Name<input value={newRotation.name} onChange={e=>setNewRotation({...newRotation,name:e.target.value})}/></label><label>Timezone<input value={newRotation.timezone} onChange={e=>setNewRotation({...newRotation,timezone:e.target.value})}/></label></div><button className="primary" style={{marginTop:10}} onClick={createRotation} disabled={!newRotation.name.trim()}>＋ Create rotation</button></div></div>
   <div className="card"><div className="section-title"><div><h2>Members & shifts</h2><p>Add responders and place them on a schedule.</p></div></div><label>Rotation<select value={selectedRotation} onChange={e=>{setSelectedRotation(e.target.value);setCoverage(null);loadOverrides(e.target.value);loadRules(e.target.value)}}><option value="">Select rotation</option>{rotations.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></label><div className="two-col" style={{marginTop:10}}><label>Member name<input value={newMember.name} onChange={e=>setNewMember({...newMember,name:e.target.value})}/></label><label>Role<input value={newMember.role} onChange={e=>setNewMember({...newMember,role:e.target.value})}/></label><label>Email<input value={newMember.email} onChange={e=>setNewMember({...newMember,email:e.target.value})}/></label></div><button style={{marginTop:10}} onClick={addMember} disabled={!selectedRotation||!newMember.name.trim()}>＋ Add member</button><hr style={{border:0,borderTop:"1px solid #edf1f1",margin:"14px 0"}}/><div className="two-col"><label>Shift member<select value={shift.memberId} onChange={e=>setShift({...shift,memberId:e.target.value})}><option value="">Select member</option>{rotations.find(r=>r.id===selectedRotation)?.members?.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label><label>Start<input type="datetime-local" value={shift.startsAt} onChange={e=>setShift({...shift,startsAt:e.target.value})}/></label><label>End<input type="datetime-local" value={shift.endsAt} onChange={e=>setShift({...shift,endsAt:e.target.value})}/></label></div><button className="primary" style={{marginTop:10}} onClick={addShift} disabled={!selectedRotation||!shift.memberId||!shift.startsAt||!shift.endsAt}>＋ Schedule shift</button></div>
  </section>
  <section className="card"><div className="section-title"><div><h2>Rotation calendar & handoffs</h2><p>Generate a forward schedule from the active responder order and hand over an active shift without losing the audit trail.</p></div><span className="badge">{data?.upcomingShifts?.length||0} upcoming</span></div>
   <div className="two-col"><label>Rotation<select value={selectedRotation} onChange={e=>setSelectedRotation(e.target.value)}><option value="">Select rotation</option>{rotations.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></label><label>Start date/time ({rotations.find(r=>r.id===selectedRotation)?.timezone||"rotation timezone"})<input type="datetime-local" value={generate.startAt} onChange={e=>setGenerate({...generate,startAt:e.target.value})}/></label><label>Days to generate<input type="number" min="1" max="90" value={generate.days} onChange={e=>setGenerate({...generate,days:e.target.value})}/></label><label>Shift length (minutes)<input type="number" min="30" value={generate.shiftDurationMinutes} onChange={e=>setGenerate({...generate,shiftDurationMinutes:e.target.value})}/></label></div><button className="primary" style={{marginTop:10}} onClick={generateShifts} disabled={!selectedRotation}>↻ Generate rotation calendar</button>
   <hr style={{border:0,borderTop:"1px solid #edf1f1",margin:"14px 0"}}/>
   <div className="form-grid"><label>Handoff note<input value={handoffNote} onChange={e=>setHandoffNote(e.target.value)} placeholder="Context for the incoming responder"/></label></div>
   {data?.upcomingShifts?.length ? <div className="list" style={{marginTop:10}}>{data.upcomingShifts.slice(0,12).map(sh=><div className="list-row" key={sh.id}><div><b>{sh.member?.name||"Responder"}</b><div className="muted">{sh.rotation?.name||"Rotation"} · {new Date(sh.startsAt).toLocaleString()} → {new Date(sh.endsAt).toLocaleString()}</div></div><div style={{display:"flex",gap:8}}><span className="badge">{sh.status}</span><button onClick={()=>handoffShift(sh.id)}>Handoff</button></div></div>)}</div> : <div className="empty">No upcoming shifts scheduled.</div>}
  </section>

  <section className="card"><div className="section-title"><div><h2>Leave & holiday overrides</h2><p>Apply rotation-timezone dates to skip a shift or replace an unavailable responder during schedule generation.</p></div><span className="badge">{overrides.length} overrides</span></div>
   <div className="two-col"><label>Date ({rotations.find(r=>r.id===selectedRotation)?.timezone||"timezone"})<input type="date" value={override.dateKey} onChange={e=>setOverride({...override,dateKey:e.target.value})}/></label><label>Type<select value={override.type} onChange={e=>setOverride({...override,type:e.target.value,memberId:e.target.value==="leave"?override.memberId:""})}><option value="leave">Leave</option><option value="holiday">Holiday</option></select></label><label>Unavailable member<select value={override.memberId} onChange={e=>setOverride({...override,memberId:e.target.value})} disabled={override.type==="holiday"}><option value="">All / select later</option>{rotations.find(r=>r.id===selectedRotation)?.members?.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label><label>Replacement<select value={override.replacementMemberId} onChange={e=>setOverride({...override,replacementMemberId:e.target.value})}><option value="">Auto next active</option>{rotations.find(r=>r.id===selectedRotation)?.members?.filter(m=>m.active).map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label><label>Mode<select value={override.mode} onChange={e=>setOverride({...override,mode:e.target.value})}><option value="replace">Replace responder</option><option value="skip">Skip shift</option></select></label><label>Note<input value={override.note} onChange={e=>setOverride({...override,note:e.target.value})} placeholder="Vacation, public holiday, etc."/></label></div>
   <button className="primary" style={{marginTop:10}} onClick={createOverride} disabled={!selectedRotation||!override.dateKey||(override.type==="leave"&&!override.memberId)}>＋ Add override</button>
   {overrides.length>0&&<div className="list" style={{marginTop:12}}>{overrides.slice(0,20).map(o=><div className="list-row" key={o.id}><div><b>{o.dateKey} · {o.type}</b><div className="muted">{o.member?.name||"All responders"} → {o.replacementMember?.name|| (o.mode==="skip"?"Skip shift":"Auto next active")} {o.note?`· ${o.note}`:""}</div></div><button onClick={()=>deleteOverride(o.id)}>Remove</button></div>)}</div>}
  </section>
  <section className="card"><div className="section-title"><div><h2>Recurring leave rules</h2><p>Automatically apply weekly, monthly, annual or date-range unavailability during future schedule generation.</p></div><span className="badge">{recurringRules.length} rules</span></div>
   <div className="two-col"><label>Type<select value={rule.type} onChange={e=>setRule({...rule,type:e.target.value})}><option value="leave">Leave</option><option value="holiday">Holiday rule</option></select></label><label>Recurrence<select value={rule.recurrence} onChange={e=>setRule({...rule,recurrence:e.target.value})}><option value="weekly">Weekly</option><option value="monthly">Monthly</option><option value="annual">Annual</option><option value="date_range">Date range</option></select></label><label>Start date<input type="date" value={rule.startDate} onChange={e=>setRule({...rule,startDate:e.target.value})}/></label><label>End date<input type="date" value={rule.endDate} onChange={e=>setRule({...rule,endDate:e.target.value})}/></label>{rule.type==='leave'&&<label>Unavailable member<select value={rule.memberId} onChange={e=>setRule({...rule,memberId:e.target.value})}><option value="">Select member</option>{rotations.find(r=>r.id===selectedRotation)?.members?.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label>}<label>Replacement<select value={rule.replacementMemberId} onChange={e=>setRule({...rule,replacementMemberId:e.target.value})}><option value="">Auto next active</option>{rotations.find(r=>r.id===selectedRotation)?.members?.filter(m=>m.active).map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label><label>Mode<select value={rule.mode} onChange={e=>setRule({...rule,mode:e.target.value})}><option value="replace">Replace responder</option><option value="skip">Skip shift</option></select></label>{rule.recurrence==='weekly'&&<label>Weekdays (0 Sun … 6 Sat)<input value={rule.daysOfWeek} onChange={e=>setRule({...rule,daysOfWeek:e.target.value})} placeholder="1,2,3,4,5"/></label>}<label>Note<input value={rule.note} onChange={e=>setRule({...rule,note:e.target.value})} placeholder="Recurring vacation / weekend rule"/></label></div>
   <button className="primary" style={{marginTop:10}} onClick={createRule} disabled={!selectedRotation||!rule.startDate||(rule.type==='leave'&&!rule.memberId)}>＋ Add recurring rule</button>
   {recurringRules.length>0&&<div className="list" style={{marginTop:12}}>{recurringRules.slice(0,20).map(r=><div className="list-row" key={r.id}><div><b>{r.type} · {r.recurrence} · {r.startDate}</b><div className="muted">{r.member?.name||"All responders"} → {r.replacementMember?.name|| (r.mode==='skip'?"Skip shift":"Auto next active")} {r.daysOfWeek?`· days ${r.daysOfWeek}`:""} {r.note?`· ${r.note}`:""}</div></div><button onClick={()=>deleteRule(r.id)}>Remove</button></div>)}</div>}
  </section>
  <section className="card"><div className="section-title"><div><h2>Official holiday API integration</h2><p>Fetch public holidays from the configurable holiday provider; built-in calendars remain the fallback.</p></div><span className="badge">API + fallback</span></div>
   <div className="two-col"><label>Country<input maxLength="2" value={holiday.country} onChange={e=>setHoliday({...holiday,country:e.target.value.toUpperCase()})}/></label><label>Year<input type="number" min="2000" max="2100" value={holiday.year} onChange={e=>setHoliday({...holiday,year:e.target.value})}/></label><label>Source<select value={holiday.source} onChange={e=>setHoliday({...holiday,source:e.target.value})}><option value="api">API with fallback</option><option value="api_strict">API only</option><option value="built_in">Built-in fallback</option></select></label><label>Apply mode<select value={holiday.mode} onChange={e=>setHoliday({...holiday,mode:e.target.value})}><option value="replace">Replace responder</option><option value="skip">Skip shift</option></select></label><label>Replacement<select value={holiday.replacementMemberId} onChange={e=>setHoliday({...holiday,replacementMemberId:e.target.value})} disabled={holiday.mode==='skip'}><option value="">Select active member</option>{rotations.find(r=>r.id===selectedRotation)?.members?.filter(m=>m.active).map(m=><option key={m.id} value={m.id}>{m.name}</option>)}</select></label></div>
   <div className="page-actions" style={{marginTop:10}}><button onClick={loadHoliday}>Load holidays</button><button className="primary" onClick={applyHolidayCalendar} disabled={!selectedRotation||!holiday.items.length||(holiday.mode==='replace'&&!holiday.replacementMemberId)}>Apply API holidays</button></div>
   {holiday.items.length>0&&<div className="list" style={{marginTop:12}}>{holiday.items.map(h=><div className="list-row" key={`${h.dateKey}-${h.name}`}><div><b>{h.dateKey}</b><div className="muted">{h.name}</div></div><span className="badge">{h.source}</span></div>)}</div>}
  </section>
  <section className="card"><div className="section-title"><div><h2>Custom holiday calendars</h2><p>Create your own calendar, add dates manually, optionally sync an API source, and apply it to a rotation.</p></div><span className="badge">{customCalendars.length} calendars</span></div>
   <div className="two-col"><label>Calendar name<input value={customCalendar.name} onChange={e=>setCustomCalendar({...customCalendar,name:e.target.value})} placeholder="Hospital holidays 2027"/></label><label>Country code<input maxLength="2" value={customCalendar.countryCode} onChange={e=>setCustomCalendar({...customCalendar,countryCode:e.target.value.toUpperCase()})}/></label><label>Timezone<input value={customCalendar.timezone} onChange={e=>setCustomCalendar({...customCalendar,timezone:e.target.value})} placeholder="Asia/Kolkata"/></label><label>Source type<select value={customCalendar.sourceType} onChange={e=>setCustomCalendar({...customCalendar,sourceType:e.target.value})}><option value="custom">Manual</option><option value="api">API-backed</option></select></label><label>Custom API URL template (optional)<input value={customCalendar.sourceUrl} onChange={e=>setCustomCalendar({...customCalendar,sourceUrl:e.target.value})} placeholder="https://example/api/{year}/{country}"/></label></div>
   <div className="page-actions" style={{marginTop:10}}><button className="primary" onClick={createCustomCalendar} disabled={!customCalendar.name.trim()}>＋ Create calendar</button><button onClick={loadCustomCalendars}>↻ Refresh calendars</button></div>
   <div className="two-col" style={{marginTop:12}}><label>Calendar<select value={customHoliday.calendarId} onChange={e=>setCustomHoliday({...customHoliday,calendarId:e.target.value})}><option value="">Select calendar</option>{customCalendars.map(c=><option key={c.id} value={c.id}>{c.name}</option>)}</select></label><label>Date<input type="date" value={customHoliday.dateKey} onChange={e=>setCustomHoliday({...customHoliday,dateKey:e.target.value})}/></label><label>Holiday name<input value={customHoliday.name} onChange={e=>setCustomHoliday({...customHoliday,name:e.target.value})}/></label><label>Observed<input type="checkbox" checked={customHoliday.observed} onChange={e=>setCustomHoliday({...customHoliday,observed:e.target.checked})}/></label></div>
   <div className="page-actions" style={{marginTop:10}}><button onClick={addCustomHoliday} disabled={!customHoliday.calendarId||!customHoliday.dateKey||!customHoliday.name.trim()}>＋ Add date</button><label style={{display:"flex",alignItems:"center",gap:8}}>Sync year<input style={{maxWidth:110}} type="number" min="2000" max="2100" value={customSyncYear} onChange={e=>setCustomSyncYear(e.target.value)}/></label></div>
   {customCalendars.length>0&&<div className="list" style={{marginTop:12}}>{customCalendars.map(c=><div className="list-row" key={c.id}><div><b>{c.name}</b><div className="muted">{c.countryCode||"—"} · {c.timezone} · {c.holidays?.length||0} dates · {c.sourceType}</div></div><div className="page-actions"><button onClick={()=>syncCustomCalendar(c.id)} disabled={!c.countryCode}>Sync</button><button className="primary" onClick={()=>applyCustomCalendar(c.id)} disabled={!selectedRotation||(!holiday.replacementMemberId&&holiday.mode==='replace')}>Apply</button></div></div>)}</div>}
  </section>

  <section className="card"><div className="section-title"><div><h2>Coverage & conflict check</h2><p>Validate that the selected rotation has continuous coverage and no overlapping or inactive-responder shifts.</p></div><span className={coverage?.covered?"badge":"badge warn"}>{coverage?coverage.covered?"Covered":"Action needed":"Not checked"}</span></div><div className="two-col"><label>Rotation<select value={selectedRotation} onChange={e=>{setSelectedRotation(e.target.value);setCoverage(null)}}><option value="">Select rotation</option>{rotations.map(r=><option key={r.id} value={r.id}>{r.name}</option>)}</select></label><label>Window (days)<input type="number" min="1" max="90" value={generate.days} onChange={e=>setGenerate({...generate,days:e.target.value})}/></label></div><button className="primary" style={{marginTop:10}} onClick={validateCoverage} disabled={!selectedRotation||coverageLoading}>{coverageLoading?"Checking…":"✓ Validate schedule"}</button>{coverage&&<div className="record-list" style={{marginTop:12}}><div className="setting-row"><div><b>{coverage.shiftCount} shifts checked</b><small>{coverage.conflicts?.length||0} conflict(s) · {coverage.gaps?.length||0} coverage gap(s)</small></div><span className="badge">{coverage.covered?"Ready":"Needs attention"}</span></div>{(coverage.conflicts||[]).map((c,i)=><div className="record-item" key={`c${i}`}><div className="record-icon">⚠️</div><div className="record-main"><b>{c.type.replaceAll("_"," ")}</b><small>{c.message}</small></div></div>)}{(coverage.gaps||[]).map((g,i)=><div className="record-item" key={`g${i}`}><div className="record-icon">⏱️</div><div className="record-main"><b>Coverage gap</b><small>{new Date(g.start).toLocaleString()} → {new Date(g.end).toLocaleString()}</small></div></div>)}{coverage.covered&&<div className="note">✅ Continuous coverage confirmed for this validation window.</div>}</div>}</section>
  <section className="card"><div className="section-title"><div><h2>Escalation policies</h2><p>Define how unacknowledged critical incidents move through responders.</p></div><span className="badge">{policies.length} policies</span></div>{policies.map(p=><article className="record-item" key={p.id}><div className="record-icon">🚨</div><div className="record-main"><b>{p.name} <span className="badge">{p.active?"Active":"Paused"}</span></b><small>{p.description||"No description"}</small>{(p.steps||[]).map(st=><div key={st.id} style={{marginTop:6}}><small>Level {st.level} · wait {st.delayMinutes} min · {st.targetType}: {st.targetRef}</small></div>)}</div></article>)}<div className="compact-form" style={{marginTop:12}}><div className="two-col"><label>Policy name<input value={policy.name} onChange={e=>setPolicy({...policy,name:e.target.value})}/></label><label>Description<input value={policy.description} onChange={e=>setPolicy({...policy,description:e.target.value})}/></label></div><div style={{display:"grid",gap:7,marginTop:10}}>{policy.steps.map((st,i)=><div key={i} className="setting-row"><div><b>Level {st.level}</b><small>{st.targetType} → {st.targetRef}</small></div><input style={{maxWidth:90}} type="number" min="1" value={st.delayMinutes} onChange={e=>setPolicy({...policy,steps:policy.steps.map((x,j)=>j===i?{...x,delayMinutes:e.target.value}:x)})}/><button onClick={()=>setPolicy({...policy,steps:policy.steps.filter((_,j)=>j!==i)})}>Remove</button></div>)}</div><button style={{marginTop:8}} onClick={()=>setPolicy({...policy,steps:[...policy.steps,{level:policy.steps.length+1,delayMinutes:30,targetType:"webhook",targetRef:"next-on-call"}]})}>＋ Add level</button><button className="primary" style={{marginTop:10}} onClick={savePolicy} disabled={!policy.name.trim()}>＋ Save as policy</button></div></section>
  <div className="note">🔐 On-call names/contact details and escalation routing are operational metadata. Keep this module behind a private gateway, use a short-lived operations token, and store real paging/webhook credentials in a secret manager.</div>
 </section>
}

function SecurityDashboardPage(){
 const [logs,setLogs]=useState([]);
 const [sessions,setSessions]=useState([]);
 const [mfa,setMfa]=useState(null);
 const [securityEvents,setSecurityEvents]=useState([]);
 const [loading,setLoading]=useState(true);
 const [error,setError]=useState("");
 async function load(){
   setLoading(true); setError("");
   try{
     const [a,s,m,e]=await Promise.all([api.auditLogs(100),api.sessions(),api.mfaStatus(),api.securityEvents(100,7)]);
     setLogs(a.data||[]); setSessions(s.data||[]); setMfa(m); setSecurityEvents(e.data||[]);
   }catch(e){setError(e.message||"Unable to load security status.");}
   finally{setLoading(false);}
 }
 useEffect(()=>{load()},[]);
 const failed=logs.filter(x=>x.outcome==="failure"||x.statusCode>=400);
 const recentFailures=failed.filter(x=>Date.now()-new Date(x.createdAt).getTime()<86400000);
 const trusted=mfa?.trustedDevices||[];
 const score=(mfa?.enabled?40:0)+(sessions.length?25:15)+(recentFailures.length===0?20:0)+(trusted.length?10:5)+(logs.length?5:0);
 const badge=score>=85?"Strong":score>=65?"Good":"Needs attention";
 return <div>
  <div className="page-head"><div><div className="eyebrow">SECURITY</div><h1>Security Dashboard</h1><p>Monitor account protection, active access and recent security activity.</p></div><div className="page-actions"><button onClick={load}>↻ Refresh</button></div></div>
  {error&&<div className="auth-error">{error}</div>}
  {loading?<div className="empty-state card"><div>⏳</div><h2>Loading security status…</h2></div>:<>
  <section className="security-summary-grid">
   <div className="card security-score"><span className="security-score-ring">{score}</span><div><b>Security score</b><small>{badge}. Improve protection by enabling MFA and reviewing trusted devices.</small></div></div>
   <div className="card"><span className="stat-label">MFA</span><b className="stat-number">{mfa?.enabled?"Enabled":"Off"}</b><small>{mfa?.enabled?"Authenticator protection is active.":"Enable MFA from Settings."}</small></div>
   <div className="card"><span className="stat-label">Active sessions</span><b className="stat-number">{sessions.length}</b><small>{sessions.filter(x=>!x.current).length} other device session{sessions.filter(x=>!x.current).length===1?"":"s"}</small></div>
   <div className="card"><span className="stat-label">24h failed events</span><b className="stat-number">{recentFailures.length}</b><small>{recentFailures.length===0?"No recent failed security events.":"Review recent activity below."}</small></div>
  </section>
  <section className="security-grid">
   <div className="card"><div className="section-title"><div><h2>Recent security alerts</h2><p>Derived from server-side audit activity.</p></div><span className="badge">{securityEvents.length} events</span></div>
    {securityEvents.length===0?<div className="empty-state compact-empty"><div>✅</div><h2>No security alerts</h2><p>No persisted security events were returned in the selected window.</p></div>:<div className="record-list">{securityEvents.slice(0,8).map(x=><article className="record-item" key={x.id}><div className="record-icon">⚠️</div><div className="record-main"><b>{x.action||"Security event"} · {x.resource}</b><small>{new Date(x.createdAt).toLocaleString()} · HTTP {x.statusCode}</small><p>{x.type||"Security event"}{x.ipAddress?` · ${x.ipAddress}`:""}</p></div><span className="badge badge-warn">Review</span></article>)}</div>}
   </div>
   <div className="card"><div className="section-title"><div><h2>Protection checklist</h2><p>Quick account-security review.</p></div></div>
    <div className="security-checks">
      <div><span>{mfa?.enabled?"✅":"⚠️"}</span><div><b>Multi-factor authentication</b><small>{mfa?.enabled?"Enabled":"Enable TOTP MFA in Settings."}</small></div></div>
      <div><span>✅</span><div><b>Server-side sessions</b><small>Active sessions can be revoked remotely.</small></div></div>
      <div><span>{trusted.length?"✅":"ℹ️"}</span><div><b>Trusted devices</b><small>{trusted.length?`${trusted.length} trusted device${trusted.length===1?"":"s"}.`:"No trusted device currently stored."}</small></div></div>
      <div><span>✅</span><div><b>Audit logging</b><small>Authentication and security actions are logged.</small></div></div>
    </div>
   </div>
  </section>
  <div className="note">🛡️ This dashboard reports application-level security telemetry. Production deployments should add centralized alerting, tamper-resistant logs, incident response rules and periodic security reviews.</div>
  </>}
 </div>
}

function NotificationsPage(){
 const [items,setItems]=useState([]);
 const [loading,setLoading]=useState(true);
 const [error,setError]=useState("");
 const [pushState,setPushState]=useState("checking");
 async function load(){ setLoading(true); setError(""); try{ const r=await api.notifications(); setItems(r.data||[]); }catch(err){ setError(err.message||"Unable to load notifications."); }finally{setLoading(false);} }
 useEffect(()=>{ load(); checkPush(); },[]);
 async function checkPush(){
   if(!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)){ setPushState('unsupported'); return; }
   try{ const reg=await navigator.serviceWorker.getRegistration('/'); const sub=reg&&await reg.pushManager.getSubscription(); setPushState(sub?'enabled':Notification.permission==='denied'?'blocked':'ready'); }catch(_){ setPushState('ready'); }
 }
 function urlBase64ToUint8Array(base64String){ const padding='='.repeat((4-base64String.length%4)%4); const base64=(base64String+padding).replace(/-/g,'+').replace(/_/g,'/'); const raw=atob(base64); return Uint8Array.from([...raw].map(c=>c.charCodeAt(0))); }
 async function enablePush(){
   setError("");
   try{
     if(!('Notification' in window) || !('serviceWorker' in navigator) || !('PushManager' in window)) throw new Error('This browser does not support Web Push.');
     const key=await api.pushPublicKey(); if(!key.configured||!key.publicKey) throw new Error('Web Push provider is not configured on the server yet.');
     const permission=await Notification.requestPermission(); if(permission!=='granted'){ setPushState('blocked'); throw new Error('Notification permission was not granted.'); }
     const reg=await navigator.serviceWorker.register('/sw.js');
     const subscription=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:urlBase64ToUint8Array(key.publicKey)});
     await api.subscribePush(subscription.toJSON()); setPushState('enabled');
   }catch(err){ setError(err.message||'Unable to enable push notifications.'); }
 }
 async function disablePush(){
   setError("");
   try{ const reg=await navigator.serviceWorker.getRegistration('/'); const sub=reg&&await reg.pushManager.getSubscription(); if(sub){ await api.unsubscribePush(sub.endpoint); await sub.unsubscribe(); } setPushState('ready'); }catch(err){ setError(err.message||'Unable to disable push notifications.'); }
 }
 async function mark(id){ try{ await api.markNotificationRead(id); setItems(prev=>prev.map(x=>x.id===id?{...x,readAt:new Date().toISOString()}:x)); }catch(err){ setError(err.message||"Unable to update notification."); } }
 async function markAll(){ try{ await api.markAllNotificationsRead(); setItems(prev=>prev.map(x=>({...x,readAt:x.readAt||new Date().toISOString()}))); }catch(err){ setError(err.message||"Unable to update notifications."); } }
 const unread=items.filter(x=>!x.readAt).length;
 return <div><div className="page-head"><div><div className="eyebrow">NOTIFICATIONS</div><h1>Health Notifications</h1><p>In-app reminders plus optional browser push and email delivery.</p></div><div className="page-actions"><button onClick={load}>↻ Refresh</button><button className="primary" onClick={markAll} disabled={!unread}>✓ Mark all read</button></div></div>
  <section className="card"><div className="section-title"><div><h2>Delivery</h2><p>Enable browser push for this device.</p></div><span className="badge">{pushState==='enabled'?'Push enabled':pushState==='unsupported'?'Not supported':pushState==='blocked'?'Blocked':'Ready'}</span></div>
   <div className="form-grid"><div><b>Browser push</b><p className="muted">Push requires HTTPS in production and VAPID keys on the server.</p></div><div className="page-actions">{pushState==='enabled'?<button onClick={disablePush}>Disable push</button>:<button className="primary" onClick={enablePush} disabled={pushState==='unsupported'||pushState==='blocked'}>Enable push</button>}</div></div>
  </section>
  <section className="card"><div className="section-title"><div><h2>{unread?`${unread} unread notification${unread===1?"":"s"}`:"All caught up"}</h2><p>Reminder worker checks upcoming calendar events on the server.</p></div><span className="badge">Worker connected</span></div>
   {error&&<div className="auth-error">{error}</div>}
   {loading?<div className="empty-state"><div>⏳</div><h2>Loading notifications…</h2></div>:items.length===0?<div className="empty-state"><div>🔔</div><h2>No notifications yet</h2><p>Add a calendar reminder scheduled within the worker window.</p></div>:<div className="record-list">{items.map(x=><article className={x.readAt?"record-item":"record-item unread-row"} key={x.id}><div className="record-icon">{x.type==="REMINDER"?"🔔":"ℹ️"}</div><div className="record-main"><b>{x.title}</b><small>{new Date(x.scheduledFor).toLocaleString()}</small><p>{x.body}</p></div><button onClick={()=>mark(x.id)} disabled={!!x.readAt}>{x.readAt?"✓ Read":"Mark read"}</button></article>)}</div>}
  </section>
  <div className="note">📧 Email delivery uses SMTP when EMAIL_ENABLED=true. 🔔 Browser push uses VAPID when VAPID keys are configured. No provider is enabled by default.</div>
 </div>
}


function ActivityHistoryPage(){
 const [items,setItems]=useState([]);
 const [loading,setLoading]=useState(true);
 const [error,setError]=useState("");
 async function load(){setLoading(true);setError("");try{const r=await api.auditLogs(100);setItems(r.data||[])}catch(e){setError(e.message||"Unable to load activity history.")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 const label=(x)=>{const map={AUTH_LOGIN:"Signed in",AUTH_LOGOUT:"Signed out",AUTH_REGISTER:"Account created",READ:"Viewed",CREATE:"Created",UPDATE:"Updated",DELETE:"Deleted"};return map[x]||x};
 return <div>
  <div className="page-head"><div><div className="eyebrow">SECURITY AUDIT</div><h1>Activity History</h1><p>A server-side audit trail of account and health-data access.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
  <section className="card"><div className="section-title"><div><h2>Recent activity</h2><p>{items.length} event{items.length===1?"":"s"}</p></div><span className="badge">Server audit log</span></div>
   {error&&<div className="auth-error">{error}</div>}
   {loading?<div className="empty-state"><div>⏳</div><h2>Loading activity…</h2></div>:items.length===0?<div className="empty-state"><div>🧾</div><h2>No activity recorded yet</h2></div>:<div className="record-list">{items.map(x=><article className="record-item" key={x.id}><div className="record-icon">{x.outcome==="failure"?"⚠️":"🛡️"}</div><div className="record-main"><b>{label(x.action)} · {x.resource}</b><small>{new Date(x.createdAt).toLocaleString()} · {x.method} · {x.statusCode}</small><p>{x.path}</p><code>{x.outcome}{x.ipAddress?` · ${x.ipAddress}`:""}</code></div></article>)}</div>}
  </section>
  <div className="note">🛡️ Audit entries exclude request bodies, passwords and session tokens. Production deployments should add tamper-resistant retention, alerting and centralized log storage.</div>
 </div>
}

function ActiveSessionsPage(){
 const [items,setItems]=useState([]); const [loading,setLoading]=useState(true); const [error,setError]=useState(""); const [busy,setBusy]=useState(false);
 async function load(){setLoading(true);setError("");try{const r=await api.sessions();setItems(r.data||[])}catch(e){setError(e.message||"Unable to load sessions.")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 const revoke=async(id)=>{setBusy(true);setError("");try{await api.revokeSession(id);setItems(x=>x.filter(s=>s.id!==id))}catch(e){setError(e.message||"Unable to revoke session.")}finally{setBusy(false)}};
 const revokeOthers=async()=>{if(!window.confirm("Sign out all other active sessions?"))return;setBusy(true);setError("");try{await api.revokeOtherSessions();await load()}catch(e){setError(e.message||"Unable to revoke sessions.")}finally{setBusy(false)}};
 const device=(ua)=>{if(!ua)return"Unknown device"; if(/Android/i.test(ua))return"Android device"; if(/iPhone|iPad/i.test(ua))return"iPhone/iPad"; if(/Windows/i.test(ua))return"Windows browser"; if(/Macintosh/i.test(ua))return"Mac browser"; if(/Linux/i.test(ua))return"Linux browser"; return"Web browser"};
 return <div><div className="page-head"><div><div className="eyebrow">SECURITY</div><h1>Active Sessions</h1><p>Review signed-in devices and remotely revoke sessions you no longer trust.</p></div><div className="page-actions"><button onClick={load}>↻ Refresh</button><button className="primary" onClick={revokeOthers} disabled={busy||items.filter(s=>!s.current).length===0}>Sign out other sessions</button></div></div>
  <section className="card"><div className="section-title"><div><h2>{items.length} active session{items.length===1?"":"s"}</h2><p>Your current browser is marked as the current session.</p></div><span className="badge">Server-side session store</span></div>
   {error&&<div className="auth-error">{error}</div>}
   {loading?<div className="empty-state"><div>⏳</div><h2>Loading sessions…</h2></div>:items.length===0?<div className="empty-state"><div>📱</div><h2>No active sessions</h2></div>:<div className="record-list">{items.map(s=><article className="record-item" key={s.id}><div className="record-icon">{s.current?"✅":"📱"}</div><div className="record-main"><b>{s.current?"This device":"Active session"} · {device(s.userAgent)}</b><small>Last used {new Date(s.lastUsedAt).toLocaleString()} · Created {new Date(s.createdAt).toLocaleString()}</small><p>Expires {new Date(s.expiresAt).toLocaleString()}{s.ipAddress?` · IP ${s.ipAddress}`:""}</p><code>{s.userAgent||"No user-agent recorded"}</code></div>{s.current?<span className="badge">Current</span>:<button onClick={()=>revoke(s.id)} disabled={busy}>Revoke</button>}</article>)}</div>}
  </section><div className="note">🔐 Revoking a session removes its server-side session token. Remote logout does not remove medical data or trusted-device records.</div>
 </div>
}

function LoadingScreen(){
 return <div className="auth-shell"><div className="auth-loading card"><div className="logo">M</div><h1>MediVault</h1><p>Checking your secure session…</p></div></div>;
}

function AuthPage({onAuthenticated,apiBase}){
 const params=new URLSearchParams(window.location.search);
 const verifyToken=params.get("verify");
 const resetToken=params.get("reset");
 const [mode,setMode]=useState(resetToken?"reset":verifyToken?"verify":"login");
 const [email,setEmail]=useState("");
 const [password,setPassword]=useState("");
 const [name,setName]=useState("");
 const [busy,setBusy]=useState(false);
 const [error,setError]=useState("");
 const [message,setMessage]=useState("");
 const [showPassword,setShowPassword]=useState(false);
 const [mfaChallenge,setMfaChallenge]=useState(null);
 const [mfaCode,setMfaCode]=useState("");
 const [trustDevice,setTrustDevice]=useState(true);

 async function submit(e){
  e.preventDefault();
  setBusy(true); setError(""); setMessage("");
  try{
   if(mode==="reset"){
    await api.resetPassword(resetToken,password);
    window.history.replaceState({},"",window.location.pathname);
    setMode("login"); setPassword(""); setMessage("Password updated successfully. Please sign in.");
    return;
   }
   const payload=mode==="register"?{name,email,password}:{email,password};
   const result=mode==="register"?await api.register(payload):await api.login(payload);
   if(mode==="login" && result.mfaRequired){ setMfaChallenge(result.challenge); setMode("mfa"); setMessage("Enter the 6-digit code from your authenticator app."); return; }
   if(mode==="register"){
    setMessage(result.verificationSent?"Account created. Check your email to verify the account before signing in.":"Account created. Email delivery is not configured yet; configure SMTP to complete verification.");
    setMode("verify");
    return;
   }
   onAuthenticated(result.user);
  }catch(err){
   if(err.code==="EMAIL_NOT_VERIFIED"||err.status===403){ setMode("verify"); }
   setError(err.message||"Unable to authenticate.");
  } finally{ setBusy(false); }
 }

 async function verify(){
  setBusy(true); setError(""); setMessage("");
  try{
   const result=await api.verifyEmail(verifyToken);
   window.history.replaceState({},"",window.location.pathname);
   setMessage("Email verified successfully. You can now sign in.");
   setEmail(result.user?.email||email); setMode("login");
  }catch(err){setError(err.message||"Unable to verify email.")}
  finally{setBusy(false)}
 }

 async function resend(){
  setBusy(true); setError(""); setMessage("");
  try{ const r=await api.resendVerification(email); setMessage(r.message); }
  catch(err){setError(err.message||"Unable to send verification email.")}
  finally{setBusy(false)}
 }

 async function requestReset(){
  setBusy(true); setError(""); setMessage("");
  try{ const r=await api.requestPasswordReset(email); setMessage(r.message); }
  catch(err){setError(err.message||"Unable to start password recovery.")}
  finally{setBusy(false)}
 }

 async function verifyMfaLogin(e){
  e.preventDefault(); setBusy(true); setError("");
  try{ const result=await api.mfaVerifyLogin(mfaChallenge,mfaCode,trustDevice,"Android browser"); onAuthenticated(result.user); }catch(err){setError(err.message||"Unable to verify MFA.");}finally{setBusy(false)}
 }

 if(mode==="mfa") return <div className="auth-shell"><section className="auth-card"><div className="auth-brand"><div className="logo">M</div><div><strong>MediVault</strong><small>Personal Health Organizer</small></div></div><div className="auth-head"><div className="eyebrow">TWO-FACTOR AUTHENTICATION</div><h1>Verify your sign-in</h1><p>Enter the 6-digit code from your authenticator app, or use a recovery code.</p></div>{error&&<div className="auth-error">{error}</div>}{message&&<div className="auth-success">{message}</div>}<form className="auth-form" onSubmit={verifyMfaLogin}><label>Authentication code<input inputMode="numeric" autoComplete="one-time-code" value={mfaCode} onChange={e=>setMfaCode(e.target.value)} placeholder="123456" maxLength={20} required/></label><label className="setting-row"><div><b>Trust this device</b><small>Skip MFA on this device for a limited time.</small></div><button type="button" className={trustDevice?"switch on":"switch"} onClick={()=>setTrustDevice(v=>!v)}><i></i></button></label><button className="primary auth-submit" disabled={busy}>{busy?"Verifying…":"Verify & continue"}</button></form><button className="auth-switch" onClick={()=>{setMode("login");setMfaChallenge(null);setMfaCode("");setMessage("");setError("")}}>Back to sign in</button><div className="auth-meta">Recovery codes can be used once each.</div></section></div>;

 if(mode==="verify"&&verifyToken) return <div className="auth-shell"><section className="auth-card"><div className="auth-brand"><div className="logo">M</div><div><strong>MediVault</strong><small>Personal Health Organizer</small></div></div><div className="auth-head"><div className="eyebrow">EMAIL VERIFICATION</div><h1>Verify your email</h1><p>Confirm the email address for your MediVault account.</p></div>{error&&<div className="auth-error">{error}</div>}{message&&<div className="auth-success">{message}</div>}<button className="primary auth-submit" onClick={verify} disabled={busy}>{busy?"Verifying…":"Verify email"}</button><button className="auth-switch" onClick={()=>{window.history.replaceState({},"",window.location.pathname);setMode("login")}}>Back to sign in</button></section></div>;

 return <div className="auth-shell">
  <section className="auth-card">
   <div className="auth-brand"><div className="logo">M</div><div><strong>MediVault</strong><small>Personal Health Organizer</small></div></div>
   <div className="auth-head"><div className="eyebrow">SECURE ACCOUNT</div><h1>{mode==="login"?"Welcome back":mode==="register"?"Create your account":mode==="reset"?"Set a new password":"Verify your email"}</h1><p>{mode==="login"?"Sign in to access your health records and tools.":mode==="register"?"Create a private account to keep your health data organized.":mode==="reset"?"Choose a new password for your MediVault account.":"Check your email to complete account verification."}</p></div>
   {mode==="verify"?<>
    <label className="auth-form">Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" /></label>
    {error&&<div className="auth-error">{error}</div>}{message&&<div className="auth-success">{message}</div>}
    <button className="primary auth-submit" onClick={resend} disabled={busy}>{busy?"Sending…":"Resend verification email"}</button>
    <button className="auth-switch" onClick={()=>{setMode("login");setError("");setMessage("")}}>Back to sign in</button>
   </>:mode==="reset"?<form onSubmit={submit} className="auth-form">
    <label>New password<div className="password-wrap"><input type={showPassword?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Minimum 8 characters" minLength={8} required autoComplete="new-password"/><button type="button" onClick={()=>setShowPassword(v=>!v)}>{showPassword?"Hide":"Show"}</button></div></label>
    {error&&<div className="auth-error">{error}</div>}{message&&<div className="auth-success">{message}</div>}
    <button className="primary auth-submit" disabled={busy}>{busy?"Updating…":"Update password"}</button>
   </form>:<form onSubmit={mode==="recover"?e=>{e.preventDefault();requestReset()}:submit} className="auth-form">
    {mode==="register"&&<label>Full name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name" autoComplete="name" required /></label>}
    <label>Email<input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com" autoComplete="email" required /></label>
    {mode!=="recover"&&<label>Password<div className="password-wrap"><input type={showPassword?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Minimum 8 characters" autoComplete={mode==="login"?"current-password":"new-password"} minLength={8} required /><button type="button" onClick={()=>setShowPassword(v=>!v)}>{showPassword?"Hide":"Show"}</button></div></label>}
    {error&&<div className="auth-error">{error}</div>}{message&&<div className="auth-success">{message}</div>}
    <button className="primary auth-submit" disabled={busy}>{busy?(mode==="login"?"Signing in…":mode==="register"?"Creating…":"Sending…"):(mode==="login"?"Sign in":mode==="register"?"Create account":"Send reset link")}</button>
   </form>}
   {mode==="login"&&<button className="auth-switch" onClick={()=>{setMode("recover");setError("");setMessage("")}}>Forgot password?</button>}
   {mode==="login"||mode==="register"?<button className="auth-switch" onClick={()=>{setMode(mode==="login"?"register":"login");setError("");setMessage("")}}>{mode==="login"?"New to MediVault? Create an account":"Already have an account? Sign in"}</button>:null}
   <div className="auth-meta">API: {apiBase.replace(/^https?:\/\//,"")}</div>
   <div className="note">🔐 Passwords are hashed server-side. Verification and reset tokens are short-lived, hashed at rest and single-use. Configure SMTP and HTTPS before production deployment.</div>
  </section>
 </div>
}

function VitalsPage(){
 const [items,setItems]=useState([]),[profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState(false),[form,setForm]=useState({type:"Blood Pressure",value:"",unit:"mmHg",recordedAt:"",profileId:""});
 async function load(){setLoading(true);try{const [r,p]=await Promise.all([api.vitals(),api.profiles()]);setItems(r.data||[]);setProfiles(p.data||[])}catch(e){setError(e.message||"Unable to load vitals")}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const r=await api.createVital({...form,profileId:form.profileId||null,unit:form.unit||null,recordedAt:form.recordedAt?new Date(form.recordedAt).toISOString():null});setItems(x=>[r.data,...x]);setForm({type:"Blood Pressure",value:"",unit:"mmHg",recordedAt:"",profileId:""})}catch(e){setError(e.message||"Unable to save vital")}finally{setBusy(false)}}
 async function remove(id){if(!window.confirm("Delete this vital entry?"))return;try{await api.deleteVital(id);setItems(x=>x.filter(i=>i.id!==id))}catch(e){setError(e.message||"Unable to delete vital")}}
 return <div><div className="page-head"><div><div className="eyebrow">VITALS & SYNC</div><h1>Vitals</h1><p>Blood pressure, heart rate, temperature and other readings stored in PostgreSQL.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div><section className="split-grid"><section className="card"><div className="section-title"><div><h2>Add vital</h2><p>Capture a health reading.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Vital type<select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))}><option>Blood Pressure</option><option>Heart Rate</option><option>Temperature</option><option>SpO₂</option><option>Weight</option><option>Blood Glucose</option><option>Other</option></select></label><label>Value<input value={form.value} onChange={e=>setForm(f=>({...f,value:e.target.value}))} placeholder="e.g. 120/80" required/></label><label>Unit<input value={form.unit} onChange={e=>setForm(f=>({...f,unit:e.target.value}))}/></label><label>Date/time<input type="datetime-local" value={form.recordedAt} onChange={e=>setForm(f=>({...f,recordedAt:e.target.value}))}/></label><label>Family profile<select value={form.profileId} onChange={e=>setForm(f=>({...f,profileId:e.target.value}))}><option value="">Myself</option>{profiles.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save vital"}</button></form></section><section className="card"><div className="section-title"><div><h2>Recent readings</h2><p>{items.length} reading{items.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading vitals…</h2></div>:items.length===0?<div className="empty-state"><div>❤️</div><h2>No vitals yet</h2></div>:<div className="record-list">{items.map(i=><article className="record-item" key={i.id}><div className="record-icon">❤️</div><div className="record-main"><b>{i.type}</b><small>{i.value}{i.unit?` ${i.unit}`:""}{i.recordedAt?` · ${new Date(i.recordedAt).toLocaleString()}`:""}</small><code>{i.profileId?`Profile ${i.profileId}`:"My health record"}</code></div><button className="danger-text" onClick={()=>remove(i.id)}>Delete</button></article>)}</div>}</section></section><div className="note">Device sync providers such as Health Connect, Apple Health or Fitbit still require dedicated production integrations.</div></div>
}

function VaccinationsPage(){
 const [items,setItems]=useState([]),[profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState(false),[form,setForm]=useState({vaccineName:"",doseNumber:"",administeredAt:"",nextDueAt:"",provider:"",profileId:""});
 async function load(){setLoading(true);try{const [r,p]=await Promise.all([api.vaccinations(),api.profiles()]);setItems(r.data||[]);setProfiles(p.data||[])}catch(e){setError(e.message||"Unable to load vaccinations")}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const payload={...form,profileId:form.profileId||null,administeredAt:form.administeredAt?new Date(form.administeredAt).toISOString():null,nextDueAt:form.nextDueAt?new Date(form.nextDueAt).toISOString():null,provider:form.provider||null};const r=await api.createVaccination(payload);setItems(x=>[r.data,...x]);setForm({vaccineName:"",doseNumber:"",administeredAt:"",nextDueAt:"",provider:"",profileId:""})}catch(e){setError(e.message||"Unable to save vaccination")}finally{setBusy(false)}}
 async function remove(id){if(!window.confirm("Delete this vaccination?"))return;try{await api.deleteVaccination(id);setItems(x=>x.filter(i=>i.id!==id))}catch(e){setError(e.message||"Unable to delete vaccination")}}
 return <div><div className="page-head"><div><div className="eyebrow">IMMUNIZATION RECORD</div><h1>Vaccinations</h1><p>Store vaccine doses and upcoming due dates.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div><section className="split-grid"><section className="card"><div className="section-title"><div><h2>Add vaccination</h2><p>Record a dose for yourself or family.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Vaccine name<input value={form.vaccineName} onChange={e=>setForm(f=>({...f,vaccineName:e.target.value}))} placeholder="e.g. Hepatitis B" required/></label><label>Dose number<input value={form.doseNumber} onChange={e=>setForm(f=>({...f,doseNumber:e.target.value}))} placeholder="Dose 1"/></label><label>Administered<input type="date" value={form.administeredAt} onChange={e=>setForm(f=>({...f,administeredAt:e.target.value}))}/></label><label>Next due<input type="date" value={form.nextDueAt} onChange={e=>setForm(f=>({...f,nextDueAt:e.target.value}))}/></label><label>Provider<input value={form.provider} onChange={e=>setForm(f=>({...f,provider:e.target.value}))} placeholder="Clinic / hospital"/></label><label>Family profile<select value={form.profileId} onChange={e=>setForm(f=>({...f,profileId:e.target.value}))}><option value="">Myself</option>{profiles.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save vaccination"}</button></form></section><section className="card"><div className="section-title"><div><h2>Vaccination history</h2><p>{items.length} record{items.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading vaccinations…</h2></div>:items.length===0?<div className="empty-state"><div>💉</div><h2>No vaccinations yet</h2></div>:<div className="record-list">{items.map(i=><article className="record-item" key={i.id}><div className="record-icon">💉</div><div className="record-main"><b>{i.vaccineName}</b><small>{[i.doseNumber,i.administeredAt?new Date(i.administeredAt).toLocaleDateString():null,i.provider].filter(Boolean).join(" · ")}</small><p>{i.nextDueAt?`Next due: ${new Date(i.nextDueAt).toLocaleDateString()}`:"No next due date"}</p></div><button className="danger-text" onClick={()=>remove(i.id)}>Delete</button></article>)}</div>}</section></section></div>
}

function HealthGoalsPage(){
 const [items,setItems]=useState([]),[profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState(false),[form,setForm]=useState({title:"",metric:"",target:"",current:"",unit:"",dueDate:"",profileId:""});
 async function load(){setLoading(true);try{const [r,p]=await Promise.all([api.goals(),api.profiles()]);setItems(r.data||[]);setProfiles(p.data||[])}catch(e){setError(e.message||"Unable to load goals")}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const payload={...form,profileId:form.profileId||null,target:form.target||null,current:form.current||null,unit:form.unit||null,metric:form.metric||null,dueDate:form.dueDate?new Date(form.dueDate).toISOString():null};const r=await api.createGoal(payload);setItems(x=>[r.data,...x]);setForm({title:"",metric:"",target:"",current:"",unit:"",dueDate:"",profileId:""})}catch(e){setError(e.message||"Unable to save goal")}finally{setBusy(false)}}
 async function toggle(i){try{const r=await api.updateGoal(i.id,{status:i.status==="completed"?"active":"completed"});setItems(x=>x.map(a=>a.id===i.id?r.data:a))}catch(e){setError(e.message||"Unable to update goal")}}
 async function remove(id){if(!window.confirm("Delete this health goal?"))return;try{await api.deleteGoal(id);setItems(x=>x.filter(i=>i.id!==id))}catch(e){setError(e.message||"Unable to delete goal")}}
 return <div><div className="page-head"><div><div className="eyebrow">HEALTH GOALS</div><h1>Health Goals</h1><p>Track personal or family goals with target and current values.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div><section className="split-grid"><section className="card"><div className="section-title"><div><h2>Create goal</h2><p>Set a measurable target.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Goal title<input value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="Walk 8,000 steps daily" required/></label><label>Metric<input value={form.metric} onChange={e=>setForm(f=>({...f,metric:e.target.value}))} placeholder="Daily steps"/></label><div className="two-col"><label>Target<input value={form.target} onChange={e=>setForm(f=>({...f,target:e.target.value}))} placeholder="8000"/></label><label>Current<input value={form.current} onChange={e=>setForm(f=>({...f,current:e.target.value}))} placeholder="4500"/></label></div><label>Unit<input value={form.unit} onChange={e=>setForm(f=>({...f,unit:e.target.value}))} placeholder="steps"/></label><label>Due date<input type="date" value={form.dueDate} onChange={e=>setForm(f=>({...f,dueDate:e.target.value}))}/></label><label>Family profile<select value={form.profileId} onChange={e=>setForm(f=>({...f,profileId:e.target.value}))}><option value="">Myself</option>{profiles.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Create goal"}</button></form></section><section className="card"><div className="section-title"><div><h2>Your goals</h2><p>{items.length} goal{items.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading goals…</h2></div>:items.length===0?<div className="empty-state"><div>🎯</div><h2>No goals yet</h2></div>:<div className="record-list">{items.map(i=><article className="record-item" key={i.id}><div className="record-icon">🎯</div><div className="record-main"><b>{i.title}</b><small>{[i.metric,i.current&&i.target?`${i.current} / ${i.target} ${i.unit||""}`:i.target?`Target ${i.target} ${i.unit||""}`:null].filter(Boolean).join(" · ")}</small><code>{i.status}{i.dueDate?` · Due ${new Date(i.dueDate).toLocaleDateString()}`:""}</code></div><button onClick={()=>toggle(i)}>{i.status==="completed"?"Reopen":"Complete"}</button><button className="danger-text" onClick={()=>remove(i.id)}>Delete</button></article>)}</div>}</section></section></div>
}

function Dashboard({select}){
 return <>
  <section className="hero"><div><div className="eyebrow">ACCESS & CONSULTATION</div><h1>Find care nearby or consult remotely.</h1><p>Healthcare discovery and telemedicine workflows are now part of the React app.</p></div><div className="hero-actions"><button className="primary" onClick={()=>select("Nearby Healthcare")}>Nearby care</button><button onClick={()=>select("Telemedicine")}>Telemedicine</button></div></section>
  <section className="metrics"><div className="metric"><span>Nearby facilities</span><strong>4</strong><small>Demo directory</small></div><div className="metric"><span>Emergency sites</span><strong>1</strong><small>24/7 hospital</small></div><div className="metric"><span>Consultations</span><strong>3</strong><small>2 upcoming</small></div><div className="metric"><span>Remote modes</span><strong>3</strong><small>Video · Phone · Chat</small></div></section>
  <section className="dashboard-grid"><article className="card"><div className="card-head"><div><h2>Nearby healthcare</h2><p>Facilities from the demo directory.</p></div><button onClick={()=>select("Nearby Healthcare")}>Open</button></div><div className="place-mini">{places.slice(0,3).map(p=><div key={p.id}><span>{p.type==="Hospital"?"🏥":p.type==="Laboratory"?"🧪":p.type==="Pharmacy"?"💊":"🩺"}</span><div><b>{p.name}</b><small>{p.distance} · {p.open}</small></div><em>{p.type}</em></div>)}</div></article>
   <article className="card"><div className="card-head"><div><h2>Telemedicine</h2><p>Upcoming remote consultations.</p></div><button onClick={()=>select("Telemedicine")}>Open</button></div><div className="consult-mini">{consults.slice(0,3).map(c=><div key={c.id}><span>{c.icon}</span><div><b>{c.doctor}</b><small>{c.mode} · {c.date} · {c.time}</small></div><em>{c.status}</em></div>)}</div></article>
  </section>
 </>
}

function NearbyPage({places,query,setQuery,type,setType,emergencyOnly,setEmergencyOnly,selected,setSelected}){
 return <div>
  <div className="page-head"><div><div className="eyebrow">NEARBY HEALTHCARE</div><h1>Find healthcare nearby</h1><p>Search hospitals, clinics, laboratories and pharmacies from your saved/local directory.</p></div><button className="primary" onClick={()=>alert("Demo map/directions action.")}>🗺️ Map view</button></div>
  <section className="nearby-layout">
   <div>
    <section className="toolbar card"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search hospital, clinic, pharmacy or lab..." /><div className="filter-row">{["All","Hospital","Clinic","Laboratory","Pharmacy"].map(f=><button key={f} className={type===f?"filter active":"filter"} onClick={()=>setType(f)}>{f}</button>)}<button className={emergencyOnly?"filter active":"filter"} onClick={()=>setEmergencyOnly(v=>!v)}>🚑 Emergency</button></div></section>
    <section className="card"><div className="section-title"><div><h2>{places.length} nearby places</h2><p>Demo distance and opening information.</p></div><span className="badge">Location-aware UI</span></div><div className="place-list">{places.map(p=><button className={selected?.id===p.id?"place-item selected":"place-item"} key={p.id} onClick={()=>setSelected(p)}><span className="place-icon">{p.type==="Hospital"?"🏥":p.type==="Laboratory"?"🧪":p.type==="Pharmacy"?"💊":"🩺"}</span><div><b>{p.name}</b><small>{p.type} · {p.specialty}</small><small>{p.distance} · {p.open}</small></div>{p.emergency&&<em>24/7</em>}<i>›</i></button>)}</div></section>
   </div>
   <aside className="card place-detail">{selected?<><div className="place-profile"><span>{selected.type==="Hospital"?"🏥":selected.type==="Laboratory"?"🧪":selected.type==="Pharmacy"?"💊":"🩺"}</span><div><h2>{selected.name}</h2><p>{selected.type} · {selected.specialty}</p></div></div><div className="detail-grid"><div><span>Distance</span><b>{selected.distance}</b></div><div><span>Hours</span><b>{selected.open}</b></div><div><span>Phone</span><b>{selected.phone}</b></div><div><span>Emergency</span><b>{selected.emergency?"Available":"No"}</b></div></div><div className="provider-actions"><button>Directions</button><button>Call</button><button>Save place</button></div></>:<div className="empty-state"><div>📍</div><h2>Select a facility</h2><p>Choose a place to view details and actions.</p></div>}</aside>
  </section>
  <div className="emergency-strip"><span>🚑</span><div><b>Emergency quick access</b><small>112 · Emergency Card · nearest 24/7 facility</small></div><button onClick={()=>alert("Demo 112 call action.")}>Call 112</button></div>
  <div className="note">📍 The current directory is a frontend demo. Real nearby search, maps, geolocation and opening hours require a maps/location service and live provider data.</div>
 </div>
}

function TelemedicinePage({consults,query,setQuery,mode,setMode,selected,setSelected}){
 return <div>
  <div className="page-head"><div><div className="eyebrow">TELEMEDICINE</div><h1>Doctor Consultation</h1><p>Manage video, phone and chat consultations with your care team.</p></div><button className="primary" onClick={()=>alert("Demo booking flow opened.")}>＋ Book consultation</button></div>
  <section className="tele-summary"><div className="card"><span>Upcoming</span><b>2</b><small>Scheduled consultations</small></div><div className="card"><span>Modes</span><b>3</b><small>Video · Phone · Chat</small></div><div className="card"><span>Doctors</span><b>3</b><small>Saved specialists</small></div><div className="card"><span>Prep</span><b>Ready</b><small>Record summary available</small></div></section>
  <section className="toolbar card"><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search doctor, specialty, patient or mode..." /><div className="filter-row">{["All","Video","Phone","Chat"].map(f=><button className={mode===f?"filter active":"filter"} key={f} onClick={()=>setMode(f)}>{f}</button>)}</div></section>
  <section className="tele-layout"><div className="card"><div className="section-title"><div><h2>{consults.length} consultations</h2><p>Recent and upcoming sessions.</p></div><span className="badge">React component</span></div><div className="consult-list">{consults.map(c=><button className={selected?.id===c.id?"consult-item selected":"consult-item"} key={c.id} onClick={()=>setSelected(c)}><span className="consult-icon">{c.icon}</span><div><b>{c.doctor}</b><small>{c.specialty} · {c.patient}</small><small>{c.mode} · {c.date} · {c.time}</small></div><em>{c.status}</em></button>)}</div></div>
  <aside className="card consult-detail">{selected?<><div className="place-profile"><span>{selected.icon}</span><div><h2>{selected.doctor}</h2><p>{selected.specialty} · {selected.patient}</p></div></div><div className="detail-grid"><div><span>Date</span><b>{selected.date}</b></div><div><span>Time</span><b>{selected.time}</b></div><div><span>Mode</span><b>{selected.mode}</b></div><div><span>Status</span><b>{selected.status}</b></div></div><div className="prep-list"><b>Appointment prep</b><span>✓ Recent lab results available</span><span>✓ Medicine list available</span><span>✓ Doctor-ready summary available</span></div><div className="provider-actions"><button className="join-btn">Join consultation</button><button>Reschedule</button><button>Cancel</button></div></>:<div className="empty-state"><div>🎥</div><h2>Select a consultation</h2><p>Choose a session to review details and join controls.</p></div>}</aside></section>
  <div className="note">🎥 Video/phone/chat rooms are demo controls. Production telemedicine requires a secure provider, authenticated sessions, consent, encryption and backend scheduling.</div>
 </div>
}



function MedicalRecordsPage(){
 const [records,setRecords]=useState([]);
 const [loading,setLoading]=useState(true);
 const [error,setError]=useState("");
 const [form,setForm]=useState({type:"Consultation",title:"",summary:"",occurredAt:""});
 const [busy,setBusy]=useState(false);
 async function load(){ setLoading(true); setError(""); try{ const r=await api.records(); setRecords(r.data||[]); }catch(e){setError(e.message||"Unable to load records.")}finally{setLoading(false)} }
 useEffect(()=>{load()},[]);
 async function add(e){ e.preventDefault(); setBusy(true); setError(""); try{ const payload={...form, summary:form.summary||undefined, occurredAt:form.occurredAt?new Date(form.occurredAt).toISOString():undefined}; const r=await api.createRecord(payload); setRecords(prev=>[r.data,...prev]); setForm({type:"Consultation",title:"",summary:"",occurredAt:""}); }catch(e){setError(e.message||"Unable to save record")}finally{setBusy(false)} }
 async function remove(id){ if(!window.confirm("Delete this medical record?"))return; try{await api.deleteRecord(id);setRecords(prev=>prev.filter(x=>x.id!==id))}catch(e){setError(e.message||"Unable to delete record")} }
 return <div>
  <div className="page-head"><div><div className="eyebrow">SECURE MEDICAL RECORDS</div><h1>Medical Records</h1><p>Records are now stored against your authenticated account in PostgreSQL.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
  <section className="split-grid">
   <section className="card"><div className="section-title"><div><h2>Add record</h2><p>Only your authenticated account can create and manage these records.</p></div><span className="badge">Backend connected</span></div>
    <form className="auth-form compact-form" onSubmit={add}>
      <label>Type<select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))}><option>Consultation</option><option>Diagnosis</option><option>Lab Report</option><option>Prescription</option><option>Vaccination</option><option>Hospitalization</option><option>Other</option></select></label>
      <label>Title<input value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="e.g. Annual health check" required /></label>
      <label>Date & time<input type="datetime-local" value={form.occurredAt} onChange={e=>setForm(f=>({...f,occurredAt:e.target.value}))}/></label>
      <label>Summary<textarea rows="5" value={form.summary} onChange={e=>setForm(f=>({...f,summary:e.target.value}))} placeholder="Notes, findings or follow-up"></textarea></label>
      {error&&<div className="auth-error">{error}</div>}
      <button className="primary" disabled={busy}>{busy?"Saving…":"Save medical record"}</button>
    </form>
   </section>
   <section className="card"><div className="section-title"><div><h2>Your records</h2><p>{records.length} stored record{records.length===1?"":"s"}</p></div></div>
    {loading?<div className="empty-state"><div>⏳</div><h2>Loading records…</h2></div>:records.length===0?<div className="empty-state"><div>🗂️</div><h2>No records yet</h2><p>Add your first record using the form.</p></div>:<div className="record-list">{records.map(r=><article className="record-item" key={r.id}><div className="record-icon">{r.type==="Lab Report"?"🧪":r.type==="Prescription"?"💊":"🗂️"}</div><div className="record-main"><b>{r.title}</b><small>{r.type}{r.occurredAt?` · ${new Date(r.occurredAt).toLocaleString()}`:""}</small>{r.summary&&<p>{r.summary}</p>}<code>{r.id}</code></div><button className="danger-text" onClick={()=>remove(r.id)}>Delete</button></article>)}</div>}
   </section>
  </section>
  <div className="note">🔐 Ownership is enforced on the API for every read/write/delete request. This is a development storage foundation; production still needs audit logs, encryption/key management, backups and retention controls.</div>
 </div>
}


function FamilyProfilesPage(){
 const [profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[form,setForm]=useState({name:"",relation:"",dob:""}),[busy,setBusy]=useState(false);
 async function load(){setLoading(true);try{const r=await api.profiles();setProfiles(r.data||[])}catch(e){setError(e.message||"Unable to load profiles")}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const r=await api.createProfile({...form,dob:form.dob||null,relation:form.relation||null});setProfiles(p=>[...p,r.data]);setForm({name:"",relation:"",dob:""})}catch(e){setError(e.message||"Unable to save profile")}finally{setBusy(false)}}
 async function remove(id){if(!window.confirm("Delete this family profile?"))return;try{await api.deleteProfile(id);setProfiles(p=>p.filter(x=>x.id!==id))}catch(e){setError(e.message||"Unable to delete profile")}}
 return <div><div className="page-head"><div><div className="eyebrow">FAMILY HEALTH PROFILES</div><h1>Family Profiles</h1><p>Profiles are stored in PostgreSQL and isolated to your account.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
  <section className="split-grid"><section className="card"><div className="section-title"><div><h2>Add profile</h2><p>Create a family member record.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Name<input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} required/></label><label>Relation<input value={form.relation} onChange={e=>setForm(f=>({...f,relation:e.target.value}))} placeholder="Mother, Father, Child…"/></label><label>Date of birth<input type="date" value={form.dob} onChange={e=>setForm(f=>({...f,dob:e.target.value}))}/></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save profile"}</button></form></section>
  <section className="card"><div className="section-title"><div><h2>Your family</h2><p>{profiles.length} profile{profiles.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading profiles…</h2></div>:profiles.length===0?<div className="empty-state"><div>👨‍👩‍👧</div><h2>No family profiles yet</h2></div>:<div className="record-list">{profiles.map(p=><article className="record-item" key={p.id}><div className="record-icon">👤</div><div className="record-main"><b>{p.name}</b><small>{p.relation||"Family member"}{p.dob?` · ${new Date(p.dob).toLocaleDateString()}`:""}</small><code>{p.id}</code></div><button className="danger-text" onClick={()=>remove(p.id)}>Delete</button></article>)}</div>}</section></section>
  <div className="note">🔐 Family profile ownership is enforced by the API. Production still needs audit logging and privacy/retention controls.</div></div>
}

function MedicinesPage(){
 const [items,setItems]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[form,setForm]=useState({name:"",dose:"",frequency:"",active:true}),[busy,setBusy]=useState(false);
 async function load(){setLoading(true);try{const r=await api.medications();setItems(r.data||[])}catch(e){setError(e.message||"Unable to load medicines")}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const r=await api.createMedication(form);setItems(p=>[r.data,...p]);setForm({name:"",dose:"",frequency:"",active:true})}catch(e){setError(e.message||"Unable to save medicine")}finally{setBusy(false)}}
 async function toggle(i){try{const r=await api.updateMedication(i.id,{active:!i.active});setItems(p=>p.map(x=>x.id===i.id?r.data:x))}catch(e){setError(e.message||"Unable to update medicine")}}
 async function remove(id){if(!window.confirm("Delete this medicine?"))return;try{await api.deleteMedication(id);setItems(p=>p.filter(x=>x.id!==id))}catch(e){setError(e.message||"Unable to delete medicine")}}
 return <div><div className="page-head"><div><div className="eyebrow">MEDICATION TRACKER</div><h1>Medicines</h1><p>Your medicine list is now backed by PostgreSQL.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
 <section className="split-grid"><section className="card"><div className="section-title"><div><h2>Add medicine</h2><p>Track dose and schedule.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Medicine<input value={form.name} onChange={e=>setForm(f=>({...f,name:e.target.value}))} placeholder="e.g. Paracetamol" required/></label><label>Dose<input value={form.dose} onChange={e=>setForm(f=>({...f,dose:e.target.value}))} placeholder="500 mg"/></label><label>Frequency<input value={form.frequency} onChange={e=>setForm(f=>({...f,frequency:e.target.value}))} placeholder="Twice daily"/></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save medicine"}</button></form></section>
 <section className="card"><div className="section-title"><div><h2>Medicine list</h2><p>{items.length} medicine{items.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading medicines…</h2></div>:items.length===0?<div className="empty-state"><div>💊</div><h2>No medicines yet</h2></div>:<div className="record-list">{items.map(i=><article className="record-item" key={i.id}><div className="record-icon">💊</div><div className="record-main"><b>{i.name}</b><small>{[i.dose,i.frequency].filter(Boolean).join(" · ")||"Schedule not set"}</small><code>{i.active?"Active":"Inactive"}</code></div><button onClick={()=>toggle(i)}>{i.active?"Mark inactive":"Mark active"}</button><button className="danger-text" onClick={()=>remove(i.id)}>Delete</button></article>)}</div>}</section></section></div>
}

function LabReportsPage(){
 const [items,setItems]=useState([]),[profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[form,setForm]=useState({testName:"",result:"",unit:"",reference:"",status:"Normal",testedAt:"",profileId:""}),[busy,setBusy]=useState(false);
 async function load(){setLoading(true);try{const [r,p]=await Promise.all([api.labReports(),api.profiles()]);setItems(r.data||[]);setProfiles(p.data||[])}catch(e){setError(e.message||"Unable to load lab reports")}finally{setLoading(false)}} useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const payload={...form,profileId:form.profileId||null,result:form.result||null,unit:form.unit||null,reference:form.reference||null,status:form.status||null,testedAt:form.testedAt?new Date(form.testedAt).toISOString():null};const r=await api.createLabReport(payload);setItems(p=>[r.data,...p]);setForm({testName:"",result:"",unit:"",reference:"",status:"Normal",testedAt:"",profileId:""})}catch(e){setError(e.message||"Unable to save lab report")}finally{setBusy(false)}}
 async function remove(id){if(!window.confirm("Delete this lab report?"))return;try{await api.deleteLabReport(id);setItems(p=>p.filter(x=>x.id!==id))}catch(e){setError(e.message||"Unable to delete lab report")}}
 return <div><div className="page-head"><div><div className="eyebrow">LAB REPORTS</div><h1>Lab Reports</h1><p>Store lab results with optional family-profile ownership.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
 <section className="split-grid"><section className="card"><div className="section-title"><div><h2>Add result</h2><p>Capture a biomarker or diagnostic result.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Test name<input value={form.testName} onChange={e=>setForm(f=>({...f,testName:e.target.value}))} placeholder="e.g. Hemoglobin" required/></label><label>Result<input value={form.result} onChange={e=>setForm(f=>({...f,result:e.target.value}))}/></label><label>Unit<input value={form.unit} onChange={e=>setForm(f=>({...f,unit:e.target.value}))} placeholder="g/dL"/></label><label>Reference range<input value={form.reference} onChange={e=>setForm(f=>({...f,reference:e.target.value}))}/></label><label>Status<select value={form.status} onChange={e=>setForm(f=>({...f,status:e.target.value}))}><option>Normal</option><option>High</option><option>Low</option><option>Critical</option><option>Pending</option></select></label><label>Date/time<input type="datetime-local" value={form.testedAt} onChange={e=>setForm(f=>({...f,testedAt:e.target.value}))}/></label><label>Family profile<select value={form.profileId} onChange={e=>setForm(f=>({...f,profileId:e.target.value}))}><option value="">Myself</option>{profiles.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save lab result"}</button></form></section>
 <section className="card"><div className="section-title"><div><h2>Results</h2><p>{items.length} report{items.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading reports…</h2></div>:items.length===0?<div className="empty-state"><div>🧪</div><h2>No lab reports yet</h2></div>:<div className="record-list">{items.map(i=><article className="record-item" key={i.id}><div className="record-icon">🧪</div><div className="record-main"><b>{i.testName}</b><small>{[i.result,i.unit].filter(Boolean).join(" ")}{i.testedAt?` · ${new Date(i.testedAt).toLocaleString()}`:""}</small><p>{i.reference?`Reference: ${i.reference} · `:""}{i.status||""}</p><code>{i.profileId?`Profile ${i.profileId}`:"My health record"}</code></div><button className="danger-text" onClick={()=>remove(i.id)}>Delete</button></article>)}</div>}</section></section></div>
}

function DocumentsPage(){
 const [documents,setDocuments]=useState([]); const [loading,setLoading]=useState(true); const [busy,setBusy]=useState(false); const [error,setError]=useState("");
 async function load(){setLoading(true);setError("");try{const r=await api.documents();setDocuments(r.data||[])}catch(e){setError(e.message||"Unable to load documents")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 async function upload(e){const file=e.target.files?.[0];e.target.value="";if(!file)return;setBusy(true);setError("");try{const r=await api.uploadDocument(file);setDocuments(prev=>[r.data,...prev])}catch(e){setError(e.message||"Upload failed")}finally{setBusy(false)}}
 async function remove(id){if(!window.confirm("Delete this document?"))return;try{await api.deleteDocument(id);setDocuments(prev=>prev.filter(x=>x.id!==id))}catch(e){setError(e.message||"Unable to delete document")}}
 function openDocument(id){window.open(api.documentDownloadUrl(id),"_blank","noopener,noreferrer")}
 return <div>
  <div className="page-head"><div><div className="eyebrow">PRIVATE DOCUMENT VAULT</div><h1>Documents Vault</h1><p>Private files are stored behind authenticated download and delete endpoints.</p></div><label className="primary upload-label">{busy?"Uploading…":"＋ Upload document"}<input type="file" hidden accept="application/pdf,image/jpeg,image/png,image/webp,text/plain,.doc,.docx" onChange={upload} disabled={busy}/></label></div>
  <section className="card"><div className="section-title"><div><h2>Stored documents</h2><p>{documents.length} file{documents.length===1?"":"s"}</p></div><button onClick={load}>↻ Refresh</button></div>
   {error&&<div className="auth-error">{error}</div>}
   {loading?<div className="empty-state"><div>⏳</div><h2>Loading documents…</h2></div>:documents.length===0?<div className="empty-state"><div>📄</div><h2>Your vault is empty</h2><p>Upload a PDF or supported image/document to begin.</p></div>:<div className="document-list">{documents.map(d=><article className="document-item" key={d.id}><div className="document-icon">{d.mimeType.includes("pdf")?"📕":d.mimeType.startsWith("image/")?"🖼️":"📄"}</div><div><b>{d.name}</b><small>{d.mimeType} · {formatBytes(d.sizeBytes)} · {new Date(d.createdAt).toLocaleString()}</small><code>SHA-256 {d.sha256.slice(0,16)}…</code></div><div className="document-actions"><button onClick={()=>openDocument(d.id)}>Open / download</button><button className="danger-text" onClick={()=>remove(d.id)}>Delete</button></div></article>)}</div>}
  </section>
  <div className="note">🛡️ Files are not publicly served. The API checks the logged-in user before download/delete. Default upload limit is 10 MB with a MIME allowlist. Production should use encrypted object storage/KMS and malware scanning.</div>
 </div>
}

function formatBytes(n){if(n<1024)return `${n} B`;if(n<1024*1024)return `${(n/1024).toFixed(1)} KB`;return `${(n/1024/1024).toFixed(1)} MB`}

function MfaSettings(){
 const [state,setState]=useState({enabled:false,devices:[]}),[setup,setSetup]=useState(null),[code,setCode]=useState(""),[busy,setBusy]=useState(false),[error,setError]=useState(""),[message,setMessage]=useState("");
 async function load(){try{setState(await api.mfaStatus())}catch(e){setError(e.message||"Unable to load MFA status.")}}
 useEffect(()=>{load()},[]);
 async function start(){setBusy(true);setError("");setMessage("");try{setSetup(await api.mfaSetup())}catch(e){setError(e.message||"Unable to start MFA setup.")}finally{setBusy(false)}}
 async function enable(){setBusy(true);setError("");try{await api.mfaEnable(code);setSetup(null);setCode("");setMessage("MFA enabled. Save your recovery codes securely.");load()}catch(e){setError(e.message||"Invalid authenticator code.")}finally{setBusy(false)}}
 async function disable(){setBusy(true);setError("");try{await api.mfaDisable(code);setCode("");setMessage("MFA disabled.");load()}catch(e){setError(e.message||"Unable to disable MFA.")}finally{setBusy(false)}}
 async function revoke(id){try{await api.mfaRevokeDevice(id);load()}catch(e){setError(e.message||"Unable to revoke device.")}}
 return <section className="card settings-section"><div className="section-title"><div><h2>Two-factor authentication</h2><p>Protect sign-ins with an authenticator app and recovery codes.</p></div><span className="badge">{state.enabled?"Enabled":"Off"}</span></div>{error&&<div className="auth-error">{error}</div>}{message&&<div className="auth-success">{message}</div>}{!state.enabled&&!setup&&<button className="primary" onClick={start} disabled={busy}>{busy?"Preparing…":"Set up authenticator MFA"}</button>}{setup&&<div className="mfa-setup"><div className="note"><b>1. Add this secret to your authenticator app</b><code>{setup.secret}</code><small>Or import this URI: {setup.otpauth}</small></div><div className="note"><b>2. Save these recovery codes</b><div className="recovery-grid">{setup.recoveryCodes.map(c=><code key={c}>{c}</code>)}</div></div><label className="setting-field">Authenticator code<input className="mfa-code" inputMode="numeric" autoComplete="one-time-code" value={code} onChange={e=>setCode(e.target.value)} placeholder="123456" /></label><button className="primary" onClick={enable} disabled={busy}>{busy?"Enabling…":"Confirm & enable MFA"}</button></div>}{state.enabled&&<div className="mfa-active"><div className="setting-row"><div><b>MFA is active</b><small>Authenticator code is required unless a trusted device is used.</small></div><button onClick={disable}>Disable</button></div><label className="setting-field">Code to disable<input className="mfa-code" inputMode="numeric" value={code} onChange={e=>setCode(e.target.value)} placeholder="123456" /></label><div className="device-list"><b>Trusted devices</b>{state.devices.length===0?<small>No trusted devices.</small>:state.devices.map(d=><div className="setting-row" key={d.id}><div><b>{d.label||"Trusted device"}</b><small>Last used {new Date(d.lastUsedAt).toLocaleString()} · Expires {new Date(d.expiresAt).toLocaleDateString()}</small></div><button onClick={()=>revoke(d.id)}>Revoke</button></div>)}</div></div>}</section>
}

function SettingsPage({settingsSaved,setSettingsSaved,securityMode,setSecurityMode,reminders,setReminders,analytics,setAnalytics,sharing,setSharing,user,onLogout}){
 function save(){
   localStorage.setItem("medivault_settings",JSON.stringify({securityMode,reminders,analytics,sharing}));
   setSettingsSaved(true);
   setTimeout(()=>setSettingsSaved(false),1400);
 }
 return <div>
  <div className="page-head"><div><div className="eyebrow">APP SETTINGS</div><h1>Settings</h1><p>Manage profile, reminders, privacy preferences and final app configuration.</p></div><button className="primary" onClick={save}>{settingsSaved?"✓ Saved":"Save settings"}</button></div>
  <section className="settings-grid">
   <section className="card"><div className="section-title"><div><h2>Profile</h2><p>Basic account information for the prototype.</p></div></div><div className="settings-profile"><div className="settings-avatar">AK</div><div><b>{user?.name || "MediVault User"}</b><small>Authenticated account</small><small>{user?.email}</small></div><button>Edit</button></div></section>
   <section className="card"><div className="section-title"><div><h2>Privacy & security</h2><p>Choose the local protection level.</p></div><span className="badge">Demo</span></div>
    <label className="setting-field">Security mode<select value={securityMode} onChange={e=>setSecurityMode(e.target.value)}><option>Standard</option><option>Strict</option><option>Maximum</option></select></label>
    <SettingRow title="Health reminders" text="Medicine, appointment and vaccination reminders." on={reminders} set={setReminders}/>
    <SettingRow title="Health analytics" text="Allow analytics summaries inside the app." on={analytics} set={setAnalytics}/>
    <SettingRow title="Sharing links" text="Allow temporary sharing links." on={sharing} set={setSharing}/>
   </section>
  </section>
  <MfaSettings/>
  <section className="card settings-section"><div className="section-title"><div><h2>Data & account</h2><p>Final production-oriented actions.</p></div></div>
    <div className="action-grid">
      <button><span>📤</span><b>Export all data</b><small>Create a portable account backup.</small></button>
      <button><span>💾</span><b>Backup & restore</b><small>Open the data center.</small></button>
      <button><span>📱</span><b>Trusted devices</b><small>Review signed-in sessions.</small></button>
      <button onClick={onLogout}><span>🚪</span><b>Sign out</b><small>End the current secure session.</small></button>
      <button className="danger"><span>🗑️</span><b>Delete account</b><small>Production action requires confirmation.</small></button>
    </div>
  </section>
  <section className="card final-audit"><div className="section-title"><div><h2>Final integration status</h2><p>React migration checklist.</p></div><span className="badge">Release candidate</span></div>
   <div className="final-grid">
    {[
      ["⚛️","React application","Core shell migrated","Ready"],
      ["🧭","Navigation","Universal three-line menu","Ready"],
      ["💾","Data layer","Local prototype + backend-ready architecture","Ready"],
      ["🔐","Security","Controls + production requirements documented","Ready for backend"],
      ["☁️","Cloud","Sync architecture documented","Ready for backend"],
      ["🤖","AI","Frontend assistant + summary","API required"],
      ["🪪","ABHA / ABDM","UI + consent surfaces","API required"],
      ["🎥","Telemedicine","Scheduling UI","Provider required"],
    ].map(x=><div key={x[1]}><span>{x[0]}</span><div><b>{x[1]}</b><small>{x[2]}</small></div><em>{x[3]}</em></div>)}
   </div>
  </section>
  <div className="note">✅ The React prototype is now feature-complete at the UI/demo level. Production deployment still requires the real backend, authentication, secure storage, API integrations, testing and privacy/compliance work.</div>
 </div>
}

function SettingRow({title,text,on,set}){
 return <div className="setting-row"><div><b>{title}</b><small>{text}</small></div><button className={on?"switch on":"switch"} onClick={()=>set(v=>!v)}><i></i></button></div>
}


function CalendarPage(){
 const [items,setItems]=useState([]),[profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState(false);
 const [form,setForm]=useState({title:"",type:"Reminder",startAt:"",endAt:"",notes:"",profileId:""});
 async function load(){setLoading(true);setError("");try{const [e,p]=await Promise.all([api.events(),api.profiles()]);setItems(e.data||[]);setProfiles(p.data||[]);}catch(err){setError(err.message||"Unable to load calendar.")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const r=await api.createEvent({title:form.title,type:form.type,startAt:new Date(form.startAt).toISOString(),endAt:form.endAt?new Date(form.endAt).toISOString():undefined,notes:form.notes||undefined,profileId:form.profileId||undefined});setItems(prev=>[...prev,r.data].sort((a,b)=>new Date(a.startAt)-new Date(b.startAt)));setForm({title:"",type:"Reminder",startAt:"",endAt:"",notes:"",profileId:""});}catch(err){setError(err.message||"Unable to save reminder.")}finally{setBusy(false)}}
 async function toggle(item){try{const r=await api.updateEvent(item.id,{completed:!item.completed});setItems(prev=>prev.map(x=>x.id===item.id?r.data:x));}catch(err){setError(err.message||"Unable to update reminder.")}}
 async function remove(id){if(!window.confirm("Delete this reminder?"))return;try{await api.deleteEvent(id);setItems(prev=>prev.filter(x=>x.id!==id));}catch(err){setError(err.message||"Unable to delete reminder.")}}
 return <div><div className="page-head"><div><div className="eyebrow">CALENDAR & REMINDERS</div><h1>Appointments & Reminders</h1><p>Store personal health reminders and appointments in PostgreSQL.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
 <section className="split-grid"><section className="card"><div className="section-title"><div><h2>Add reminder</h2><p>Medicine, appointment, vaccination or custom reminder.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Title<input value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="e.g. Take evening medicine" required/></label><label>Type<select value={form.type} onChange={e=>setForm(f=>({...f,type:e.target.value}))}><option>Reminder</option><option>Appointment</option><option>Medicine</option><option>Vaccination</option><option>Follow-up</option></select></label><label>Start<input type="datetime-local" value={form.startAt} onChange={e=>setForm(f=>({...f,startAt:e.target.value}))} required/></label><label>End (optional)<input type="datetime-local" value={form.endAt} onChange={e=>setForm(f=>({...f,endAt:e.target.value}))}/></label><label>Profile (optional)<select value={form.profileId} onChange={e=>setForm(f=>({...f,profileId:e.target.value}))}><option value="">Self / account</option>{profiles.map(p=><option value={p.id} key={p.id}>{p.name}{p.relation?` · ${p.relation}`:""}</option>)}</select></label><label>Notes<textarea rows="4" value={form.notes} onChange={e=>setForm(f=>({...f,notes:e.target.value}))} placeholder="Instructions or preparation notes"/></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save reminder"}</button></form></section>
 <section className="card"><div className="section-title"><div><h2>Upcoming & recent</h2><p>{items.length} stored event{items.length===1?"":"s"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading calendar…</h2></div>:items.length===0?<div className="empty-state"><div>📅</div><h2>No reminders yet</h2><p>Add your first appointment or reminder.</p></div>:<div className="record-list">{items.map(x=><article className="record-item" key={x.id}><div className="record-icon">{x.type==="Medicine"?"💊":x.type==="Vaccination"?"💉":x.type==="Appointment"?"🩺":"📅"}</div><div className="record-main"><b>{x.title}</b><small>{x.type} · {new Date(x.startAt).toLocaleString()}</small>{x.notes&&<p>{x.notes}</p>}</div><button onClick={()=>toggle(x)}>{x.completed?"✓ Done":"Mark done"}</button><button className="danger-text" onClick={()=>remove(x.id)}>Delete</button></article>)}</div>}</section></section><div className="note">🔔 These are stored reminders. Actual push/email/SMS notifications require a production notification worker and delivery provider.</div></div>
}

function JournalPage(){
 const [items,setItems]=useState([]),[profiles,setProfiles]=useState([]),[loading,setLoading]=useState(true),[error,setError]=useState(""),[busy,setBusy]=useState(false); const [form,setForm]=useState({title:"",mood:"",content:"",entryDate:"",tags:"",profileId:""});
 async function load(){setLoading(true);setError("");try{const [j,p]=await Promise.all([api.journal(),api.profiles()]);setItems(j.data||[]);setProfiles(p.data||[]);}catch(err){setError(err.message||"Unable to load journal.")}finally{setLoading(false)}}
 useEffect(()=>{load()},[]);
 async function add(e){e.preventDefault();setBusy(true);setError("");try{const r=await api.createJournalEntry({title:form.title,mood:form.mood||undefined,content:form.content,entryDate:form.entryDate?new Date(form.entryDate).toISOString():undefined,tags:form.tags||undefined,profileId:form.profileId||undefined});setItems(prev=>[r.data,...prev]);setForm({title:"",mood:"",content:"",entryDate:"",tags:"",profileId:""});}catch(err){setError(err.message||"Unable to save journal entry.")}finally{setBusy(false)}}
 async function remove(id){if(!window.confirm("Delete this journal entry?"))return;try{await api.deleteJournalEntry(id);setItems(prev=>prev.filter(x=>x.id!==id));}catch(err){setError(err.message||"Unable to delete journal entry.")}}
 return <div><div className="page-head"><div><div className="eyebrow">HEALTH JOURNAL</div><h1>Health Journal</h1><p>Keep dated notes about symptoms, wellbeing, recovery and daily health observations.</p></div><button className="primary" onClick={load}>↻ Refresh</button></div>
 <section className="split-grid"><section className="card"><div className="section-title"><div><h2>New journal entry</h2><p>Personal notes are scoped to your authenticated account.</p></div><span className="badge">Backend connected</span></div><form className="auth-form compact-form" onSubmit={add}><label>Title<input value={form.title} onChange={e=>setForm(f=>({...f,title:e.target.value}))} placeholder="e.g. Headache after work" required/></label><label>Mood<select value={form.mood} onChange={e=>setForm(f=>({...f,mood:e.target.value}))}><option value="">Not specified</option><option>Great</option><option>Good</option><option>Okay</option><option>Tired</option><option>Low</option><option>Stressed</option></select></label><label>Date & time<input type="datetime-local" value={form.entryDate} onChange={e=>setForm(f=>({...f,entryDate:e.target.value}))}/></label><label>Profile (optional)<select value={form.profileId} onChange={e=>setForm(f=>({...f,profileId:e.target.value}))}><option value="">Self / account</option>{profiles.map(p=><option value={p.id} key={p.id}>{p.name}{p.relation?` · ${p.relation}`:""}</option>)}</select></label><label>Tags<input value={form.tags} onChange={e=>setForm(f=>({...f,tags:e.target.value}))} placeholder="sleep, diet, recovery"/></label><label>Entry<textarea rows="8" value={form.content} onChange={e=>setForm(f=>({...f,content:e.target.value}))} placeholder="Write your health observation…" required/></label>{error&&<div className="auth-error">{error}</div>}<button className="primary" disabled={busy}>{busy?"Saving…":"Save journal entry"}</button></form></section>
 <section className="card"><div className="section-title"><div><h2>Journal timeline</h2><p>{items.length} entr{items.length===1?"y":"ies"}</p></div></div>{loading?<div className="empty-state"><div>⏳</div><h2>Loading journal…</h2></div>:items.length===0?<div className="empty-state"><div>📓</div><h2>Your journal is empty</h2><p>Add a note about how you are feeling today.</p></div>:<div className="record-list">{items.map(x=><article className="record-item" key={x.id}><div className="record-icon">📓</div><div className="record-main"><b>{x.title}</b><small>{new Date(x.entryDate).toLocaleString()}{x.mood?` · ${x.mood}`:""}{x.tags?` · ${x.tags}`:""}</small><p>{x.content}</p></div><button className="danger-text" onClick={()=>remove(x.id)}>Delete</button></article>)}</div>}</section></section><div className="note">📝 Journal entries are personal notes and should not replace professional medical assessment. Backend ownership checks protect entries within your account.</div></div>
}

function Placeholder({active,onBack}){return <section className="placeholder card"><div className="eyebrow">REACT MODULE</div><h1>{active}</h1><p>This section is routed through the React application. Additional modules are being migrated step-by-step.</p><div className="placeholder-actions"><button className="primary" onClick={onBack}>Back to dashboard</button><button onClick={()=>window.open("/legacy-prototype.html","_blank")}>Open legacy prototype</button></div></section>}

export default App;
