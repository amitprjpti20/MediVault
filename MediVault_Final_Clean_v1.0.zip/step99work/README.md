# MediVault

Production-oriented health records web application scaffold.

## Project structure

- `src/` — React frontend
- `server/` — Node.js + Prisma backend
- `observability/` — Prometheus, Grafana, Loki, Tempo and OpenTelemetry configuration
- `deploy/` — production web/server deployment configuration
- `docs/` — operational runbooks
- `release/` — production sign-off and release manifest

## Local setup

Install dependencies in the root and server packages, configure environment variables, run PostgreSQL, apply Prisma migrations, then start the frontend and backend.

See `server/README.md` and the operational runbooks for deployment and recovery details.
