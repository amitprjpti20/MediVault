# Production Sign-off Checklist

Use this checklist immediately before live deployment.

- [ ] Clean CI runner: dependency install succeeds.
- [ ] Frontend build succeeds.
- [ ] Backend starts with production configuration.
- [ ] Prisma migrations apply to staging and production safely.
- [ ] Managed PostgreSQL configured.
- [ ] Encryption/secrets stored in a secret manager.
- [ ] Object storage configured and encrypted.
- [ ] TLS certificate and DNS verified.
- [ ] WAF/rate-limiting configured.
- [ ] Email/SMS/push providers configured.
- [ ] Prometheus/OTel/Grafana/Tempo/Loki/Alertmanager receivers configured.
- [ ] Backup and restore drill verified.
- [ ] Incident/on-call runbooks approved.
- [ ] Privacy/retention/legal review approved.
- [ ] Security/dependency/secret scans pass.
- [ ] Authenticated end-to-end smoke tests pass.
- [ ] Rollback plan tested.
